# app.py: Main Web Application Controller, Gatekeeper & Router.
#
# WHAT THIS FILE DOES:
#   This is the root entry point executed by `streamlit run app.py`. It coordinates the entire
#   application lifecycle on every user interaction:
#     1. Sets up the browser tab title, favicon, and wide responsive layout.
#     2. Verifies that the MySQL database is reachable and populated before proceeding.
#     3. Updates confirmed bookings whose check-out date has passed to 'Completed'.
#     4. Acts as an authentication gate: if unauthenticated, it renders only the login screen.
#     5. Renders the persistent sidebar with user identity, dynamic unread counters, and navigation.
#     6. Routes to the active page component (`page_explore`, `page_details`, `page_checkout`, etc.).
#
# WHY THIS STEP IS NECESSARY:
#   Streamlit executes from top to bottom on every user click or input change. Having a clean,
#   central controller ensures consistent state initialization, enforces role-based access control
#   (so non-admins can never access the Admin Dashboard), and handles global branding.

import streamlit as st  # Core Streamlit library used to render UI components.
import database  # MySQL database functions: health check, booking completion, unread counts.
import auth  # Authentication helper functions: session checks and logout.
import activity  # Navigation helpers and audit logging.

# Configure browser tab title, favicon emoji, and responsive wide screen layout.
st.set_page_config(page_title="OFFSTAYS | Luxury Stays", page_icon="🏡", layout="wide")

# Initialize persistent session state variables if they do not already exist.
# Streamlit re-runs this script from top to bottom on every interaction; `st.session_state`
# is the only dictionary where values survive across reruns.
DEFAULTS = {
    "current_page": "explore",        # Active page route (explore, details, checkout, messages, etc.).
    "selected_listing_id": None,     # ID of the stay currently inspected on the details page.
    "pending_booking": None,          # Staged booking dictionary carried from details to checkout.
    "details_photo_index": 0,         # Active carousel photo index on the details screen.
    "chat_listing_id": None,          # Property thread ID currently opened on the Messages screen.
    "user": None,                     # Authenticated user dictionary (None if visitor is logged out).
    "session_id": None,               # Primary key ID of the current login row in MySQL `user_sessions`.
}
for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value

# Inject custom CSS for OFFSTAYS branding:
# - Signature coral accent (#E0565C) for all primary buttons and form submit actions.
# - Subtle card borders with rounded corners for luxury presentation.
st.markdown("""
<style>
    div.stButton > button:first-child, div.stFormSubmitButton > button:first-child {
        background-color: #E0565C; color: white; border: none; border-radius: 6px; font-weight: 600;
    }
    div.stButton > button:first-child:hover, div.stFormSubmitButton > button:first-child:hover {
        background-color: #c9444a; color: white;
    }
    .brand-coral { color: #E0565C; font-weight: 700; }
    [data-testid="stVerticalBlockBorderWrapper"] { border-radius: 10px; }
</style>
""", unsafe_allow_html=True)

# 1. DATABASE HEALTH CHECK:
# Ensure MySQL is reachable and the schema is loaded before attempting any UI rendering.
db_ok, db_message = database.check_database_ready()
if not db_ok:
    st.title("🏡 OFFSTAYS")
    st.error(f"**Database not ready.** {db_message}")
    st.markdown("""
**Checklist**
1. MySQL Server is installed and running (MySQL Workbench can connect to it).
2. In Workbench, run `sql/01_schema.sql`, then `sql/02_seed_data.sql`.
   (Or run `python setup_database.py` from the project folder.)
3. `db_config.py` contains the correct MySQL password.
4. Refresh this page.
""")
    st.stop()  # Halt execution cleanly so users do not see broken code stack traces.

# 2. AUTOMATIC BOOKING STATUS MAINTENANCE:
# Confirmed bookings whose checkout date has passed are marked as 'Completed' in MySQL.
database.update_completed_bookings()

# 3. AUTHENTICATION GATE:
# If no user is logged in, show only the Login / Register screen and halt further rendering.
if not auth.is_logged_in():
    import page_login
    page_login.render()
    st.stop()

# Retrieve safe user profile dictionary from session state
user = auth.current_user()

# Display one-time toast welcome banner if redirected from login or registration
welcome = st.session_state.pop("flash_main", None)
if welcome:
    st.toast(welcome, icon="👋")

# 4. SIDEBAR RENDERING:
# Displays user identity, dynamic unread badge slot, page navigation buttons, and logout.
with st.sidebar:
    st.markdown("## 🏡 **OFFSTAYS**")
    st.caption("Hand-picked sanctuaries · Worldwide")
    st.markdown("---")

    # User Profile Header: Avatar + Name + Role ID
    user_col1, user_col2 = st.columns([1, 3])
    with user_col1:
        if user.get("avatar_url"):
            st.image(user["avatar_url"], width=55)
    with user_col2:
        st.markdown(f"**{user['full_name']}**")
        st.caption(f"{user['role'].capitalize()} · #USR-{user['user_id']:04d}")

    # Empty placeholder container for unread counts.
    # Filled at the bottom of the script after the active page finishes rendering.
    badge_slot = st.empty()
    st.markdown("---")

    # Navigation menu items.
    NAV = [
        ("Explore Stays", "explore"),
        ("Messages", "messages"),
        ("My Trips", "trips"),
        ("Become a Host", "host"),
        ("My Profile", "profile"),
    ]
    # Admin dashboard option only appears if the user has role = 'admin' in MySQL.
    if user["role"] == "admin":
        NAV.append(("🛡️ Admin Dashboard", "admin"))
        
    for label, page_key in NAV:
        if st.button(label, use_container_width=True, key=f"nav_{page_key}"):
            activity.go_to(page_key)

    st.markdown("---")
    if st.button("🚪 Log out", use_container_width=True, key="nav_logout"):
        auth.logout_user()
        st.session_state["flash"] = "You have been logged out."
        st.rerun()
        
    st.caption("OFFSTAYS Demo Environment · Software Engineering Coursework")

# 5. PAGE ROUTING:
# Dynamically imports and executes the render() function for the requested page.
import page_explore
import page_details
import page_checkout
import page_messages
import page_trips
import page_host
import page_profile
import page_admin

ROUTES = {
    "explore": page_explore.render,
    "details": page_details.render,
    "checkout": page_checkout.render,
    "messages": page_messages.render,
    "trips": page_trips.render,
    "host": page_host.render,
    "profile": page_profile.render,
    "admin": page_admin.render,
}

page = st.session_state["current_page"]
# Security check: Non-admin users attempting to open 'admin' are redirected to 'explore'.
if page == "admin" and user["role"] != "admin":
    page = "explore"
    
# Execute the corresponding page render function
ROUTES.get(page, page_explore.render)()

# 6. POPULATE SIDEBAR COUNTERS:
# Now that the active page has finished running (including any new bookings or messages),
# query fresh unread counts from MySQL and display them in the reserved sidebar slot.
unread_messages = database.get_unread_message_count(user["user_id"])
unread_notifs = database.get_unread_notification_count(user["user_id"])
badge_slot.caption(f"💬 {unread_messages} unread message(s) · 🔔 {unread_notifs} new notification(s)")

# Global Static Footer
st.markdown("---")
footer_col1, footer_col2 = st.columns([2, 1])
with footer_col1:
    st.caption("© 2026 OFFSTAYS Inc. · Hand-picked sanctuaries from Bali to the Swiss Alps · Demo project for Software Engineering coursework.")
with footer_col2:
    st.caption("Simulated booking platform · All transactions and messages are simulated.")