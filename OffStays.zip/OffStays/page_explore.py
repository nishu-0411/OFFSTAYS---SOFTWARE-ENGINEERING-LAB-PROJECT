# page_explore.py: Explore Stays Marketplace, Filtering & Map Screen.
#
# WHAT THIS FILE DOES:
#   Renders the primary discovery marketplace where guests can:
#     1. Select a destination (e.g. Bali, Swiss Alps, Kyoto) and drill down into specific areas.
#     2. Pick calendar check-in and check-out dates and specify guest capacity.
#     3. Filter by property category, nightly price range, and amenities (private pool, fast Wi-Fi, superhost).
#     4. Sort stays by price or review rating.
#     5. View stay locations on an interactive world map (`st.map`).
#     6. View stay cards with live total pricing, and toggle wishlist saves.
#
# WHY THIS STEP IS NECESSARY:
#   This is the main browsing interface of OFFSTAYS. It implements our availability
#   collision check (`database.get_unavailable_listing_ids`), ensuring that stays with
#   overlapping confirmed bookings are hidden in real time.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Calls `database.get_destinations()` and `database.get_areas()` to dynamically populate search filters.
#   - Calls `pricing.calculate_price_breakdown()` to compute live totals on each property card.
#   - Calls `activity.open_property()` to navigate to `page_details.py` when a user clicks 'View details'.
#   - Calls `database.toggle_saved_listing()` when a user clicks the bookmark button.

import streamlit as st  # Streamlit UI components (selectboxes, sliders, columns, cards).
import pandas as pd  # Structures latitude and longitude coordinates for Streamlit's built-in map widget.
import datetime  # Standard module for calendar dates and check-in/check-out date math.
import database  # Database queries for listings, destinations, availability, and wishlists.
import pricing  # Live stay price calculator module.
import activity  # Audit logging (SEARCH, SAVE_PROPERTY) and page navigation.
import auth  # Retrieves current authenticated user.


# Sorting helper functions:
# Named functions are used instead of lambda expressions for clean readability during a viva.
def sort_by_price(item):
    # Extracts the nightly price integer for ascending or descending sort order.
    return item["price_per_night"]


def sort_by_rating(item):
    # Extracts the guest review score (e.g. 4.98) for highest-rated sorting.
    return item["rating"]


# Sentinel string constants for default dropdown selections
ALL_DESTINATIONS = "🌍 All destinations"
ALL_AREAS = "All areas"


def filter_stays(all_listings, destination, area, category, min_p, max_p, req_pool, req_wifi, req_superhost, guests, unavailable_ids):
    # WHAT: Filters the list of properties based on user-selected criteria.
    # WHY:  Keeps filtering logic organized in a clean, sequential, and easily explainable loop.
    # HOW:  Tests each stay against destination, area, category, price bounds, capacity, amenities,
    #       and the set of unavailable IDs returned by MySQL availability queries.
    filtered = []
    for stay in all_listings:
        # Rule 1a: Filter by destination (e.g. Bali, Swiss Alps).
        if destination != ALL_DESTINATIONS and stay["destination"] != destination:
            continue
            
        # Rule 1b: Filter by specific neighbourhood/area within the destination (e.g. Ubud).
        if area != ALL_AREAS and stay["area"] != area:
            continue
            
        # Rule 2: Filter by category (e.g. Amazing pools, Overwater Villas).
        if category != "All Categories" and stay["category"] != category:
            continue
            
        # Rule 3: Filter by nightly price bounds from the slider.
        if stay["price_per_night"] < min_p or stay["price_per_night"] > max_p:
            continue
            
        # Rule 4: Property must have capacity for the requested number of guests.
        if guests > stay["max_guests"]:
            continue
            
        # Rule 5: Check for private pool amenity if requested.
        if req_pool and stay["has_pool"] != 1:
            continue
            
        # Rule 6: Check for fast Wi-Fi amenity if requested.
        if req_wifi and stay["has_wifi"] != 1:
            continue
            
        # Rule 7: Check if the host is a certified Superhost if requested.
        if req_superhost and stay["host_superhost"] != 1:
            continue
            
        # Rule 8: Availability collision rule - skip if the property has a confirmed
        # booking overlapping the chosen check-in and check-out dates.
        if stay["id"] in unavailable_ids:
            continue
            
        filtered.append(stay)
    return filtered


def render_stay_card(stay, check_in_date, check_out_date, total_nights, saved_ids, user_id):
    # WHAT: Draws a single stay card inside a clean bordered container.
    # HOW:  Displays the cover image, badge, title, subtitle, rating, live price calculation,
    #       a 'View details' button, and a 'Save' wishlist toggle button.
    with st.container(border=True):
        # Display the primary cover photo (the first image URL in the pipe-separated string).
        st.image(stay["image_urls"].split("|")[0], use_container_width=True)
        st.caption(f"**{stay['badge']}** · 📍 {stay['area']}, {stay['destination']} · {stay['category']}")
        st.markdown(f"### {stay['title']}")
        st.write(stay["subtitle"])
        st.write(f"★ **{stay['rating']:.2f}** ({stay['review_count']} reviews) · Max {stay['max_guests']} guests")
        
        # Calculate dynamic total price including cleaning fees and taxes for the requested dates.
        price = pricing.calculate_price_breakdown(stay["price_per_night"], check_in_date, check_out_date)
        st.markdown(f"**\\${stay['price_per_night']}** / night · **\\${price['total_price']:.2f}** total ({total_nights} nights)")

        # Action button columns: 2/3 width for 'View details', 1/3 width for 'Save'
        btn_col1, btn_col2 = st.columns([2, 1])
        with btn_col1:
            if st.button("View details", key=f"details_btn_{stay['id']}", use_container_width=True):
                activity.open_property(stay["id"], "explore")
        with btn_col2:
            is_saved = stay["id"] in saved_ids
            # Toggle heart icon based on whether this property is already bookmarked in MySQL.
            if st.button("❤️ Saved" if is_saved else "🤍 Save", key=f"save_btn_{stay['id']}", use_container_width=True):
                now_saved = database.toggle_saved_listing(user_id, stay["id"])
                activity.log_event(
                    "SAVE_PROPERTY" if now_saved else "UNSAVE_PROPERTY",
                    f"{'Saved' if now_saved else 'Removed'} {stay['title']} {'to' if now_saved else 'from'} wishlist",
                    "property", stay["id"]
                )
                st.rerun()


def render():
    user = auth.current_user()
    destinations = database.get_destinations()
    st.title("Find Your Sanctuary")
    st.caption(f"Villas, chalets, havelis and overwater hideaways across {len(destinations)} destinations worldwide.")

    # Default search dates: check-in 14 days ahead, check-out 4 nights later.
    today = datetime.date.today()
    default_check_in = today + datetime.timedelta(days=14)
    default_check_out = default_check_in + datetime.timedelta(days=4)

    # Destination & Area pickers populated dynamically from MySQL.
    dest_by_name = {}
    dest_labels = {ALL_DESTINATIONS: ALL_DESTINATIONS}
    for d in destinations:
        dest_by_name[d["name"]] = d
        dest_labels[d["name"]] = f"{d['name']}, {d['country']} ({d['property_count']})"
        
    search_col0, search_col1, search_col2, search_col3, search_col4 = st.columns([1.8, 1.4, 1.2, 1.2, 0.8])
    with search_col0:
        destination = st.selectbox("Destination", list(dest_labels.keys()), format_func=dest_labels.get,
                                   help="Pick a destination, or browse all of them.")
    with search_col1:
        # If 'All destinations' is chosen, the area dropdown is disabled.
        if destination == ALL_DESTINATIONS:
            area = st.selectbox("Area", [ALL_AREAS], disabled=True)
        else:
            area = st.selectbox("Area", [ALL_AREAS] + database.get_areas(destination))
    with search_col2:
        check_in_date = st.date_input("Check-in", value=default_check_in, min_value=today)
    with search_col3:
        check_out_date = st.date_input("Check-out", value=default_check_out, min_value=today + datetime.timedelta(days=1))
    with search_col4:
        guests_count = st.number_input("Guests", min_value=1, max_value=12, value=2, step=1)

    # Date sanity check: check-out must be after check-in.
    if check_out_date <= check_in_date:
        st.error("Check-out date must be after check-in date.")
        return

    # Price range slider calibrated from lowest and highest rates in MySQL.
    price_lo, price_hi = database.get_price_bounds()
    slider_lo = (price_lo // 10) * 10
    slider_hi = ((price_hi + 9) // 10) * 10

    # Expandable filters panel
    with st.expander("Filter Options & Preferences", expanded=False):
        filter_col1, filter_col2, filter_col3 = st.columns([1.5, 2, 2])
        with filter_col1:
            selected_category = st.selectbox("Category", ["All Categories"] + database.get_distinct_categories())
        with filter_col2:
            price_range = st.slider("Price per night ($ USD)", min_value=slider_lo, max_value=slider_hi,
                                    value=(slider_lo, slider_hi), step=10)
        with filter_col3:
            st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)
            cb_col1, cb_col2, cb_col3 = st.columns(3)
            with cb_col1:
                filter_pool = st.checkbox("Private pool")
            with cb_col2:
                filter_wifi = st.checkbox("Fast Wi-Fi")
            with cb_col3:
                filter_superhost = st.checkbox("Superhost")

    # Sorting selector
    sort_col1, sort_col2 = st.columns([3, 1])
    with sort_col2:
        sort_choice = st.selectbox("Sort by", ["Recommended", "Price: Low to High", "Price: High to Low", "Highest Rated"])

    # Query all active listings and the user's bookmarked IDs from MySQL.
    all_stays = database.get_all_listings()
    saved_ids = database.get_saved_listing_ids(user["user_id"])
    c_in_str = check_in_date.isoformat()
    c_out_str = check_out_date.isoformat()
    
    # Query IDs of listings that have conflicting confirmed bookings for these dates.
    unavailable = database.get_unavailable_listing_ids(c_in_str, c_out_str)

    # Apply filtering rules sequentially
    results = filter_stays(
        all_stays, destination, area, selected_category, price_range[0], price_range[1],
        filter_pool, filter_wifi, filter_superhost, guests_count, unavailable
    )

    # Apply selected sorting order
    if sort_choice == "Price: Low to High":
        results = sorted(results, key=sort_by_price)
    elif sort_choice == "Price: High to Low":
        results = sorted(results, key=sort_by_price, reverse=True)
    elif sort_choice == "Highest Rated":
        results = sorted(results, key=sort_by_rating, reverse=True)

    # Search Logging:
    # Only record a SEARCH event in MySQL `activity_logs` when search criteria actually change,
    # preventing log spam on simple page reloads.
    search = {
        "destination": destination, "area": area, "check_in": c_in_str, "check_out": c_out_str,
        "guests": int(guests_count), "category": selected_category, "price": list(price_range),
        "pool": filter_pool, "wifi": filter_wifi, "superhost": filter_superhost, "sort": sort_choice
    }
    if st.session_state.get("last_logged_search") != search:
        st.session_state["last_logged_search"] = search
        place = destination if area == ALL_AREAS else f"{area}, {destination}"
        activity.log_event(
            "SEARCH", f"Searched stays: {place}, {len(results)} results", "search", None,
            dict(search, results=len(results))
        )

    with sort_col1:
        st.subheader(f"Showing {len(results)} stays")

    # Destination guide banner shown when a specific destination is selected
    if destination != ALL_DESTINATIONS:
        d = dest_by_name[destination]
        st.info(f"**{d['name']}, {d['country']}** — {d['description']}  \n"
                f"🗓️ Best time to visit: {d['best_season']} · ✈️ {d['nearest_airport']}")

    # Empty results notice
    if len(results) == 0:
        st.info("No stays match your search criteria. Try widening your price range or picking different dates.")
        return

    # Interactive Map View:
    # Structures latitude and longitude into a Pandas DataFrame and renders with st.map.
    map_data = []
    for stay in results:
        map_data.append({"lat": stay["latitude"], "lon": stay["longitude"]})
        
    if destination == ALL_DESTINATIONS:
        zoom = 1  # Global zoom showing all destinations worldwide.
    elif area == ALL_AREAS:
        zoom = dest_by_name[destination]["map_zoom"]  # Regional zoom from database.
    else:
        zoom = 12  # Close neighbourhood zoom.
        
    with st.expander("🗺️ View stays on map", expanded=True):
        st.map(pd.DataFrame(map_data), zoom=zoom)

    st.markdown("---")

    # Render stay cards in a 2-column responsive grid
    total_nights = (check_out_date - check_in_date).days
    for i in range(0, len(results), 2):
        col_left, col_right = st.columns(2)
        with col_left:
            render_stay_card(results[i], check_in_date, check_out_date, total_nights, saved_ids, user["user_id"])
        if i + 1 < len(results):
            with col_right:
                render_stay_card(results[i + 1], check_in_date, check_out_date, total_nights, saved_ids, user["user_id"])