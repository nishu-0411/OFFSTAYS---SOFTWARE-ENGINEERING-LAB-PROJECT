# page_profile.py: User Account Management, Security & Personal Audit Screen.
#
# WHAT THIS FILE DOES:
#   Renders a 4-tab personal management dashboard for the logged-in user:
#     - Tab 1: Profile Details: Allows users to update full name, phone number, city,
#       and country. Email is locked as a disabled primary identifier.
#     - Tab 2: Change Password: A secure form requiring the current password, validating
#       the new password against complexity rules, and updating the PBKDF2 hash and salt.
#     - Tab 3: My Activity Log: A transparent table showing every action this user
#       has performed on OFFSTAYS (queries, stay views, bookings, review submissions).
#     - Tab 4: Login History: Lists all device sessions from `user_sessions`, indicating
#       login time, last activity time, logout time, and highlighting the active session.
#
# WHY THIS STEP IS NECESSARY:
#   Empowers users to manage their personal profile, provides transparency by letting
#   them inspect their own audit logs, and allows monitoring of device logins for account security.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Queries user details, sessions, and activity logs via `database.py`.
#   - Calls `auth.refresh_user()` after profile edits to synchronize `st.session_state["user"]`.
#   - Calls `auth.change_password()` to enforce cryptographic hash updates in MySQL.
#   - Logs `PROFILE_UPDATED` and `PASSWORD_CHANGED` events to `activity_logs`.

import pandas as pd  # Structures database lists into clean tabular DataFrames for st.dataframe.
import streamlit as st  # Streamlit UI framework (tabs, forms, inputs, dataframes, success/error alerts).
import auth  # Contains current user retrieval, password change logic, and phone validation.
import activity  # Logs PROFILE_UPDATED audit events.
import database  # MySQL updates for profiles, password hashes, sessions, and activity rows.


def session_status(row):
    # WHAT: Determines the display label for each session row in the login history table.
    # HOW:  Checks if the session_id matches the active session in `st.session_state`.
    if row["session_id"] == st.session_state.get("session_id"):
        return "This session"
    if row["is_active"] == 1:
        return "Not logged out"
    return "Logged out"


def render():
    user = auth.current_user()
    st.title("My Profile")
    st.caption(f"#USR-{user['user_id']:04d} · {user['email']} · Member since {str(user.get('created_at') or '')[:10]}")

    # Check for any flash message carried over after a profile update
    flash = st.session_state.pop("profile_flash", None)
    if flash:
        st.success(flash)

    # 4 distinct tabs organizing account settings, security, and audit trails
    tab_details, tab_password, tab_activity, tab_sessions = st.tabs([
        "Profile details",
        "Change password",
        "My activity log",
        "Login history"
    ])

    # ---------------- TAB 1: PROFILE DETAILS
    with tab_details:
        with st.form("profile_form"):
            full_name = st.text_input("Full name", value=user["full_name"])
            # Email cannot be edited because it is our unique account identifier in MySQL
            st.text_input("Email (cannot be changed)", value=user["email"], disabled=True)
            phone = st.text_input("Phone", value=user.get("phone") or "")
            c1, c2 = st.columns(2)
            with c1:
                city = st.text_input("City", value=user.get("city") or "")
            with c2:
                country = st.text_input("Country", value=user.get("country") or "")
            save = st.form_submit_button("Save changes")

        if save:
            # Validate phone number formatting
            phone_error = auth.validate_phone(phone.strip())
            if len(full_name.strip()) < 2:
                st.error("Please enter your full name.")
            elif phone_error:
                st.error(phone_error)
            else:
                # Track what changed so we can record an audit trail
                changed = {}
                for field, new_value in (
                    ("full_name", full_name.strip()),
                    ("phone", phone.strip()),
                    ("city", city.strip()),
                    ("country", country.strip())
                ):
                    if (user.get(field) or "") != new_value:
                        changed[field] = {"from": user.get(field), "to": new_value}
                        
                # Update database record in MySQL
                database.update_profile(user["user_id"], full_name.strip(), phone.strip(), city.strip(), country.strip())
                
                # Log audit event with details of which fields changed
                activity.log_event("PROFILE_UPDATED", "Updated profile details", "user", user["user_id"], {"changed": changed})
                
                # Refresh session state user dictionary so sidebar reflects the updated name immediately
                auth.refresh_user()
                st.session_state["current_page"] = "profile"
                st.session_state["profile_flash"] = "Profile updated."
                st.rerun()

    # ---------------- TAB 2: CHANGE PASSWORD
    with tab_password:
        with st.form("password_form", clear_on_submit=True):
            current = st.text_input("Current password", type="password")
            new = st.text_input(
                "New password",
                type="password",
                help="At least 8 characters, with a letter, a number and a special character."
            )
            confirm = st.text_input("Confirm new password", type="password")
            change = st.form_submit_button("Update password")

        if change:
            # Delegate password verification and PBKDF2 re-hashing to auth.py
            ok, message = auth.change_password(current, new, confirm)
            if ok:
                st.success(message)
            else:
                st.error(message)

    # ---------------- TAB 3: PERSONAL ACTIVITY LOG
    with tab_activity:
        st.caption("Every action you take on OFFSTAYS is recorded in the `activity_logs` table.")
        rows = database.get_user_activity(user["user_id"], limit=200)
        if rows:
            df = pd.DataFrame(rows)[["created_at", "activity_type", "description", "status"]]
            # Clean ISO timestamps into readable date-time strings
            df["created_at"] = df["created_at"].str.replace("T", " ")
            df.columns = ["When", "Activity", "Description", "Status"]
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.info("No activity recorded yet.")

    # ---------------- TAB 4: LOGIN SESSION HISTORY
    with tab_sessions:
        st.caption("A chronological record of device logins and session lifetimes stored in `user_sessions`.")
        sessions = database.get_user_sessions(user["user_id"])
        if sessions:
            df = pd.DataFrame(sessions)
            df["status"] = df.apply(session_status, axis=1)
            df = df[["session_id", "login_at", "last_activity_at", "logout_at", "status"]]
            for col in ("login_at", "last_activity_at", "logout_at"):
                df[col] = df[col].fillna("-").astype(str).str.replace("T", " ")
            df.columns = ["Session", "Logged in", "Last activity", "Logged out", "Status"]
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.info("No login history yet.")
