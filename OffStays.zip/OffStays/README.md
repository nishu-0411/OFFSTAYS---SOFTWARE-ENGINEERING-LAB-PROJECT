# OFFSTAYS 🏡 — Luxury Stay Booking Platform

OFFSTAYS is a luxury stay-booking web platform with **100 boutique properties across 14 destinations in 9 countries**, built with **Python**, **Streamlit** and **MySQL 8**. It has multi-user **login / registration**, and **every activity is recorded in the database**. Payments, host replies and refunds are simulated.

---

## Project Structure

```text
OffStays/
├── app.py                    # Entry point: DB check, login gate, sidebar, page routing
├── auth.py                   # Register / login / logout, PBKDF2 password hashing, lockout
├── activity.py               # log_event(), go_to(), open_property() helpers
├── database.py               # MySQL data layer (PyMySQL) - every query is parameterized
├── db_config.py              # <-- put your MySQL password here
├── pricing.py                # Price breakdown and night counting
├── page_login.py             # Log in / Create account screen
├── page_explore.py           # Search, filters, map, stay cards
├── page_details.py           # Gallery, amenities, reviews, reserve widget
├── page_checkout.py          # Demo card / UPI payment with validation
├── page_messages.py          # Guest-host chat with automated replies
├── page_trips.py             # Upcoming, past, saved stays, notifications, invoices, cancel
├── page_host.py              # Become a Host application
├── page_profile.py           # Edit profile, change password, my activity, login history
├── page_admin.py             # Admin dashboard: metrics, full activity log, users
├── setup_database.py         # One-command DB setup (alternative to Workbench)
├── requirements.txt
├── sql/
│   ├── 01_schema.sql         # CREATE DATABASE + 16 tables, keys, constraints
│   ├── 02_seed_data.sql      # INSERTs for all sample rows (recommended)
│   ├── 03_load_csv.sql       # Alternative: LOAD DATA LOCAL INFILE from data/*.csv
│   └── 04_views_and_reports.sql  # 5 views + ready-made report queries
├── data/                     # Sample CSVs (01_users.csv ... 16_activity_logs.csv)
├── tools/
│   └── csv_to_sql.py         # Rebuilds 02/03 SQL from the CSVs after you edit them
├── TESTING.md                # How to run the tests + test report
└── tests/                    # 205 automated tests (Python unittest)
    ├── unit/                 # one function at a time, no MySQL needed
    ├── integration_mocked/   # real modules together, MySQL replaced by fakes
    ├── integration_db/       # real modules + separate MySQL test database
    ├── support/              # fakes and the safe test-database helper
    └── test_database.example.ini   # template for the test-database settings
```

---

## Step-by-Step Setup

### 1. Install the software (one time)

| Software | Version | Where |
|---|---|---|
| Python | 3.10 – 3.13 recommended | python.org |
| MySQL Server | 8.0 or newer | dev.mysql.com/downloads/mysql (Windows: MySQL Installer) |
| MySQL Workbench | 8.0 | dev.mysql.com/downloads/workbench |

During the MySQL Server install, choose a **root password** and remember it.

### 2. Create the database in MySQL Workbench

1. Open Workbench → click your **Local instance (root)** connection → enter the root password.
2. **File → Open SQL Script… → `sql/01_schema.sql`** → click the ⚡ (Execute all) button.
3. **File → Open SQL Script… → `sql/02_seed_data.sql`** → ⚡. The last result grid shows the row count of every table.
4. **File → Open SQL Script… → `sql/04_views_and_reports.sql`** → ⚡ (optional, adds views and reports).
5. Click the 🔄 refresh icon in the **Schemas** panel. You will see `offstays` with 16 tables.
   (If you also have an older `offstaysdb` schema, ignore it. The app only uses `offstays`.)

> Shortcut: after step 4 below you can run `python setup_database.py` instead, which runs the same three scripts.

### 3. Tell the app your MySQL password

Open `db_config.py` and change:

```python
DB_PASSWORD = os.environ.get("OFFSTAYS_DB_PASSWORD", "your_mysql_password")
```

Replace `your_mysql_password` with your MySQL root password.

### 4. Create a virtual environment and install dependencies

**Windows (Command Prompt)**
```cmd
cd C:\path\to\OffStays
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

**macOS / Linux**
```bash
cd /path/to/OffStays
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Dependencies (`requirements.txt`):

| Package | Why |
|---|---|
| `streamlit>=1.35,<1.49` | Web UI |
| `pandas>=2.0,<3` | Map data and tables |
| `PyMySQL>=1.1` | MySQL driver (pure Python) |
| `cryptography>=42` | Needed by PyMySQL for MySQL 8's default `caching_sha2_password` login |

> Do **not** reuse the old `venv/` folder from another computer. Always create a fresh one.

### 5. Run

```bash
streamlit run app.py
```

Open http://localhost:8501.

> Whenever you edit `db_config.py` (or any `.py` file), stop the app with `Ctrl + C` and run `streamlit run app.py` again. A running app keeps the old settings.

### 6. Log in

| Role | Email | Password |
|---|---|---|
| Guest (demo data) | `sarah.vance@example.com` | `Password@123` |
| Admin | `admin@offstays.com` | `Admin@123` |
| Any other sample user | see `data/01_users.csv` | `Password@123` |

Or click **Create account** to register a new user.

### 7. Watch the activity being recorded

In Workbench run:

```sql
USE offstays;
SELECT * FROM vw_activity_feed ORDER BY log_id DESC LIMIT 50;
```

Log in as the admin and open **🛡️ Admin Dashboard** to see the same feed inside the app.

### 8. Reset everything to the sample data

Re-run `sql/01_schema.sql` + `sql/02_seed_data.sql` in Workbench, or `python setup_database.py`.

---

## Running the Tests

From the project folder, with the virtual environment active:

```bash
python -m unittest discover -s tests -t .
```

This runs the unit tests and the mocked integration tests (no database needed). The real-database
tests are skipped until you set up the separate `offstays_test` database. See **TESTING.md** for the
setup, the safety rules, and the full test report.

---

## Destinations (14)

| Destination | Country | Properties | Areas |
|---|---|---|---|
| Bali | Indonesia | 15 | Amed, Bedugul, Canggu, Munduk, Nusa Dua, Pajangan, Seminyak, Sidemen, Ubud, Uluwatu |
| Goa | India | 8 | Anjuna, Assagao, Candolim, Palolem, Vagator |
| Kerala | India | 7 | Alleppey, Fort Kochi, Kumarakom, Munnar, Varkala, Wayanad |
| Manali | India | 6 | Naggar, Old Manali, Solang Valley, Vashisht |
| Udaipur | India | 6 | Badi Lake, Fateh Sagar, Lake Pichola, Old City |
| Rishikesh | India | 5 | Laxman Jhula, Shivpuri, Tapovan |
| Maldives | Maldives | 7 | Ari Atoll, Baa Atoll, North Malé Atoll, South Malé Atoll |
| Phuket | Thailand | 7 | Cape Yamu, Kamala, Kata, Patong, Rawai, Surin |
| Dubai | UAE | 7 | Al Marmoom Desert, Downtown, Dubai Marina, Jumeirah, Palm Jumeirah |
| Santorini | Greece | 7 | Fira, Imerovigli, Oia, Pyrgos |
| Swiss Alps | Switzerland | 7 | Grindelwald, Interlaken, St. Moritz, Verbier, Zermatt |
| Kyoto | Japan | 6 | Arashiyama, Gion, Higashiyama, Ohara |
| Amalfi Coast | Italy | 6 | Amalfi, Positano, Ravello, Sorrento |
| Tulum | Mexico | 6 | Akumal, La Veleta, Tulum Beach |

Property categories: Amazing pools, Luxury Villas, Countryside, Heritage Stays, Beachfront, Mountain Chalets, Eco Cabins, Tropical, Overwater Villas. Prices range from $50 to about $1,100 per night (USD).

**Photos:** every property reuses the 21 Unsplash photos from the original app (villas, pools, cabins, interiors), so all images load reliably. To give a destination its own photos, replace the `image_url` values in `data/05_property_images.csv`, run `python tools/csv_to_sql.py`, and reload the database.

## Database Schema (16 tables)

| Table | Rows | Purpose |
|---|---|---|
| `users` | 99 | All accounts (1 admin, 50 guests, 48 hosts) with hashed passwords |
| `destinations` | 14 | Places OFFSTAYS operates in: country, airport, best season, map zoom |
| `hosts` | 48 | Host profile, 1-to-1 with a `users` row, linked to a home destination |
| `properties` | 100 | Stays: destination + area, price, rooms, scores |
| `property_images` | 354 | Photo gallery per property |
| `amenities` | 64 | Master amenity list with categories |
| `property_amenities` | ~890 | Many-to-many bridge (+ property-specific detail text) |
| `bookings` | 140 | Reservations (Confirmed / Completed / Cancelled) |
| `payments` | 140 | One simulated payment per booking (only last 4 digits stored) |
| `reviews` | 90 | Guest reviews (one per booking) |
| `messages` | ~470 | Guest ↔ host chat threads |
| `notifications` | ~370 | In-app alerts per user |
| `saved_listings` | 80 | Wishlist (user × property) |
| `host_applications` | 50 | "Become a Host" submissions |
| `user_sessions` | ~240 | One row per login (login / last activity / logout time) |
| `activity_logs` | ~1,470 | Audit trail of every action |

### Relationships

```text
destinations 1──* properties        destinations 1──* hosts
users 1──1 hosts 1──* properties 1──* property_images
                         properties *──* amenities   (via property_amenities)
users 1──* bookings *──1 properties
bookings 1──1 payments
bookings 1──0..1 reviews *──1 properties
users 1──* messages / notifications / saved_listings / user_sessions / activity_logs
user_sessions 1──* activity_logs
```

### What gets logged in `activity_logs`

| Area | activity_type values |
|---|---|
| Account | `REGISTER`, `REGISTER_FAILED`, `LOGIN`, `LOGIN_FAILED`, `LOGIN_BLOCKED`, `LOGOUT`, `PROFILE_UPDATED`, `PASSWORD_CHANGED`, `PASSWORD_CHANGE_FAILED` |
| Browsing | `PAGE_VIEW`, `SEARCH`, `VIEW_PROPERTY`, `SAVE_PROPERTY`, `UNSAVE_PROPERTY`, `SHARE_PROPERTY` |
| Booking | `START_RESERVATION`, `RESERVATION_UNAVAILABLE`, `PAYMENT_FAILED`, `PAYMENT_SUCCESS`, `BOOKING_CREATED`, `BOOKING_FAILED`, `BOOKING_CANCELLED`, `INVOICE_DOWNLOADED` |
| Engagement | `OPEN_CHAT`, `MESSAGE_SENT`, `REVIEW_SUBMITTED`, `NOTIFICATION_READ`, `NOTIFICATIONS_READ_ALL`, `HOST_APPLICATION` |
| Admin | `EXPORT_ACTIVITY_LOG` |

Each row stores the user, the login session, the affected entity (e.g. `booking` / `42`), a description, a JSON `details` column and `SUCCESS` / `FAILED`. Passwords and card numbers are never logged.

---

## Security Features (good viva points)

- **Password hashing:** PBKDF2-HMAC-SHA256, 100,000 iterations, 16-byte random salt per user (`auth.hash_password`). Comparison uses `hmac.compare_digest` (constant time).
- **Password rules:** at least 8 characters, with a letter, a number and a special character.
- **Brute-force protection:** 5 failed logins within 15 minutes → login blocked (`LOGIN_BLOCKED`).
- **Generic error message:** "Incorrect email or password" never reveals whether the email exists.
- **SQL injection:** every query uses `%s` placeholders. PyMySQL escapes the values separately from the SQL text.
- **Data isolation:** every booking / message / notification query filters by `user_id`, so one guest can never see another guest's keyless PIN.
- **Race-condition safe booking:** `SELECT ... FOR UPDATE` locks the property row inside the booking transaction, then re-checks availability before inserting.
- **Atomic transactions:** booking + payment + messages + notifications + logs commit together or roll back together.
- **Payment data minimization:** only the card's last 4 digits or a masked UPI handle are stored.

---

## Viva Q&A (updated)

1. **Why MySQL instead of SQLite?** Multiple users log in at the same time, so we need a real client-server database with row-level locking, foreign keys enforced by default, and a GUI (Workbench) to inspect live data.
2. **How does login work?** `auth.login_user()` looks up the email, re-hashes the typed password with the stored salt and compares. On success it inserts a `user_sessions` row, updates `last_login_at`, logs `LOGIN` and stores a safe user dict in `st.session_state["user"]`.
3. **Why salt the password?** The same password gives a different hash for every user, which defeats pre-computed "rainbow tables".
4. **How is double-booking prevented?** Overlap rule `existing.check_in < new_check_out AND existing.check_out > new_check_in`, checked on Explore, on Reserve, and again inside the locked transaction.
5. **Why is `rating` stored in `properties` when reviews exist?** It is a cached aggregate. On a new review we update it with a running average, `(rating × count + new) / (count + 1)`, so historic counts (e.g. 142 reviews) are kept.
6. **What does Streamlit session state hold now?** `user`, `session_id`, `current_page`, `selected_listing_id`, `pending_booking`, `chat_listing_id`, and the last logged search.
7. **What happens on browser refresh?** Streamlit starts a new session, so the user has to log in again. The old session row stays `is_active = 1` with its last-activity time.
8. **Why are sidebar button labels fixed (no "(3)" badge in the label)?** Streamlit identifies a widget partly by its label. If the label changes between reruns, the click is lost. So the counts are shown in a separate line that is filled at the end of the script.

---

## Feature-to-Code Mapping

| Feature | File | Function |
|---|---|---|
| Registration | `auth.py`, `database.py` | `register_user()`, `create_user()` |
| Login / lockout / logout | `auth.py` | `login_user()`, `logout_user()` |
| Activity logging | `activity.py`, `database.py` | `log_event()`, `log_activity()` |
| Stay filtering (destination → area → filters) | `page_explore.py` | `filter_stays()`, `get_destinations()`, `get_areas()` |
| Price breakdown | `pricing.py` | `calculate_price_breakdown()` |
| Atomic booking | `database.py` | `create_booking_transaction()` |
| Cancellation + refund | `page_trips.py`, `database.py` | `cancel_booking()` |
| Reviews | `database.py` | `add_review()` |
| Automated host replies | `page_messages.py` | `get_automated_host_reply()` |
| Admin activity feed | `page_admin.py` | `get_activity_logs()` |

---

## Troubleshooting

| Error / Issue | Cause | Fix |
|---|---|---|
| App says the database is not ready right after you changed `db_config.py` | The running app still has the old settings | `Ctrl + C`, then `streamlit run app.py` again |
| App shows "MySQL rejected the username/password" (error 1045) | Wrong password, user or port in `db_config.py` | Copy Hostname / Port / Username from Workbench → Database → Manage Connections, and the password you use there |
| "Cannot reach the MySQL server" (error 2003) | MySQL service not running | Windows: Services → start **MySQL80**. macOS: System Settings → MySQL → Start |
| "Database `offstays` does not exist" (1049) / "Tables are missing" (1146) | SQL scripts not run | Run `01_schema.sql` then `02_seed_data.sql` |
| `RuntimeError: 'cryptography' package is required for sha256_password or caching_sha2_password` | Missing dependency | `pip install cryptography` |
| `ModuleNotFoundError: No module named 'pymysql'` | venv not active / deps missing | Activate venv, `pip install -r requirements.txt` |
| `03_load_csv.sql`: Error 3948 / 2068 "Loading local data is disabled" | `local_infile` off | Use `02_seed_data.sql` instead, or `SET GLOBAL local_infile = 1;` and add `OPT_LOCAL_INFILE=1` under connection → Advanced → Others |
| Workbench: Error 2013 "Lost connection" while running 02_seed_data.sql | Timeout too short | Edit → Preferences → SQL Editor → raise DBMS connection read timeout to 600 |
| "Too many failed attempts" | Lockout after 5 wrong passwords | Wait 15 minutes (the failed attempts stay in `activity_logs` as evidence) |
| Port 8501 in use | Another Streamlit running | `streamlit run app.py --server.port 8502` |
| Images are empty frames | No internet (Unsplash / ui-avatars) | Connect to the internet |

---

## Editing the Sample Data

1. Edit any CSV in `data/` (keep the header row and the IDs consistent).
2. Run `python tools/csv_to_sql.py` to rebuild `sql/02_seed_data.sql` and `sql/03_load_csv.sql` (with your real folder path).
3. Re-run `01_schema.sql` and `02_seed_data.sql`.
