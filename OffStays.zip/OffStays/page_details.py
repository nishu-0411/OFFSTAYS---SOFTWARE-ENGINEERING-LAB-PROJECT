# page_details.py: Property Details & Reservation Widget Screen.
#
# WHAT THIS FILE DOES:
#   Renders the comprehensive property details screen for a selected sanctuary:
#     1. Interactive photo carousel cycling through high-resolution property images.
#     2. Superhost identification, response metrics, and capacity parameters.
#     3. Curated stay highlights (e.g. dedicated workspace, self check-in).
#     4. Full architectural description and complete amenity checklist.
#     5. Granular rating score breakdowns (cleanliness, accuracy, communication, etc.).
#     6. Single-property location map and nearest airport travel guide.
#     7. Authenticated past guest reviews.
#     8. An interactive, sticky reservation card that computes live pricing, calculates
#        free cancellation deadlines, and initiates checkout.
#
# WHY THIS STEP IS NECESSARY:
#   Provides guests with the full context needed to evaluate a luxury booking and validates
#   date availability against MySQL before transitioning to the payment screen.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Reads `st.session_state["selected_listing_id"]` set by Explore or Wishlist.
#   - Queries MySQL via `database.get_listing_by_id()` and `database.get_listing_reviews()`.
#   - Uses `pricing.calculate_price_breakdown()` to display real-time itemized pricing.
#   - Stages reservation parameters into `st.session_state["pending_booking"]` and routes to Checkout.

import streamlit as st  # Streamlit UI framework (handles layout, columns, widgets, and images).
import pandas as pd  # Structures coordinates for the property location map.
import datetime  # Date math for cancellation policy deadlines and calendar pickers.
import database  # Database queries for listing details, reviews, wishlists, and availability.
import pricing  # Live price calculation module.
import activity  # Audit logging (VIEW_PROPERTY, SAVE_PROPERTY, START_RESERVATION) and navigation.
import auth  # Retrieves the current authenticated user.


def render():
    user = auth.current_user()
    
    # Check if a property ID has been stored in session state.
    # If not (e.g., direct navigation), prompt the user to return to Explore.
    listing_id = st.session_state.get("selected_listing_id")
    if not listing_id:
        st.warning("No property selected.")
        if st.button("← Back to Explore"):
            activity.go_to("explore")
        return

    # Fetch fresh listing record from MySQL by ID.
    listing = database.get_listing_by_id(listing_id)
    if not listing:
        st.error("Property not found.")
        if st.button("← Back to Explore"):
            activity.go_to("explore")
        return

    # Back navigation and top action row: [Back Button, Save Bookmark, Share Link]
    top_nav_col, save_col, share_col = st.columns([6, 1, 1])
    with top_nav_col:
        if st.button("← Back to results"):
            activity.go_to("explore")
    with save_col:
        # Check if currently bookmarked in the user's wishlist
        saved_ids = database.get_saved_listing_ids(user["user_id"])
        is_saved = listing["id"] in saved_ids
        save_btn_label = "❤️ Saved" if is_saved else "🤍 Save"
        if st.button(save_btn_label, key="details_save_toggle"):
            now_saved = database.toggle_saved_listing(user["user_id"], listing["id"])
            activity.log_event(
                "SAVE_PROPERTY" if now_saved else "UNSAVE_PROPERTY",
                f"{'Saved' if now_saved else 'Removed'} {listing['title']} {'to' if now_saved else 'from'} wishlist",
                "property", listing["id"], {"source": "details"}
            )
            st.rerun()
    with share_col:
        # Toggle a copyable share link box (Streamlit cannot directly copy to system clipboard).
        if st.button("🔗 Share"):
            st.session_state["show_share_modal"] = not st.session_state.get("show_share_modal", False)
            if st.session_state["show_share_modal"]:
                activity.log_event("SHARE_PROPERTY", f"Opened share link for {listing['title']}", "property", listing["id"])

    # If share was clicked, display the copyable URL
    if st.session_state.get("show_share_modal", False):
        st.info("Copy the demo link below to share this stay:")
        st.code(f"https://offstays.demo/stays/{listing['id']}", language="text")

    # Header section: Title, Rating, Review Count, Badge, and Location
    st.title(listing["title"])
    st.write(f"★ **{listing['rating']:.2f}** ({listing['review_count']} reviews) · **{listing['badge']}** · {listing['location']}")

    # Photo Gallery Carousel:
    # Cycles through all photo URLs stored for this property in MySQL `property_images`.
    photos = listing["image_urls"].split("|")
    total_photos = len(photos)
    current_idx = st.session_state.get("details_photo_index", 0)
    
    # Ensure current photo index stays within valid array bounds
    if current_idx >= total_photos:
        current_idx = 0
        st.session_state["details_photo_index"] = 0

    # Display large current photo
    st.image(photos[current_idx], use_container_width=True)

    # Carousel previous and next buttons
    p_col1, p_col2, p_col3 = st.columns([1, 4, 1])
    with p_col1:
        if st.button("◀ Previous Photo", use_container_width=True):
            st.session_state["details_photo_index"] = (current_idx - 1) % total_photos
            st.rerun()
    with p_col2:
        st.markdown(f"<p style='text-align:center;'>Photo {current_idx + 1} of {total_photos}</p>", unsafe_allow_html=True)
    with p_col3:
        if st.button("Next Photo ▶", use_container_width=True):
            st.session_state["details_photo_index"] = (current_idx + 1) % total_photos
            st.rerun()

    st.markdown("---")

    # Split screen: Left column (Description & Amenities), Right column (Sticky Booking Card)
    left_col, right_col = st.columns([2, 1])

    with left_col:
        # Host Identity Row
        host_c1, host_c2 = st.columns([1, 4])
        with host_c1:
            st.image(listing["host_avatar_url"], width=70)
        with host_c2:
            st.markdown(f"### Entire sanctuary hosted by {listing['host_name']}")
            st.caption(f"{listing['max_guests']} guests · {listing['bedrooms']} bedrooms · {listing['beds']} beds · {listing['baths']} baths")
            if listing["host_superhost"] == 1:
                st.markdown(f"⭐ **Superhost** · Responds {listing['host_response_time']} ({listing['host_response_rate']} response rate)")

        st.markdown("---")

        # Stay Highlights Section (e.g. Dedicated workspace, Self check-in)
        raw_highlights = listing["highlights"].strip()
        if raw_highlights:
            st.markdown("### Stay Highlights")
            highlights_list = raw_highlights.split("|")
            for h in highlights_list:
                if "::" in h:
                    h_title, h_desc = h.split("::", 1)
                    st.markdown(f"**{h_title.strip()}** — {h_desc.strip()}")
            st.markdown("---")

        # Detailed Sanctuary Description
        st.markdown("### About this Sanctuary")
        st.write(listing["description"])
        st.markdown("---")

        # Full Amenities list inside an expander
        with st.expander("Show all amenities", expanded=True):
            amenities_list = listing["amenities"].split("|")
            am_col1, am_col2 = st.columns(2)
            for i, am in enumerate(amenities_list):
                if i % 2 == 0:
                    am_col1.write(f"✓ {am.strip()}")
                else:
                    am_col2.write(f"✓ {am.strip()}")

        st.markdown("---")

        # Rating Category Scores Breakdown
        st.markdown("### Guest Rating Breakdown")
        score_c1, score_c2, score_c3 = st.columns(3)
        with score_c1:
            st.metric("Cleanliness", f"{listing['score_cleanliness']:.1f} / 5.0")
            st.metric("Communication", f"{listing['score_communication']:.1f} / 5.0")
        with score_c2:
            st.metric("Accuracy", f"{listing['score_accuracy']:.1f} / 5.0")
            st.metric("Location", f"{listing['score_location']:.1f} / 5.0")
        with score_c3:
            st.metric("Check-in", f"{listing['score_checkin']:.1f} / 5.0")
            st.metric("Value", f"{listing['score_value']:.1f} / 5.0")

        st.markdown("---")

        # Property Location Map & Travel Info
        st.markdown("### Where you will be")
        st.caption(f"📍 {listing['location']}")
        st.write(listing["destination_description"])
        st.write(f"🗓️ **Best time to visit:** {listing['best_season']}  \n✈️ **Nearest airport:** {listing['nearest_airport']}")
        df_single = pd.DataFrame([{"lat": listing["latitude"], "lon": listing["longitude"]}])
        st.map(df_single, zoom=12)

        st.markdown("---")

        # Reviews Section from Past Guests
        st.markdown("### Reviews from Past Guests")
        reviews = database.get_listing_reviews(listing["id"])
        if len(reviews) == 0:
            st.info("No reviews yet for this property. Be the first to stay and review!")
        else:
            for rev in reviews:
                with st.container(border=True):
                    st.markdown(f"**{rev['author']}** · {rev['location']} · *{rev['review_date']}*")
                    st.write(f"Rating: {'★' * int(rev['rating'])} ({rev['rating']:.1f})")
                    st.write(rev["comment"])

    with right_col:
        # Reservation Interactive Card
        with st.container(border=True):
            st.markdown(
                f"## **\\${listing['price_per_night']}** <span style='font-size: 16px; font-weight: normal;'>/ night</span>",
                unsafe_allow_html=True
            )
            st.caption(f"★ {listing['rating']:.2f} · {listing['review_count']} reviews")
            st.markdown("---")

            # Date pickers initialized to a standard 4-night window 14 days ahead
            today = datetime.date.today()
            def_in = today + datetime.timedelta(days=14)
            def_out = def_in + datetime.timedelta(days=4)

            booking_check_in = st.date_input("Check-in Date", value=def_in, min_value=today, key="details_check_in")
            booking_check_out = st.date_input("Check-out Date", value=def_out, min_value=today + datetime.timedelta(days=1), key="details_check_out")

            booking_guests = st.number_input(
                "Guests",
                min_value=1,
                max_value=listing["max_guests"],
                value=min(2, listing["max_guests"]),
                step=1,
                key="details_guests"
            )

            # Validate date order
            if booking_check_out <= booking_check_in:
                st.error("Check-out must be after check-in.")
                return

            # Live pricing calculation from pricing.py
            price_details = pricing.calculate_price_breakdown(listing["price_per_night"], booking_check_in, booking_check_out)

            st.markdown("---")
            # Itemized price breakdown
            st.write(f"\\${listing['price_per_night']} × {price_details['nights']} nights: **\\${price_details['stay_cost']:.2f}**")
            st.write(f"Cleaning fee: **\\${price_details['cleaning_fee']:.2f}**")
            st.write(f"OffStays service fee: **\\${price_details['service_fee']:.2f}**")
            st.write(f"Occupancy taxes (10%): **\\${price_details['taxes']:.2f}**")
            st.markdown("---")
            st.markdown(f"### Total: **\\${price_details['total_price']:.2f}**")

            # Calculate real cancellation deadline (48 hours before check-in)
            cancel_deadline = booking_check_in - datetime.timedelta(days=2)
            st.caption(f"🛡️ **Free cancellation** until {cancel_deadline.strftime('%B %d, %Y')} (48 hours before check-in).")

            st.markdown("<br>", unsafe_allow_html=True)

            # Reserve Button
            if st.button("Reserve Stay", use_container_width=True):
                # Verify date availability in MySQL for this specific property
                in_str = booking_check_in.isoformat()
                out_str = booking_check_out.isoformat()
                if not database.is_listing_available(listing["id"], in_str, out_str):
                    activity.log_event(
                        "RESERVATION_UNAVAILABLE", f"Tried unavailable dates for {listing['title']}",
                        "property", listing["id"], {"check_in": in_str, "check_out": out_str}, status="FAILED"
                    )
                    st.error("This property is already booked for the selected dates. Please choose different dates.")
                    return

                # Stage pending booking dictionary in session state for Checkout
                st.session_state["pending_booking"] = {
                    "listing_id": listing["id"],
                    "listing_title": listing["title"],
                    "listing_location": listing["location"],
                    "host_name": listing["host_name"],
                    "price_per_night": listing["price_per_night"],
                    "check_in": in_str,
                    "check_out": out_str,
                    "nights": price_details["nights"],
                    "guests": booking_guests,
                    "stay_cost": price_details["stay_cost"],
                    "cleaning_fee": price_details["cleaning_fee"],
                    "service_fee": price_details["service_fee"],
                    "taxes": price_details["taxes"],
                    "total_price": price_details["total_price"]
                }
                activity.log_event(
                    "START_RESERVATION", f"Started reservation for {listing['title']}", "property",
                    listing["id"], {"check_in": in_str, "check_out": out_str, "guests": int(booking_guests),
                                    "total": price_details["total_price"]}
                )
                # Navigate to checkout page and rerun
                activity.go_to("checkout")