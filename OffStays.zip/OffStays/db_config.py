# db_config.py: Central Database Configuration Module for OFFSTAYS.
#
# WHAT THIS FILE DOES:
#   This file stores the MySQL server connection settings (host, port, username,
#   password, and database name) so the entire application knows where and how
#   to connect to our MySQL database.
#
# WHY THIS STEP IS NECESSARY:
#   Instead of hardcoding connection credentials across multiple files or inside
#   individual SQL queries, storing them in this single configuration file ensures
#   that if your database password, port, or host changes, you only update it once here.
#
# HOW IT WORKS:
#   1. It first checks Python's `os.environ` to see if custom environment variables
#      exist on the operating system.
#   2. If no environment variables are detected, it falls back to sensible local
#      development defaults (e.g., localhost:3306, user 'root').
#   3. Other modules like `database.py` and `setup_database.py` import these variables
#      directly when opening database connections.

import os  # Standard Python module used to read system environment variables.

# Hostname: Defaults to "localhost" because the MySQL server is running locally on the same computer.
# If deploying to a cloud server, you can set the OFFSTAYS_DB_HOST environment variable instead.
DB_HOST = os.environ.get("OFFSTAYS_DB_HOST", "localhost")

# Port: MySQL's default network port is 3306.
# We wrap this in int() because the PyMySQL connection driver expects an integer port number.
DB_PORT = int(os.environ.get("OFFSTAYS_DB_PORT", "3306"))

# Username: 'root' is the administrative superuser created by default during MySQL installation.
DB_USER = os.environ.get("OFFSTAYS_DB_USER", "root")

# Password: Change "your_mysql_password" to match the root password you created in MySQL Workbench.
# This can also be set via the OFFSTAYS_DB_PASSWORD environment variable for security.
DB_PASSWORD = os.environ.get("OFFSTAYS_DB_PASSWORD", "your_mysql_password")

# Database Schema Name: Must match the database created by our schema scripts in sql/01_schema.sql.
DB_NAME = "offstays"