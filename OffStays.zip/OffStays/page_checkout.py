# page_checkout.py: Checkout & Simulated Payment Processing Screen.
#
# WHAT THIS FILE DOES:
#   Renders the final booking confirmation and payment screen:
#     1. Displays a prominent demo environment disclaimer to ensure academic clarity.
#     2. Presents a choice of simulated payment instruments (Demo Card or Demo UPI).
#     3. Enforces client-side validation rules (card digit count, expiry dates, CVV, UPI format).
#     4. Captures an optional personal note/arrival time for the host.
#     5. Requires mandatory acceptance of house rules and cancellation policies.
#     6. Triggers an atomic multi-table transaction in MySQL via `database.create_booking_transaction()`.
#     7. Displays confirmation balloons, generates a unique booking reference (#OFS-XXXXX),
#        and clears temporary session storage.
#
# WHY THIS STEP IS NECESSARY:
#   This module turns intent into a confirmed reservation. It practices strict data minimization
#   aligned with PCI-DSS guidelines (storing only masked handles or the last 4 card digits),
#   and coordinates atomic insertion across bookings, payments, chat messages, notifications,
#   and audit logs.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Reads `st.session_state["pending_booking"]` populated by `page_details.py`.
#   - Calls `database.create_booking_transaction()` to commit the booking in MySQL.
#   - Sets `st.session_state["chat_listing_id"]` so the Messages tab opens this host thread.
#   - Logs `PAYMENT_FAILED` on input errors or `PAYMENT_SUCCESS` and `BOOKING_CREATED` upon completion.

import streamlit as st  # Streamlit UI framework (radio selectors, input boxes, text areas, columns).
import datetime  # Standard module for calendar comparisons (validating card expiration year/month).
import time  # Simulates network authorization delay during bank processing.
import database  # MySQL transaction engine: commits booking, payment, notifications, and logs atomically.
import activity  # Audit logging (PAYMENT_FAILED) and navigation helpers.
import auth  # Retrieves current authenticated user dictionary.


def payment_failed(reason, method):
    # WHAT: Displays an error alert to the user and logs the failed payment attempt in MySQL.
    # WHY:  Maintains security audit logging without ever recording raw credit card numbers.
    activity.log_event(
        "PAYMENT_FAILED", f"Payment validation failed: {reason}", "payment", None,
        {"method": method, "reason": reason}, status="FAILED"
    )
    st.error(reason)


def validate_payment_details(pay_method, card_name, card_num, card_exp, card_cvv, upi_id, today):
    # WHAT: Checks the demo card / UPI fields and builds the minimal payment record.
    # RETURNS: (error_message, None) when something is wrong, or (None, payment_info) when valid.
    # WHY:  Kept separate from render() so the payment rules can be unit tested without the UI.
    payment_info = {"method": pay_method}
    if pay_method == "Card (demo)":
        if not card_name.strip():
            return "Please enter the cardholder's name.", None
        clean_card = card_num.replace(" ", "").strip()
        if len(clean_card) != 16 or not clean_card.isdigit():
            return "Please enter a valid 16-digit card number (numbers only).", None
        if len(card_exp) != 5 or card_exp[2] != "/" or not (card_exp[:2].isdigit() and card_exp[3:].isdigit()):
            return "Expiration must be in MM/YY format (e.g., 12/28).", None
        month_val = int(card_exp[:2])
        year_val = 2000 + int(card_exp[3:])
        if month_val < 1 or month_val > 12:
            return "Card expiration month must be between 01 and 12.", None
        if (year_val, month_val) < (today.year, today.month):
            return "This card has expired. Please use a card with a future expiry date.", None
        if len(card_cvv.strip()) != 3 or not card_cvv.strip().isdigit():
            return "CVV must be exactly 3 digits.", None
        # Data minimization: we ONLY store the last 4 digits
        payment_info["card_last4"] = clean_card[-4:]
    else:
        upi_clean = upi_id.strip()
        if not upi_clean or upi_clean.count("@") != 1 or upi_clean.startswith("@") or upi_clean.endswith("@"):
            return "Please enter a valid UPI ID containing an '@' symbol (e.g. user@bank).", None
        # Data minimization: mask the personal handle (e.g., sa****@okhdfcbank)
        name_part, bank_part = upi_clean.split("@")
        payment_info["upi_masked"] = name_part[:2] + "****@" + bank_part
    return None, payment_info


def render():
    user = auth.current_user()
    st.title("Review and Confirm Your Stay")

    # Guard: If no reservation is currently staged in memory, guide user back to Explore.
    pending = st.session_state.get("pending_booking")
    if not pending:
        st.warning("No reservation in progress. Please choose a stay from Explore.")
        if st.button("← Back to Explore"):
            activity.go_to("explore")
        return

    # Prominent Demo Payment Disclaimer Banner
    st.warning("⚠️ **DEMO PAYMENT ENVIRONMENT:** This is a simulated checkout for academic coursework. No real credit card or bank account is charged. Do NOT enter real payment credentials.")

    # Split-column layout: Left column = Payment & Host message form, Right column = Trip Summary
    col_left, col_right = st.columns([1.5, 1])

    with col_left:
        # Payment Method Selection (Radio buttons for Card or UPI)
        st.markdown("### Choose Payment Method (Simulated)")
        pay_method = st.radio(
            "Payment Type",
            ["Card (demo)", "UPI (demo)"],
            horizontal=True
        )

        # Fields of the payment method that is NOT selected stay empty.
        card_name = card_num = card_exp = card_cvv = upi_id = ""

        # Container for card form or UPI form
        with st.container(border=True):
            if pay_method == "Card (demo)":
                st.markdown("**Simulated Card Payment**")
                card_name = st.text_input("Name on Card", value=user["full_name"])
                card_num = st.text_input("Card Number (16 digits)", placeholder="4000 1234 5678 9010", max_chars=19)
                exp_col, cvv_col = st.columns(2)
                with exp_col:
                    card_exp = st.text_input("Expiry (MM/YY)", placeholder="12/28", max_chars=5)
                with cvv_col:
                    card_cvv = st.text_input("CVV (3 digits)", placeholder="123", max_chars=3, type="password")
            else:
                st.markdown("**Simulated UPI Payment**")
                upi_id = st.text_input("UPI Virtual Payment Address", placeholder="name@okhdfcbank")

        # Optional Note to Host
        st.markdown("### Message Your Host (Optional)")
        host_note = st.text_area(
            "Share arrival time or special requests",
            placeholder="e.g. We will arrive around 3 PM after our flight lands."
        )

        # Mandatory Terms Agreement Checkbox
        rules_accepted = st.checkbox("I agree to the house rules, cancellation policy, and community guidelines.")

        st.markdown("<br>", unsafe_allow_html=True)

        # Booking Submission Button
        if st.button("Confirm Booking (Demo Payment)", use_container_width=True):
            # 1. Terms verification check
            if not rules_accepted:
                st.error("You must agree to the house rules and cancellation policy to proceed.")
                return

            # 2. Strict client-side validation of payment fields (see validate_payment_details above).
            error, payment_info = validate_payment_details(
                pay_method, card_name, card_num, card_exp, card_cvv, upi_id, datetime.date.today()
            )
            if error:
                payment_failed(error, pay_method)
                return

            # Show short simulated bank processing spinner for realistic user experience
            with st.spinner("Simulating secure bank authorization..."):
                time.sleep(1)

            # Assemble clean booking payload dictionary
            booking_payload = {
                "listing_id": pending["listing_id"],
                "listing_title": pending["listing_title"],
                "check_in": pending["check_in"],
                "check_out": pending["check_out"],
                "nights": pending["nights"],
                "guests": pending["guests"],
                "stay_cost": pending["stay_cost"],
                "cleaning_fee": pending["cleaning_fee"],
                "service_fee": pending["service_fee"],
                "taxes": pending["taxes"],
                "total_price": pending["total_price"],
                "host_note": host_note.strip(),
            }

            # 3. ATOMIC MYSQL TRANSACTION:
            # Commits booking + payment + system welcome messages + notifications + audit logs in ONE unit.
            success, msg, ref_code = database.create_booking_transaction(
                user["user_id"], st.session_state.get("session_id"), booking_payload, payment_info
            )
            if not success:
                st.error(msg)
                return

            # Display confirmation celebration and success banner
            st.balloons()
            st.success(f"🎉 Reservation confirmed! Booking reference: **{ref_code}**")
            
            # Clear staged booking and pre-select this thread on the Messages page
            st.session_state["pending_booking"] = None
            st.session_state["chat_listing_id"] = pending["listing_id"]
            st.info("Your booking is saved. Open **My Trips** or **Messages** from the left sidebar.")

    with col_right:
        # Sticky Trip Summary Card
        with st.container(border=True):
            st.markdown("### Trip Summary")
            st.markdown(f"**{pending['listing_title']}**")
            st.caption(f"Host: {pending['host_name']} · {pending['listing_location']}")
            st.markdown("---")
            st.write(f"📅 **Dates:** {pending['check_in']} to {pending['check_out']} ({pending['nights']} nights)")
            st.write(f"👥 **Guests:** {pending['guests']}")
            st.markdown("---")
            st.markdown("### Price Breakdown")
            st.write(f"\\${pending['price_per_night']} × {pending['nights']} nights: **\\${pending['stay_cost']:.2f}**")
            st.write(f"Cleaning fee: **\\${pending['cleaning_fee']:.2f}**")
            st.write(f"OffStays service fee: **\\${pending['service_fee']:.2f}**")
            st.write(f"Occupancy taxes: **\\${pending['taxes']:.2f}**")
            st.markdown("---")
            st.markdown(f"### Total (USD): **\\${pending['total_price']:.2f}**")

            # Allows the user to return to Details to adjust parameters if needed
            if st.button("Edit dates or guests", use_container_width=True):
                activity.go_to("details")