# pricing.py: Financial Calculation and Stay Itemization Engine.
#
# WHAT THIS FILE DOES:
#   This module contains the mathematical calculation routines for stay reservations.
#   It determines the number of nights between check-in and check-out dates and computes
#   a transparent, itemized financial breakdown: base nightly charges, standard cleaning
#   fees, concierge service charges, and local tourism/occupancy taxes.
#
# WHY THIS STEP IS NECESSARY:
#   In an e-commerce hospitality platform, financial calculations must be 100% consistent
#   across every screen. By isolating calculations here in a single file:
#     - The Explore stay cards, the Property Details card, the Checkout screen,
#       and the downloadable PDF-style Invoices all use the exact same calculation rules.
#     - We eliminate rounding discrepancies and prevent duplicate arithmetic across files.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - `page_explore.py` calls this to display estimated total trip prices on stay cards.
#   - `page_details.py` calls this to update the sticky reservation card as the user alters dates.
#   - `page_checkout.py` uses this breakdown to display itemized costs and commit them to MySQL.
#   - `page_trips.py` uses this breakdown to generate downloadable text invoices.

import datetime  # Standard Python library used to compute differences between calendar dates.


def calculate_nights(check_in_date, check_out_date):
    # WHAT: Calculates the integer number of nights between arrival and departure.
    # WHY:  Hospitality stays are charged per night (from check-in afternoon to check-out morning).
    # HOW:  Subtracting two datetime.date objects returns a Python `timedelta` object.
    #       Accessing the `.days` attribute gives the exact count of nights.
    delta = check_out_date - check_in_date
    return delta.days


def calculate_price_breakdown(price_per_night, check_in_date, check_out_date):
    # WHAT: Generates a complete financial itemization dictionary for a prospective stay.
    # WHY:  Modern luxury travelers require upfront, transparent pricing without hidden fees.
    # HOW:  Multiplies the nightly rate by the duration, adds fixed hospitality fees,
    #       calculates an exact 10% tax, and sums everything into a final gross total.
    
    # Calculate the number of nights.
    nights = calculate_nights(check_in_date, check_out_date)
    
    # DEFENSIVE PROGRAMMING CHECK:
    # Ensure nights is at least 1. This prevents zero or negative multipliers if check-in
    # and check-out ever fall on the same day during user input changes.
    if nights < 1:
        nights = 1

    # Base Stay Cost: Nightly rate multiplied by the number of nights.
    # We round to 2 decimal places to ensure currency precision.
    stay_cost = round(float(price_per_night * nights), 2)
    
    # Standard Professional Cleaning Fee:
    # A flat fee charged once per stay (regardless of duration) to prepare luxury sanctuaries.
    cleaning_fee = 45.00
    
    # Standard Concierge & Platform Service Fee:
    # A flat operational fee for OFFSTAYS platform support, 24/7 concierge, and verification.
    service_fee = 40.00
    
    # Occupancy Taxes:
    # Calculated as exactly 10% of the base stay cost to represent local tourism taxes.
    taxes = round(stay_cost * 0.10, 2)
    
    # Gross Total: Sum of base accommodation, cleaning, service concierge, and taxes.
    total_price = round(stay_cost + cleaning_fee + service_fee + taxes, 2)

    # Return a structured dictionary with named fields.
    # This structure is directly unpacked and used by UI components and SQL INSERT queries.
    return {
        "nights": nights,
        "price_per_night": price_per_night,
        "stay_cost": stay_cost,
        "cleaning_fee": cleaning_fee,
        "service_fee": service_fee,
        "taxes": taxes,
        "total_price": total_price
    }