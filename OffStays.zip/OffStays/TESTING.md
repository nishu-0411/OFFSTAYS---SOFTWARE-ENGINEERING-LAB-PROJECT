# OFFSTAYS — Testing Guide and Report

This project has **205 automated tests** written with Python's built-in `unittest`.
No extra testing packages are needed: the UI tests use `streamlit.testing.v1.AppTest`, which ships with Streamlit.

---

## 1. Testing approach (viva summary)

We test in three layers, from fast and narrow to slow and realistic:

| Layer | Folder | Tests | What is real | What is replaced |
|---|---|---|---|---|
| **Unit** | `tests/unit/` | 147 | One function at a time | MySQL (mocks / `FakeCursor`), Streamlit session (`FakeStreamlit`) |
| **Mocked integration** | `tests/integration_mocked/` | 20 | Several real modules together, including the whole `app.py` via AppTest | Only MySQL (in-memory fake database) |
| **Database integration** | `tests/integration_db/` | 38 | Real modules + a **real MySQL test database** + `app.py` via AppTest | Nothing except the browser |

- **Unit tests** prove each business rule is correct: prices, refunds, password hashing, validation, overlap checks, running-average ratings, commit/rollback decisions.
- **Mocked integration tests** prove the modules are wired together correctly (for example: register → log in → five wrong passwords → lockout → wait 15 minutes → log in again), and that the app's login gate and admin permissions work, without needing a database server.
- **Database integration tests** prove the SQL really works on MySQL: constraints, JSON queries, transactions, row locking under two simultaneous bookings, and per-user data isolation.

Each test creates its own users and uses its own dates, so tests do not depend on each other.

---

## 2. How to run the tests

Open a terminal in the project folder (the folder that contains `app.py`) and activate your virtual environment first.

```bash
# Everything (database tests are skipped automatically if the test database is not set up)
python -m unittest discover -s tests -t .

# Only unit tests
python -m unittest discover -s tests/unit -t .

# Only mocked integration tests (no MySQL needed)
python -m unittest discover -s tests/integration_mocked -t .

# Only real-database integration tests (needs the setup in section 3)
python -m unittest discover -s tests/integration_db -t .

# One file, with every test name printed
python -m unittest -v tests.unit.test_pricing
```

`python -m unittest` on its own (from the project folder) also discovers all tests.

---

## 3. Setting up the separate test database (for `tests/integration_db/`)

The database tests **create and delete their own database**, by default called `offstays_test`.
Your normal `offstays` database is never used or changed.

1. Make sure MySQL Server is running (the same server you use with Workbench is fine).
2. Copy `tests/test_database.example.ini` to `tests/test_database.ini`.
3. Edit `tests/test_database.ini`:
   ```ini
   [test_database]
   enabled = yes
   host = localhost
   port = 3306
   user = root
   password = <your MySQL password>
   name = offstays_test
   ```
4. Run `python -m unittest discover -s tests/integration_db -t .`

The MySQL user needs permission to `CREATE` and `DROP` databases (the `root` user has this).

**Environment variables instead of the file** (they override the file):

| macOS / Linux | Windows (Command Prompt) |
|---|---|
| `export OFFSTAYS_TEST_DB_ENABLED=1` | `set OFFSTAYS_TEST_DB_ENABLED=1` |
| `export OFFSTAYS_TEST_DB_PASSWORD=yourpass` | `set OFFSTAYS_TEST_DB_PASSWORD=yourpass` |

Other variables: `OFFSTAYS_TEST_DB_HOST`, `OFFSTAYS_TEST_DB_PORT`, `OFFSTAYS_TEST_DB_USER`, `OFFSTAYS_TEST_DB_NAME`.
Set `OFFSTAYS_TEST_DB_KEEP=1` to keep `offstays_test` after the run so you can look at it in Workbench.

`tests/test_database.ini` contains your password: keep it private and do not share it.

### Safety rules built into `tests/support/db_sandbox.py`

1. The test database name **must end with `_test`** and must not be `offstays` or a MySQL system database.
2. The project's SQL scripts are copied in memory and their `USE` / `CREATE DATABASE` lines are rewritten to the test name. The rewrite is checked: if any statement still targets `offstays`, the run stops.
3. When the test database is created, a marker table `_offstays_test_marker` is added. The tests **only drop a database that carries this marker**, so an existing database with the same name that the tests did not create is never deleted.
4. Before every database test, `SELECT DATABASE()` and the marker row are checked again.
5. The test database is dropped automatically when the run finishes.
6. Database tests are **off by default**. They run only when you switch them on.

---

## 4. What is covered

### Unit tests (`tests/unit/`, 147 tests)

| File | Tests | Covers |
|---|---|---|
| `test_pricing.py` | 13 | Night counting (month/year/leap-year boundaries), flat fees, 10% tax on stay cost only, rounding to cents, same-day and reversed dates charged as 1 night |
| `test_business_rules.py` | 18 | 48-hour refund rule and its boundary; card checks (name, 16 digits, MM/YY, month range, expiry vs today, CVV); UPI checks; only last 4 digits or a masked UPI handle kept; invoice text |
| `test_auth_security.py` | 15 | PBKDF2-SHA256 with 100,000 iterations, random 32-hex salt, different hashes for the same password, verification (including the seeded Sarah Vance hash), email / password / phone rules |
| `test_auth_flows.py` | 17 | Registration (input cleaning, duplicate email, every validation message, audit of rejected attempts without the password), login (generic error message, lockout at 5 failures, 4 failures still allowed, deactivated accounts), logout, change password, profile refresh, no password hash in session state |
| `test_database_helpers.py` | 27 | MySQL type cleaning, commit/rollback in `execute`, friendly messages for MySQL error codes 1045/1049/1146/2003/2013, audit log rows (JSON details, 500-character limit, cursor reuse), lockout time window, wishlist toggle, price-bound fallback, review date formatting, user-scoped queries |
| `test_database_transactions.py` | 20 | Booking transaction (lock first, all rows written, one commit; overlap → rollback + `BOOKING_FAILED`; mid-transaction error → full rollback), unique reference retry, cancellation (full/partial refund status, owner-only, no double cancel), reviews (running average keeps 142-review history, owner + completed stay only, duplicate review), user creation rollback, session token not fully logged |
| `test_activity.py` | 9 | Audit events carry user + session, anonymous visitors not logged, logging failures never crash a page, `PAGE_VIEW` only on a real page change, `open_property` resets the details page |
| `test_explore_and_messages.py` | 19 | Every Explore filter alone and combined (destination, area, category, inclusive price range, guests, pool, Wi-Fi, superhost, booked dates), sorting, automated host replies (PIN only for this guest's confirmed booking, destination airport, early check-in, fallback), Wi-Fi names, login-history labels |
| `test_db_sandbox_safety.py` | 9 | The safety rules above, tested without a database |

### Mocked integration tests (`tests/integration_mocked/`, 20 tests)

| File | Tests | Workflow |
|---|---|---|
| `test_account_workflow.py` | 6 | Real `auth.py` + `activity.py`: register → act → log out → log in (audit trail and session links), password change, lockout and its 15-minute expiry, lockout per email, typed passwords never stored in logs |
| `test_booking_workflow.py` | 5 | Real `pricing.py` → checkout validation → `create_booking_transaction` → refund rule → `cancel_booking`: the same amounts flow through every step; UPI masking; invalid payments never reach the database |
| `test_streamlit_app.py` | 9 | The whole `app.py` in AppTest: login gate, wrong-password message, login opens Explore, registration form (and the terms checkbox), guests cannot reach the admin page even by forcing it, admin dashboard, logout, "Database not ready" screen |

### Database integration tests (`tests/integration_db/`, 38 tests)

| File | Tests | Workflow on real MySQL |
|---|---|---|
| `test_db_accounts.py` | 12 | Registration rows (user, notification, session, logs), logout, seeded user login, duplicate email (app check + UNIQUE constraint + rollback), lockout using MySQL `JSON_EXTRACT`, password change, deactivated user, profile update, database identity check, health-check messages for a missing database and a wrong password |
| `test_db_bookings.py` | 12 | Booking writes booking/payment/messages/notifications/logs; overlap rules (back-to-back stays allowed); second guest blocked; **two simultaneous bookings: exactly one wins**; CHECK constraint rejects bad dates with full rollback; per-guest isolation; full and partial cancellation; owner-only, no double cancel; past stays become Completed; reviews update the running average; duplicate and unauthorised reviews blocked |
| `test_db_engagement.py` | 11 | Host replies use the real booking PIN and destination airport; unread counter and mark-as-read; conversation order; wishlist; private notifications; host applications; 100 listings with photos/amenities/pool and Wi-Fi flags; destination menus; a booked property disappears from search; admin statistics and log filters; profile activity |
| `test_db_streamlit_app.py` | 3 | `app.py` + real database: Sarah logs in through the form, opens My Trips and sees her booking, and MySQL records `LOGIN → SEARCH → PAGE_VIEW`; admin dashboard numbers equal live counts; a wrong password typed in the UI is stored as `LOGIN_FAILED` |

**Discounts:** the OFFSTAYS code has no discount or coupon logic, so there are no discount tests.

---

## 5. Actual results

Executed on **27 October 2026** in a Linux test environment:

- Python **3.12.3**, Streamlit **1.48.1**, PyMySQL **1.2.3**, pandas **2.3.3**, cryptography **50.0.2** (the same versions as the project's `.venv`)
- Database server: **MariaDB 10.11.14** (MySQL-compatible). MySQL 8 was not available in the test environment.

| Command | Result |
|---|---|
| `python -m unittest discover -s tests/unit -t .` | **Ran 147 tests — OK** |
| `python -m unittest discover -s tests/integration_mocked -t .` | **Ran 20 tests — OK** |
| `python -m unittest discover -s tests/integration_db -t .` (not configured) | **0 run, 11 test classes skipped** with the setup message |
| `python -m unittest discover -s tests/integration_db -t .` (test DB enabled) | **Ran 38 tests — OK** |
| `python -m unittest discover -s tests -t .` (test DB enabled) | **Ran 205 tests — OK** (about 25 seconds) |
| `python -m unittest` from the project folder (test DB not configured) | **Ran 167 tests — OK (skipped=11)** |

Extra checks:

- The two-simultaneous-bookings test was run **15 times in a row: 15 passed**. The full suite (with the test database) was run 5 times: all passed.
- After every run the `offstays_test` database was gone and the normal `offstays` database was unchanged.
- The safety checks refused `offstays`, `mysql`, `offstays_prod`, an injection-style name, and an existing `*_test` database without the marker.
- The real app (`streamlit run app.py`) was also checked in a headless Chromium browser after the code changes: registration, weak-password rejection, card booking (expired card rejected first), UPI booking, messages, cancellation with refund, logout, wrong password, 5-attempt lockout, review, profile edit, password change, host application and admin dashboard all worked. These browser checks were run manually and are not part of the test suite.

### Not executed here (please run on your computer)

- **MySQL 8 on macOS/Windows.** The database tests were run on MariaDB 10.11. Every SQL feature they use (`JSON_EXTRACT`, `CHECK` constraints, `SELECT ... FOR UPDATE`, the views) also exists in MySQL 8.0.16+, but they have not been run against MySQL 8 here. Follow section 3 and run the database suite once on your own MySQL.
- **Real browser tests** are not part of the suite. The AppTest tests cover the same app flows without a browser.

### Known AppTest limitation

After `st.stop()`, AppTest keeps the previous run's sidebar elements in its element tree. The logout test therefore checks the login screen, the session state and the database instead of the sidebar. In a real browser the sidebar disappears after logout (checked manually).

---

## 6. Production-code changes made for testing

Only three application files were changed. Behaviour is the same, and the browser checks above confirm it.

| File | Change | Why |
|---|---|---|
| `page_trips.py` | The 48-hour refund rule was moved out of `render()` into `calculate_cancellation_refund(booking, days_to_arrival)`; `render()` now calls it. | The refund rule is important money logic and could not be unit tested while it was inside the UI code. |
| `page_checkout.py` | The card/UPI validation was moved out of `render()` into `validate_payment_details(...)`, with the same messages and the same order of checks. `render()` now calls it and still logs `PAYMENT_FAILED`. The unused payment fields are now set to `""` before the form. | Same reason: payment validation and data minimisation (last 4 digits only) can now be unit tested. |
| `db_config.py` | The real MySQL password was replaced by the placeholder `your_mysql_password`. | Secrets must not be shipped in the ZIP. **Put your own password back in this file** (or set `OFFSTAYS_DB_PASSWORD`) before running the app. |

---

## 7. Observations found while testing (not changed)

These do not affect normal use through the UI, so the code was left as it is. They are worth knowing for the viva:

1. `database.add_review()` checks that the booking belongs to the user and is completed, but it does not check that `listing_id` is the booking's property. The UI always passes the matching property, so this cannot happen through the app.
2. `database.add_review()` reports **any** integrity error as "A review for this booking already exists." (for example an invalid property id). Again, the UI never sends such values.
3. The "48 hours" refund rule is counted in **whole days** (`days_to_arrival >= 2`), not exact hours.
4. Refreshing the browser starts a new Streamlit session, so the user has to log in again (this is documented in the README).
