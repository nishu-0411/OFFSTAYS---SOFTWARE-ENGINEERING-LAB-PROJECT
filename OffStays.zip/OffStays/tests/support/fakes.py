# tests/support/fakes.py: Small stand-ins used by the unit and mocked integration tests.
#
# FakeCursor / FakeConnection
#   Replace a real PyMySQL connection. They remember every SQL statement that was executed
#   and return answers that the test prepares in advance. This lets us test the logic in
#   database.py (commit, rollback, running averages ...) without a MySQL server.
#
# FakeStreamlit
#   Replaces the `st` object inside auth.py / activity.py. It only needs `session_state`
#   (a normal dict) and `rerun()`. Real st.rerun() stops the script, so the fake raises
#   RerunCalled to imitate that behaviour.

import re


class RerunCalled(Exception):
    # Raised by FakeStreamlit.rerun() so a test can check that a page change happened.
    pass


class FakeStreamlit:
    def __init__(self, session_state=None):
        self.session_state = {} if session_state is None else session_state

    def rerun(self):
        raise RerunCalled()


class FakeCursor:
    # A cursor that records statements and replies with prepared results.
    #
    # fetchone_results / fetchall_results are lists consumed in order (first in, first out).
    # execute_results is an optional list of values returned by execute() (row counts).
    # fail_on maps a regex -> exception, raised when a matching statement is executed.
    def __init__(self, fetchone_results=None, fetchall_results=None, execute_results=None,
                 fail_on=None, first_lastrowid=100):
        self.fetchone_results = list(fetchone_results or [])
        self.fetchall_results = list(fetchall_results or [])
        self.execute_results = list(execute_results or [])
        self.fail_on = fail_on or {}
        self.executed = []  # list of (normalised_sql, params)
        self.lastrowid = first_lastrowid - 1

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False  # never swallow exceptions

    def execute(self, sql, params=None):
        clean_sql = " ".join(sql.split())
        for pattern, error in self.fail_on.items():
            if re.search(pattern, clean_sql, re.IGNORECASE):
                raise error
        self.executed.append((clean_sql, params))
        if clean_sql.upper().startswith("INSERT"):
            self.lastrowid += 1
        if self.execute_results:
            return self.execute_results.pop(0)
        return 1

    def fetchone(self):
        return self.fetchone_results.pop(0) if self.fetchone_results else None

    def fetchall(self):
        return self.fetchall_results.pop(0) if self.fetchall_results else []

    # Convenience helpers for assertions
    def statements(self):
        return [sql for sql, _ in self.executed]

    def find(self, fragment):
        # Returns every (sql, params) whose SQL contains the fragment (case-insensitive).
        fragment = fragment.lower()
        return [(sql, params) for sql, params in self.executed if fragment in sql.lower()]


class FakeConnection:
    def __init__(self, cursor):
        self._cursor = cursor
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self):
        return self._cursor

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1

    def close(self):
        self.closed = True
