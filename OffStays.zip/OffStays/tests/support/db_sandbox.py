# tests/support/db_sandbox.py: Builds and protects the SEPARATE MySQL test database.
#
# Why this file exists:
#   The database integration tests need a real MySQL database, but they must NEVER touch
#   the normal `offstays` database that the app uses. This module:
#     1. Reads the test-database settings (tests/test_database.ini or OFFSTAYS_TEST_DB_* env vars).
#     2. Refuses unsafe names: the name must end with "_test" and must not be the app database.
#     3. Creates the test database from the project's own SQL scripts, with the database name
#        rewritten, plus a marker table that proves "this database was created by the tests".
#     4. Only drops a database that carries that marker, so an unknown database is never deleted.
#     5. Temporarily points db_config at the test database and checks SELECT DATABASE() before use.

import atexit
import configparser
import os
import re
import time

import pymysql
from pymysql.constants import CLIENT

import db_config

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SQL_DIR = os.path.join(PROJECT_DIR, "sql")
INI_PATH = os.path.join(PROJECT_DIR, "tests", "test_database.ini")

MARKER_TABLE = "_offstays_test_marker"
SAFE_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{1,54}_test$")
SYSTEM_DATABASES = {"mysql", "sys", "information_schema", "performance_schema"}


class UnsafeDatabaseError(Exception):
    # Raised whenever a safety check fails. Tests stop instead of touching the wrong database.
    pass


# ------------------------------------------------------------------ settings
def load_settings():
    # Settings come from tests/test_database.ini, then environment variables override them.
    settings = {"enabled": False, "host": "localhost", "port": 3306, "user": "root",
                "password": "", "name": "offstays_test", "keep": False}
    if os.path.exists(INI_PATH):
        parser = configparser.ConfigParser()
        parser.read(INI_PATH, encoding="utf-8")
        if parser.has_section("test_database"):
            sec = parser["test_database"]
            settings["enabled"] = sec.getboolean("enabled", fallback=False)
            settings["host"] = sec.get("host", settings["host"])
            settings["port"] = sec.getint("port", fallback=settings["port"])
            settings["user"] = sec.get("user", settings["user"])
            settings["password"] = sec.get("password", settings["password"])
            settings["name"] = sec.get("name", settings["name"])
    env = os.environ
    if "OFFSTAYS_TEST_DB_ENABLED" in env:
        settings["enabled"] = env["OFFSTAYS_TEST_DB_ENABLED"].strip().lower() in ("1", "yes", "true")
    settings["host"] = env.get("OFFSTAYS_TEST_DB_HOST", settings["host"])
    settings["port"] = int(env.get("OFFSTAYS_TEST_DB_PORT", settings["port"]))
    settings["user"] = env.get("OFFSTAYS_TEST_DB_USER", settings["user"])
    settings["password"] = env.get("OFFSTAYS_TEST_DB_PASSWORD", settings["password"])
    settings["name"] = env.get("OFFSTAYS_TEST_DB_NAME", settings["name"])
    settings["keep"] = env.get("OFFSTAYS_TEST_DB_KEEP", "").strip().lower() in ("1", "yes", "true")
    return settings


def skip_reason():
    # Returns a message explaining why DB tests are skipped, or None when they can run.
    settings = load_settings()
    if not settings["enabled"]:
        return ("Real-database tests are switched off. Copy tests/test_database.example.ini to "
                "tests/test_database.ini, fill in your MySQL login and set enabled = yes "
                "(or set OFFSTAYS_TEST_DB_ENABLED=1).")
    try:
        assert_safe_test_db_name(settings["name"])
    except UnsafeDatabaseError as e:
        return str(e)
    try:
        conn = _server_connection(settings)
        conn.close()
    except pymysql.err.MySQLError as e:
        return f"Cannot connect to the MySQL test server at {settings['host']}:{settings['port']} ({e.args[0]})."
    return None


# ------------------------------------------------------------------ safety checks
def assert_safe_test_db_name(name):
    # Rule 1: the name must end with _test (e.g. offstays_test).
    if not SAFE_NAME_PATTERN.match(name or ""):
        raise UnsafeDatabaseError(
            f"Refusing to use database '{name}': a test database name must end with '_test'.")
    # Rule 2: it must not be the app's own database or a MySQL system database.
    if name.lower() == str(db_config.DB_NAME).lower() or name.lower() in SYSTEM_DATABASES:
        raise UnsafeDatabaseError(f"Refusing to use database '{name}': it is not a dedicated test database.")


def _server_connection(settings, database=None, multi=False):
    return pymysql.connect(host=settings["host"], port=settings["port"], user=settings["user"],
                           password=settings["password"], database=database, charset="utf8mb4",
                           client_flag=CLIENT.MULTI_STATEMENTS if multi else 0, connect_timeout=5,
                           autocommit=True)


def _database_exists(cursor, name):
    cursor.execute("SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = %s", (name,))
    return cursor.fetchone() is not None


def _has_marker(cursor, name):
    # The marker table is created by build_test_database(); a database without it is not ours.
    cursor.execute("SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
                   (name, MARKER_TABLE))
    if cursor.fetchone() is None:
        return False
    cursor.execute(f"SELECT created_for FROM `{name}`.`{MARKER_TABLE}` LIMIT 1")
    row = cursor.fetchone()
    return row is not None and row[0] == name


# ------------------------------------------------------------------ SQL rewriting
def rewrite_sql_for_test_db(sql_text, test_name):
    # The project's SQL scripts say `USE offstays;` etc. We redirect them to the test database.
    assert_safe_test_db_name(test_name)
    app_name = re.escape(str(db_config.DB_NAME))
    sql_text = re.sub(rf"(?im)^\s*DROP\s+DATABASE\s+IF\s+EXISTS\s+`?{app_name}`?\s*;", "", sql_text)
    sql_text = re.sub(rf"(?im)^(\s*CREATE\s+DATABASE\s+)`?{app_name}`?(\b)", rf"\1`{test_name}`\2", sql_text)
    sql_text = re.sub(rf"(?im)^(\s*USE\s+)`?{app_name}`?\s*;", rf"\1`{test_name}`;", sql_text)
    # Final guard: no statement may still mention the app database.
    leftover = re.search(rf"(?im)^\s*(USE|CREATE\s+DATABASE|DROP\s+DATABASE)[^;\n]*\b{app_name}\b", sql_text)
    if leftover:
        raise UnsafeDatabaseError(f"SQL still targets the app database: {leftover.group(0).strip()}")
    return sql_text


def _run_sql_file(settings, filename):
    with open(os.path.join(SQL_DIR, filename), encoding="utf-8") as f:
        sql_text = rewrite_sql_for_test_db(f.read(), settings["name"])
    conn = _server_connection(settings, multi=True)
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql_text)
            while cursor.nextset():
                pass
    finally:
        conn.close()


# ------------------------------------------------------------------ build / drop
def build_test_database():
    # Creates a fresh test database: schema + marker + sample data + views.
    settings = load_settings()
    name = settings["name"]
    assert_safe_test_db_name(name)
    conn = _server_connection(settings)
    try:
        with conn.cursor() as cursor:
            if _database_exists(cursor, name):
                if not _has_marker(cursor, name):
                    raise UnsafeDatabaseError(
                        f"Database '{name}' already exists but was not created by the OFFSTAYS tests "
                        f"(no {MARKER_TABLE} table). Refusing to drop it. Choose another name.")
                cursor.execute(f"DROP DATABASE `{name}`")
    finally:
        conn.close()

    started = time.time()
    _run_sql_file(settings, "01_schema.sql")
    conn = _server_connection(settings, database=name)
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE TABLE `{MARKER_TABLE}` (created_for VARCHAR(64) NOT NULL, created_at DATETIME NOT NULL)")
            cursor.execute(f"INSERT INTO `{MARKER_TABLE}` VALUES (%s, NOW())", (name,))
    finally:
        conn.close()
    _run_sql_file(settings, "02_seed_data.sql")
    _run_sql_file(settings, "04_views_and_reports.sql")
    return time.time() - started


def drop_test_database():
    # Drops the test database, but only if the name is safe AND it carries our marker table.
    settings = load_settings()
    name = settings["name"]
    assert_safe_test_db_name(name)
    conn = _server_connection(settings)
    try:
        with conn.cursor() as cursor:
            if not _database_exists(cursor, name):
                return
            if not _has_marker(cursor, name):
                raise UnsafeDatabaseError(f"Refusing to drop '{name}': marker table not found.")
            cursor.execute(f"DROP DATABASE `{name}`")
    finally:
        conn.close()


# ------------------------------------------------------------------ pointing the app at the test DB
_ORIGINAL_CONFIG = None
_BUILT = False


def use_test_database():
    # Builds the test database once per test run and points db_config (and so database.py) at it.
    # Safe to call from many test modules: the build only happens the first time.
    global _ORIGINAL_CONFIG, _BUILT
    settings = load_settings()
    assert_safe_test_db_name(settings["name"])
    if not _BUILT:
        build_test_database()
        _BUILT = True
        if not settings["keep"]:
            atexit.register(_cleanup_at_exit)
    if _ORIGINAL_CONFIG is None:
        _ORIGINAL_CONFIG = (db_config.DB_HOST, db_config.DB_PORT, db_config.DB_USER,
                            db_config.DB_PASSWORD, db_config.DB_NAME)
    db_config.DB_HOST = settings["host"]
    db_config.DB_PORT = settings["port"]
    db_config.DB_USER = settings["user"]
    db_config.DB_PASSWORD = settings["password"]
    db_config.DB_NAME = settings["name"]
    verify_connected_to_test_database()
    return settings


def verify_connected_to_test_database():
    # Identity check: the connection the APP would open must land in the marked test database.
    import database
    settings = load_settings()
    row = database.fetch_one("SELECT DATABASE() AS db")
    if row is None or row["db"] != settings["name"]:
        raise UnsafeDatabaseError(f"Connected to '{row and row['db']}' instead of '{settings['name']}'.")
    marker = database.fetch_one(f"SELECT created_for FROM `{MARKER_TABLE}` LIMIT 1")
    if marker is None or marker["created_for"] != settings["name"]:
        raise UnsafeDatabaseError("Marker row missing: this is not a test database built by the tests.")


def restore_app_database_config():
    # Puts the original db_config values back after a test module finishes.
    global _ORIGINAL_CONFIG
    if _ORIGINAL_CONFIG is not None:
        (db_config.DB_HOST, db_config.DB_PORT, db_config.DB_USER,
         db_config.DB_PASSWORD, db_config.DB_NAME) = _ORIGINAL_CONFIG
        _ORIGINAL_CONFIG = None


def _cleanup_at_exit():
    try:
        drop_test_database()
    except Exception as e:  # Never hide a failed cleanup, but do not crash the interpreter exit.
        print(f"[db_sandbox] could not drop the test database: {e}")


# ------------------------------------------------------------------ data helpers for tests
_counter = {"n": 0}


def unique_email(prefix="tester"):
    # Every test creates its own users, so tests never depend on each other's data.
    _counter["n"] += 1
    return f"{prefix}.{int(time.time() * 1000)}.{_counter['n']}@offstays-tests.example"


_date_cursor = {"days": 0}


def unique_stay_dates(nights=3):
    # Hands out non-overlapping date ranges from 2031 onwards, far after the sample bookings
    # (which end in 2027), so one test's booking can never block another test's booking.
    import datetime
    start = datetime.date(2031, 1, 1) + datetime.timedelta(days=_date_cursor["days"])
    _date_cursor["days"] += nights + 2
    return start.isoformat(), (start + datetime.timedelta(days=nights)).isoformat()


def unique_past_stay_dates(nights=3):
    # Same idea for stays in the past (2021), used to test the "Completed" status and reviews.
    import datetime
    start = datetime.date(2021, 1, 1) + datetime.timedelta(days=_date_cursor["days"])
    _date_cursor["days"] += nights + 2
    return start.isoformat(), (start + datetime.timedelta(days=nights)).isoformat()
