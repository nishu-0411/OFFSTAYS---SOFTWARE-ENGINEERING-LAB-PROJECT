# tests/support/memory_db.py: An in-memory stand-in for the parts of database.py used by
# the mocked integration tests. It keeps users, sessions, activity logs and listings in
# Python lists, so the REAL auth.py, activity.py and Streamlit pages can run against it.
#
# patched_database(fake) swaps the functions inside the real `database` module for the fake's
# methods, and makes get_connection() fail loudly, so a mocked test can never reach MySQL.

import contextlib
import datetime
import json
from unittest import mock

import database


class InMemoryDatabase:
    def __init__(self):
        self.users = []
        self.sessions = []
        self.logs = []
        self.listings = []
        self.saved = set()
        self.now = datetime.datetime(2026, 10, 27, 10, 0, 0)

    # ---------------------------------------------------------------- users & sessions
    def add_user(self, full_name, email, password_hash, password_salt, role="guest", is_active=1):
        user = {"user_id": len(self.users) + 1, "full_name": full_name, "email": email, "phone": None,
                "password_hash": password_hash, "password_salt": password_salt, "role": role,
                "city": "Ahmedabad", "country": "India", "avatar_url": None, "is_active": is_active,
                "created_at": self.now.isoformat(), "last_login_at": None}
        self.users.append(user)
        return user

    def get_user_by_email(self, email):
        return next((dict(u) for u in self.users if u["email"] == email), None)

    def get_user_by_id(self, user_id):
        return next((dict(u) for u in self.users if u["user_id"] == user_id), None)

    def create_user(self, full_name, email, phone, password_hash, password_salt, city, country):
        user = self.add_user(full_name, email, password_hash, password_salt)
        user.update(phone=phone or None, city=city or None, country=country or None)
        self.log_activity(user["user_id"], "REGISTER", "New account registered", "user", user["user_id"],
                          {"email": email, "role": "guest"})
        return user["user_id"]

    def update_password(self, user_id, password_hash, password_salt):
        user = next(u for u in self.users if u["user_id"] == user_id)
        user.update(password_hash=password_hash, password_salt=password_salt)

    def start_session(self, user_id, token, user_agent):
        session = {"session_id": len(self.sessions) + 1, "user_id": user_id, "token": token,
                   "login_at": self.now, "logout_at": None, "is_active": 1}
        self.sessions.append(session)
        self.log_activity(user_id, "LOGIN", "User logged in successfully", "user", user_id,
                          session_id=session["session_id"])
        return session["session_id"]

    def end_session(self, user_id, session_id):
        for s in self.sessions:
            if s["session_id"] == session_id and s["user_id"] == user_id:
                s.update(logout_at=self.now, is_active=0)
        self.log_activity(user_id, "LOGOUT", "User logged out", "user", user_id, session_id=session_id)

    def touch_session(self, session_id):
        pass

    # ---------------------------------------------------------------- activity log
    def log_activity(self, user_id, activity_type, description, entity_type=None, entity_id=None,
                     details=None, status="SUCCESS", session_id=None, cursor=None):
        self.logs.append({"user_id": user_id, "activity_type": activity_type, "description": description,
                          "entity_type": entity_type, "entity_id": None if entity_id is None else str(entity_id),
                          "details": json.dumps(details, default=str) if details else None,
                          "status": status, "session_id": session_id, "created_at": self.now})

    def count_recent_failed_logins(self, email, minutes):
        # Same rule as the SQL version: LOGIN_FAILED rows for this email inside the time window.
        cutoff = self.now - datetime.timedelta(minutes=minutes)
        return sum(1 for log in self.logs
                   if log["activity_type"] == "LOGIN_FAILED" and log["created_at"] >= cutoff
                   and log["details"] and json.loads(log["details"]).get("email") == email)

    def log_types(self, user_id=None):
        return [log["activity_type"] for log in self.logs if user_id is None or log["user_id"] == user_id]

    # ---------------------------------------------------------------- app shell & explore page
    def check_database_ready(self):
        return True, ""

    def update_completed_bookings(self):
        pass

    def get_unread_message_count(self, user_id):
        return 0

    def get_unread_notification_count(self, user_id):
        return 2

    def get_destinations(self):
        names = sorted({l["destination"] for l in self.listings})
        return [{"destination_id": i + 1, "name": n, "country": "Indonesia" if n == "Bali" else "Switzerland",
                 "continent": "Asia", "description": f"About {n}", "latitude": 0, "longitude": 0, "map_zoom": 9,
                 "nearest_airport": "Test Airport", "best_season": "All year",
                 "property_count": sum(1 for l in self.listings if l["destination"] == n)}
                for i, n in enumerate(names)]

    def get_areas(self, destination_name):
        return sorted({l["area"] for l in self.listings if l["destination"] == destination_name})

    def get_price_bounds(self):
        prices = [l["price_per_night"] for l in self.listings] or [50, 400]
        return min(prices), max(prices)

    def get_distinct_categories(self):
        return sorted({l["category"] for l in self.listings})

    def get_all_listings(self):
        return [dict(l) for l in self.listings]

    def get_saved_listing_ids(self, user_id):
        return [pid for uid, pid in self.saved if uid == user_id]

    def get_unavailable_listing_ids(self, check_in, check_out):
        return set()

    # ---------------------------------------------------------------- admin dashboard
    def get_platform_stats(self):
        return {"users": len(self.users), "new_users_today": 0, "properties": len(self.listings),
                "active_bookings": 0, "revenue": 0, "logins_today": self.log_types().count("LOGIN"),
                "failed_today": self.log_types().count("LOGIN_FAILED"), "total_logs": len(self.logs)}

    def get_activity_types(self):
        return sorted(set(self.log_types()))

    def get_activity_logs(self, activity_type=None, search_text=None, limit=300):
        rows = []
        for i, log in enumerate(self.logs, 1):
            user = self.get_user_by_id(log["user_id"]) or {}
            rows.append({"log_id": i, "created_at": log["created_at"].isoformat(), "activity_type": log["activity_type"],
                         "status": log["status"], "user_name": user.get("full_name", "(unknown)"),
                         "email": user.get("email"), "description": log["description"],
                         "entity_type": log["entity_type"], "entity_id": log["entity_id"],
                         "details": log["details"], "session_id": log["session_id"]})
        return list(reversed(rows))[:limit]

    def get_all_users(self):
        return [{k: u[k] for k in ("user_id", "full_name", "email", "role")} for u in self.users]


def sample_listing(listing_id, title, destination, area, price):
    return {"id": listing_id, "property_id": listing_id, "title": title, "subtitle": "Test subtitle",
            "destination": destination, "area": area, "category": "Amazing pools", "badge": "Superhost",
            "price_per_night": price, "rating": 4.9, "review_count": 10, "max_guests": 4,
            "has_pool": 1, "has_wifi": 1, "host_superhost": 1, "latitude": -8.5, "longitude": 115.2,
            "image_urls": "https://example.com/a.jpg"}


@contextlib.contextmanager
def patched_database(fake):
    # Replace every database.<function> that the fake also defines; block real connections.
    names = [n for n in dir(fake) if not n.startswith("_") and callable(getattr(fake, n))
             and hasattr(database, n)]
    patchers = [mock.patch.object(database, n, getattr(fake, n)) for n in names]

    def no_real_mysql(*args, **kwargs):
        raise AssertionError("A mocked test tried to open a real MySQL connection.")

    patchers.append(mock.patch.object(database, "get_connection", no_real_mysql))
    for p in patchers:
        p.start()
    try:
        yield fake
    finally:
        for p in reversed(patchers):
            p.stop()
