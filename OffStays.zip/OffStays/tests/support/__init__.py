# Shared helpers for the OFFSTAYS tests (fakes and the safe test-database sandbox).
