# tests package for OFFSTAYS.
#
# Layout:
#   tests/unit/                -> fast tests of single functions (no MySQL needed)
#   tests/integration_mocked/  -> several real modules working together, MySQL replaced by fakes
#   tests/integration_db/      -> real modules + a real, separate MySQL test database
#   tests/support/             -> shared fakes and the safe test-database helper
#
# Run everything from the project root:
#   python -m unittest discover -s tests -t .

import logging

import streamlit  # noqa: F401  (import first: Streamlit sets up its own loggers when imported)
from streamlit.runtime.scriptrunner_utils import script_run_context  # noqa: F401

# Streamlit prints "missing ScriptRunContext" when its modules are used outside `streamlit run`.
# That is expected in tests, so we hide the warning to keep the test output readable.
logging.getLogger("streamlit.runtime.scriptrunner_utils.script_run_context").setLevel(logging.ERROR)
