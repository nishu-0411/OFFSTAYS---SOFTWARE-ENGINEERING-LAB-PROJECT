# Real-database integration tests for the other user workflows: messages and automated host
# replies, wishlist, notifications, host applications, Explore search, and admin queries.

import datetime
import unittest

import database
import page_explore
import page_messages
import pricing
from tests.integration_db.base import RealDatabaseTestCase
from tests.support import db_sandbox

CARD = {"method": "Card (demo)", "card_last4": "1111"}


def book(user_id, session_id, listing_id, price):
    check_in, check_out = db_sandbox.unique_stay_dates()
    p = pricing.calculate_price_breakdown(price, datetime.date.fromisoformat(check_in), datetime.date.fromisoformat(check_out))
    payload = {"listing_id": listing_id, "listing_title": "Test Stay", "check_in": check_in, "check_out": check_out,
               "nights": p["nights"], "guests": 2, "stay_cost": p["stay_cost"], "cleaning_fee": p["cleaning_fee"],
               "service_fee": p["service_fee"], "taxes": p["taxes"], "total_price": p["total_price"], "host_note": ""}
    ok, message, ref = database.create_booking_transaction(user_id, session_id, payload, CARD)
    assert ok, message
    return check_in, check_out, ref


class MessagingTests(RealDatabaseTestCase):
    def test_automated_reply_uses_this_guests_real_booking_and_destination(self):
        user_id, session_id, _ = self.new_guest()
        book(user_id, session_id, "cliffside-uluwatu", 245)
        pin = database.get_latest_booking_for_listing(user_id, "cliffside-uluwatu")["keyless_pin"]
        self.assertIn(pin, page_messages.get_automated_host_reply("What is the gate passcode?", "cliffside-uluwatu", user_id))
        # Airport comes from the destinations table (Bali -> Ngurah Rai, DPS).
        airport_reply = page_messages.get_automated_host_reply("airport pickup?", "cliffside-uluwatu", user_id)
        self.assertIn("(DPS)", airport_reply)
        # A different guest without a booking must not receive the PIN.
        stranger_id, _, _ = self.new_guest()
        self.assertNotIn(pin, page_messages.get_automated_host_reply("pin?", "cliffside-uluwatu", stranger_id))

    def test_unread_counter_and_mark_thread_read(self):
        user_id, session_id, _ = self.new_guest()
        book(user_id, session_id, "pajangan-villa", 210)
        self.assertEqual(database.get_unread_message_count(user_id), 1)  # host welcome message
        database.send_message(user_id, "pajangan-villa", "guest", "Hello!")
        self.assertEqual(database.get_unread_message_count(user_id), 1)  # guest's own messages never count
        self.assertEqual(database.mark_thread_read(user_id, "pajangan-villa"), 1)
        self.assertEqual(database.get_unread_message_count(user_id), 0)
        self.assertEqual(database.mark_thread_read(user_id, "pajangan-villa"), 0)

    def test_conversation_list_is_per_guest_and_newest_first(self):
        user_id, session_id, _ = self.new_guest()
        book(user_id, session_id, "auman-highland", 98)
        book(user_id, session_id, "architectural-canggu", 340)
        conversations = database.get_conversations_summary(user_id)
        self.assertEqual([c["id"] for c in conversations], ["architectural-canggu", "auman-highland"])
        database.send_message(user_id, "auman-highland", "guest", "Is there firewood?")
        self.assertEqual(database.get_conversations_summary(user_id)[0]["id"], "auman-highland")
        other_id, _, _ = self.new_guest()
        self.assertEqual(database.get_conversations_summary(other_id), [])


class WishlistNotificationAndHostTests(RealDatabaseTestCase):
    def test_wishlist_toggle_is_persisted_per_user(self):
        user_id, _, _ = self.new_guest()
        other_id, _, _ = self.new_guest()
        self.assertTrue(database.toggle_saved_listing(user_id, "villa-paradiso"))
        self.assertEqual(database.get_saved_listing_ids(user_id), ["villa-paradiso"])
        self.assertEqual(database.get_saved_listing_ids(other_id), [])
        self.assertFalse(database.toggle_saved_listing(user_id, "villa-paradiso"))
        self.assertEqual(database.get_saved_listing_ids(user_id), [])

    def test_notifications_are_private_and_filterable(self):
        user_id, session_id, _ = self.new_guest()
        other_id, _, _ = self.new_guest()
        book(user_id, session_id, "cabin-seminyak", 135)
        self.assertEqual(len(database.get_notifications(user_id, "Bookings")), 2)
        self.assertEqual([n["kind"] for n in database.get_notifications(user_id, "Account")], ["account"])
        self.assertEqual(database.get_unread_notification_count(user_id), 3)

        # Another guest trying to mark this notification as read changes nothing.
        target = database.get_notifications(user_id)[0]["notification_id"]
        database.mark_notification_as_read(other_id, target)
        self.assertEqual(database.get_unread_notification_count(user_id), 3)
        database.mark_notification_as_read(user_id, target)
        self.assertEqual(database.get_unread_notification_count(user_id), 2)
        database.mark_all_notifications_as_read(user_id)
        self.assertEqual(database.get_unread_notification_count(user_id), 0)
        self.assertEqual(database.get_unread_notification_count(other_id), 1)  # untouched

    def test_host_application_is_saved_with_notification(self):
        user_id, _, email = self.new_guest()
        before = database.get_host_application_count()
        app_id = database.submit_host_application(user_id, "Test Guest", email, "Anjuna, Goa", "Beachfront",
                                                  "Two bedroom villa with a plunge pool near the beach.")
        self.assertEqual(database.get_host_application_count(), before + 1)
        mine = database.get_user_host_applications(user_id)
        self.assertEqual((mine[0]["application_id"], mine[0]["status"]), (app_id, "Submitted"))
        self.assertIn(f"Application #{app_id}", database.get_notifications(user_id, "Account")[0]["description"])


class ExploreSearchTests(RealDatabaseTestCase):
    def test_listings_come_with_photos_amenities_and_destination_data(self):
        listings = database.get_all_listings()
        self.assertEqual(len(listings), 100)
        paradiso = next(l for l in listings if l["id"] == "villa-paradiso")
        self.assertEqual((paradiso["destination"], paradiso["area"], paradiso["host_name"]), ("Bali", "Ubud", "Wayan & Made"))
        self.assertEqual(len(paradiso["image_urls"].split("|")), 8)
        self.assertIn("Private heated infinity pool (18m)", paradiso["amenities"])
        self.assertEqual((paradiso["has_pool"], paradiso["has_wifi"]), (1, 1))
        # Auman Glass House has a sauna but no pool or internet in the sample data.
        auman = next(l for l in listings if l["id"] == "auman-highland")
        self.assertEqual((auman["has_pool"], auman["has_wifi"]), (0, 0))

    def test_destination_menus_match_the_data(self):
        destinations = {d["name"]: d for d in database.get_destinations()}
        self.assertEqual(len(destinations), 14)
        self.assertEqual(destinations["Bali"]["property_count"], 15)
        self.assertEqual(destinations["Maldives"]["country"], "Maldives")
        self.assertIn("Zermatt", database.get_areas("Swiss Alps"))
        self.assertEqual(database.get_price_bounds(), (50, 1110))

    def test_search_hides_a_property_once_it_is_booked(self):
        user_id, session_id, _ = self.new_guest()
        check_in, check_out, _ = book(user_id, session_id, "auman-highland", 98)

        def search():
            return page_explore.filter_stays(
                database.get_all_listings(), "Bali", page_explore.ALL_AREAS, "All Categories", 0, 2000,
                False, False, False, 2, database.get_unavailable_listing_ids(check_in, check_out))

        ids = [s["id"] for s in search()]
        self.assertNotIn("auman-highland", ids)
        self.assertIn("villa-paradiso", ids)
        self.assertEqual(len(ids), 14)  # 15 Bali stays minus the booked one


class AdminQueryTests(RealDatabaseTestCase):
    def test_platform_stats_and_activity_log_filters(self):
        user_id, _, email = self.new_guest()
        stats = database.get_platform_stats()
        self.assertEqual(stats["users"], self.scalar("SELECT COUNT(*) FROM users"))
        self.assertEqual(stats["properties"], 100)
        self.assertGreaterEqual(stats["logins_today"], 1)
        self.assertIn("REGISTER", database.get_activity_types())

        logs = database.get_activity_logs("REGISTER", email, 10)
        self.assertEqual(len(logs), 1)
        self.assertEqual((logs[0]["email"], logs[0]["status"]), (email, "SUCCESS"))
        self.assertTrue(all(row["activity_type"] == "LOGIN" for row in database.get_activity_logs("LOGIN", None, 50)))

    def test_user_activity_and_sessions_for_profile_page(self):
        user_id, session_id, _ = self.new_guest()
        activity = database.get_user_activity(user_id)
        self.assertEqual([a["activity_type"] for a in activity], ["LOGIN", "REGISTER"])  # newest first
        self.assertEqual(database.get_user_sessions(user_id)[0]["session_id"], session_id)


if __name__ == "__main__":
    unittest.main()
