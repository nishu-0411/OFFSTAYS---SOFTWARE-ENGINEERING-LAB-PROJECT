# End-to-end style integration test: the REAL app.py (via Streamlit AppTest) + REAL modules
# + the REAL MySQL test database. No browser is needed, but every layer is exercised:
# UI form -> auth.py -> database.py -> MySQL -> back to the rendered page.

import logging
import os
import unittest

from streamlit.testing.v1 import AppTest

from tests.integration_db.base import RealDatabaseTestCase

APP_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "app.py"))
logging.getLogger("streamlit").setLevel(logging.ERROR)


class AppAgainstRealDatabaseTests(RealDatabaseTestCase):
    use_fake_streamlit = False  # the app must use Streamlit's real session state

    def start(self):
        at = AppTest.from_file(APP_PATH, default_timeout=60)
        at.run()
        self.assertEqual(len(at.exception), 0, [e.value for e in at.exception])
        return at

    def login(self, at, email, password):
        inputs = {t.label: t for t in at.text_input}
        inputs["Email"].input(email)
        inputs["Password"].input(password)
        next(b for b in at.button if b.label == "Log in").click()
        at.run()
        self.assertEqual(len(at.exception), 0, [e.value for e in at.exception])

    def click_sidebar(self, at, label):
        next(b for b in at.sidebar.button if b.label == label).click()
        at.run()
        self.assertEqual(len(at.exception), 0, [e.value for e in at.exception])

    def test_seeded_guest_logs_in_and_sees_her_trips(self):
        at = self.start()
        before = self.scalar("SELECT COUNT(*) FROM user_sessions WHERE user_id = 2")
        self.login(at, "sarah.vance@example.com", "Password@123")
        self.assertIn("Find Your Sanctuary", [t.value for t in at.title])
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM user_sessions WHERE user_id = 2"), before + 1)

        self.click_sidebar(at, "My Trips")
        self.assertIn("My Trips & Activity", [t.value for t in at.title])
        # Sarah's sample upcoming booking at Villa Paradiso is listed on the page.
        headings = [m.value for m in at.markdown]
        self.assertTrue(any("Villa Paradiso" in h for h in headings), headings[:10])

        # Every step was audited in MySQL: login, the Explore search, then opening My Trips.
        logs = self.query("SELECT activity_type, description FROM activity_logs WHERE user_id = 2 ORDER BY log_id DESC LIMIT 3")
        self.assertEqual([l["activity_type"] for l in logs], ["PAGE_VIEW", "SEARCH", "LOGIN"])
        self.assertEqual(logs[0]["description"], "Opened My Trips")

    def test_admin_dashboard_shows_live_database_numbers(self):
        at = self.start()
        self.login(at, "admin@offstays.com", "Admin@123")
        self.click_sidebar(at, "🛡️ Admin Dashboard")
        self.assertIn("🛡️ Admin Dashboard", [t.value for t in at.title])
        users_metric = next(m for m in at.metric if m.label == "Users")
        self.assertEqual(int(users_metric.value), self.scalar("SELECT COUNT(*) FROM users"))

    def test_wrong_password_in_ui_is_recorded_in_mysql(self):
        at = self.start()
        before = self.scalar("SELECT COUNT(*) FROM activity_logs WHERE activity_type = 'LOGIN_FAILED'")
        self.login(at, "sarah.vance@example.com", "not-her-password")
        self.assertIn("Incorrect email or password.", [e.value for e in at.error])
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM activity_logs WHERE activity_type = 'LOGIN_FAILED'"), before + 1)


if __name__ == "__main__":
    unittest.main()
