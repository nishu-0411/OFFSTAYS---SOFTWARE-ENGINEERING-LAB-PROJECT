# Real-database integration tests for the booking lifecycle:
# pricing.py -> database.create_booking_transaction -> retrieval -> cancellation ->
# completion -> review, all against the separate MySQL test database.

import datetime
import threading
import unittest

import database
import page_trips
import pricing
from tests.integration_db.base import RealDatabaseTestCase
from tests.support import db_sandbox

PROPERTY = "villa-paradiso"  # sample property: $185 / night, max 8 guests
CARD = {"method": "Card (demo)", "card_last4": "9010"}


def priced_booking(listing_id, check_in, check_out, price_per_night=185, guests=2):
    # Builds the same payload page_checkout.py builds, using the real pricing rules.
    price = pricing.calculate_price_breakdown(price_per_night, datetime.date.fromisoformat(check_in),
                                              datetime.date.fromisoformat(check_out))
    return {"listing_id": listing_id, "listing_title": "Test Stay", "check_in": check_in, "check_out": check_out,
            "nights": price["nights"], "guests": guests, "stay_cost": price["stay_cost"],
            "cleaning_fee": price["cleaning_fee"], "service_fee": price["service_fee"],
            "taxes": price["taxes"], "total_price": price["total_price"], "host_note": ""}


class BookingCreationTests(RealDatabaseTestCase):
    def test_booking_transaction_writes_every_related_row(self):
        user_id, session_id, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_stay_dates(nights=4)
        ok, message, ref_code = database.create_booking_transaction(
            user_id, session_id, priced_booking(PROPERTY, check_in, check_out), CARD)
        self.assertTrue(ok, message)

        booking = self.query("SELECT * FROM bookings WHERE ref_code = %s", (ref_code,))[0]
        self.assertEqual((booking["user_id"], booking["status"], booking["nights"]), (user_id, "Confirmed", 4))
        self.assertEqual((booking["stay_cost"], booking["taxes"], booking["total_price"]), (740, 74, 899))
        self.assertRegex(booking["keyless_pin"], r"^\d{4}#$")

        payment = self.query("SELECT * FROM payments WHERE booking_id = %s", (booking["booking_id"],))[0]
        self.assertEqual((payment["amount"], payment["payment_status"], payment["card_last4"]), (899, "Paid", "9010"))

        messages = database.get_messages_for_listing(user_id, PROPERTY)
        self.assertEqual([m["sender"] for m in messages], ["system", "host"])
        self.assertIn(booking["keyless_pin"], messages[1]["text"])
        titles = [n["title"] for n in database.get_notifications(user_id, "Bookings")]
        self.assertEqual(sorted(titles), ["Booking Confirmed", "Check-In Instructions"])

        logs = self.query("SELECT activity_type, session_id FROM activity_logs WHERE user_id = %s "
                          "AND activity_type IN ('PAYMENT_SUCCESS', 'BOOKING_CREATED') ORDER BY log_id", (user_id,))
        self.assertEqual(logs, [{"activity_type": "PAYMENT_SUCCESS", "session_id": session_id},
                                {"activity_type": "BOOKING_CREATED", "session_id": session_id}])

    def test_booked_dates_become_unavailable_but_neighbouring_dates_stay_free(self):
        user_id, session_id, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_stay_dates(nights=4)
        database.create_booking_transaction(user_id, session_id, priced_booking(PROPERTY, check_in, check_out), CARD)
        day = datetime.date.fromisoformat
        shift = lambda d, n: (day(d) + datetime.timedelta(days=n)).isoformat()

        self.assertFalse(database.is_listing_available(PROPERTY, check_in, check_out))         # same dates
        self.assertFalse(database.is_listing_available(PROPERTY, shift(check_in, 1), shift(check_out, 2)))  # overlap
        self.assertTrue(database.is_listing_available(PROPERTY, check_out, shift(check_out, 2)))  # starts at checkout
        self.assertTrue(database.is_listing_available(PROPERTY, shift(check_in, -2), check_in))   # ends at check-in
        self.assertIn(PROPERTY, database.get_unavailable_listing_ids(check_in, check_out))
        self.assertTrue(database.is_listing_available("cliffside-uluwatu", check_in, check_out))  # other property

    def test_second_guest_cannot_book_the_same_dates(self):
        first_id, first_session, _ = self.new_guest()
        second_id, second_session, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_stay_dates()
        payload = priced_booking(PROPERTY, check_in, check_out)
        self.assertTrue(database.create_booking_transaction(first_id, first_session, payload, CARD)[0])
        ok, message, ref = database.create_booking_transaction(second_id, second_session, payload, CARD)
        self.assertFalse(ok)
        self.assertIn("just booked", message)
        self.assertIsNone(ref)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM bookings WHERE user_id = %s", (second_id,)), 0)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM payments WHERE user_id = %s", (second_id,)), 0)
        self.assertIn("BOOKING_FAILED", self.log_types(second_id))

    def test_two_simultaneous_bookings_for_same_dates_only_one_wins(self):
        # Two threads try to book at the same moment. SELECT ... FOR UPDATE on the property row
        # makes the second transaction wait, re-check, and fail. This is the race-condition guard.
        guests = [self.new_guest() for _ in range(2)]
        check_in, check_out = db_sandbox.unique_stay_dates()
        payload = priced_booking("cliffside-uluwatu", check_in, check_out, price_per_night=245)
        start = threading.Barrier(2)
        results = []

        def book(user_id, session_id):
            start.wait()
            results.append(database.create_booking_transaction(user_id, session_id, dict(payload), CARD)[0])

        threads = [threading.Thread(target=book, args=(g[0], g[1])) for g in guests]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)
        self.assertEqual(sorted(results), [False, True])
        count = self.scalar("""SELECT COUNT(*) FROM bookings WHERE property_id = 'cliffside-uluwatu'
                               AND status = 'Confirmed' AND check_in = %s""", (check_in,))
        self.assertEqual(count, 1)

    def test_invalid_dates_are_rejected_by_check_constraint_and_rolled_back(self):
        user_id, session_id, _ = self.new_guest()
        check_in, _ = db_sandbox.unique_stay_dates()
        payload = priced_booking(PROPERTY, check_in, check_in)  # check_out == check_in
        ok, message, _ = database.create_booking_transaction(user_id, session_id, payload, CARD)
        self.assertFalse(ok)
        self.assertTrue(message.startswith("Database transaction failed"))
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM bookings WHERE user_id = %s", (user_id,)), 0)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM messages WHERE user_id = %s", (user_id,)), 0)


class BookingRetrievalAndIsolationTests(RealDatabaseTestCase):
    def test_guest_sees_only_their_own_bookings_and_pins(self):
        owner_id, owner_session, _ = self.new_guest()
        other_id, _, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_stay_dates()
        database.create_booking_transaction(owner_id, owner_session, priced_booking(PROPERTY, check_in, check_out), CARD)

        mine = database.get_bookings_by_status(owner_id, ["Confirmed"])
        self.assertEqual(len(mine), 1)
        row = mine[0]
        self.assertEqual((row["listing_id"], row["destination"], row["payment_method"]), (PROPERTY, "Bali", "Card (demo)"))
        self.assertTrue(row["transaction_ref"].startswith("TXN"))
        self.assertTrue(row["listing_images"].startswith("https://"))
        self.assertEqual(database.get_bookings_by_status(other_id, ["Confirmed", "Completed", "Cancelled"]), [])
        self.assertIsNone(database.get_latest_booking_for_listing(other_id, PROPERTY))
        self.assertEqual(database.get_messages_for_listing(other_id, PROPERTY), [])


class CancellationTests(RealDatabaseTestCase):
    def book(self, nights=3):
        user_id, session_id, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_stay_dates(nights)
        ok, _, ref = database.create_booking_transaction(user_id, session_id, priced_booking(PROPERTY, check_in, check_out), CARD)
        self.assertTrue(ok)
        booking = self.query("SELECT * FROM bookings WHERE ref_code = %s", (ref,))[0]
        return user_id, session_id, booking

    def test_early_cancellation_gives_full_refund_and_frees_dates(self):
        user_id, session_id, booking = self.book()
        refund, note = page_trips.calculate_cancellation_refund(booking, days_to_arrival=30)
        self.assertTrue(database.cancel_booking(user_id, session_id, booking["booking_id"], refund, note))
        after = self.query("SELECT status, refund_amount, cancelled_at FROM bookings WHERE booking_id = %s",
                           (booking["booking_id"],))[0]
        self.assertEqual((after["status"], after["refund_amount"]), ("Cancelled", booking["total_price"]))
        self.assertIsNotNone(after["cancelled_at"])
        payment = self.query("SELECT payment_status, refunded_amount FROM payments WHERE booking_id = %s",
                             (booking["booking_id"],))[0]
        self.assertEqual(payment, {"payment_status": "Refunded", "refunded_amount": booking["total_price"]})
        self.assertTrue(database.is_listing_available(PROPERTY, booking["check_in"], booking["check_out"]))
        self.assertIn("BOOKING_CANCELLED", self.log_types(user_id))

    def test_late_cancellation_gives_partial_refund(self):
        user_id, session_id, booking = self.book(nights=3)  # 3 x 185 = 555 stay cost
        refund, note = page_trips.calculate_cancellation_refund(booking, days_to_arrival=1)
        self.assertEqual(refund, 322.5)  # 555 / 2 + 45
        database.cancel_booking(user_id, session_id, booking["booking_id"], refund, note)
        payment = self.query("SELECT payment_status, refunded_amount FROM payments WHERE booking_id = %s",
                             (booking["booking_id"],))[0]
        self.assertEqual(payment, {"payment_status": "Partially Refunded", "refunded_amount": 322.5})

    def test_booking_cannot_be_cancelled_twice_or_by_another_guest(self):
        user_id, session_id, booking = self.book()
        stranger_id, stranger_session, _ = self.new_guest()
        self.assertFalse(database.cancel_booking(stranger_id, stranger_session, booking["booking_id"], 1, "x"))
        self.assertEqual(self.scalar("SELECT status FROM bookings WHERE booking_id = %s", (booking["booking_id"],)),
                         "Confirmed")
        self.assertTrue(database.cancel_booking(user_id, session_id, booking["booking_id"], 10, "x"))
        self.assertFalse(database.cancel_booking(user_id, session_id, booking["booking_id"], 10, "x"))
        self.assertEqual(self.log_types(user_id).count("BOOKING_CANCELLED"), 1)


class CompletionAndReviewTests(RealDatabaseTestCase):
    def past_booking(self, listing_id="cabin-seminyak"):
        # A stay in the past (2021) so update_completed_bookings() should mark it Completed.
        user_id, session_id, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_past_stay_dates(nights=3)
        payload = priced_booking(listing_id, check_in, check_out, 135)
        ok, _, ref = database.create_booking_transaction(user_id, session_id, payload, CARD)
        self.assertTrue(ok)
        return user_id, session_id, self.query("SELECT booking_id FROM bookings WHERE ref_code = %s", (ref,))[0]["booking_id"]

    def test_past_confirmed_stays_become_completed_future_ones_do_not(self):
        user_id, session_id, past_id = self.past_booking()
        check_in, check_out = db_sandbox.unique_stay_dates()
        _, _, future_ref = database.create_booking_transaction(user_id, session_id,
                                                               priced_booking(PROPERTY, check_in, check_out), CARD)
        database.update_completed_bookings()
        self.assertEqual(self.scalar("SELECT status FROM bookings WHERE booking_id = %s", (past_id,)), "Completed")
        self.assertEqual(self.scalar("SELECT status FROM bookings WHERE ref_code = %s", (future_ref,)), "Confirmed")

    def test_review_updates_running_average_and_blocks_duplicates(self):
        user_id, session_id, booking_id = self.past_booking("auman-highland")
        database.update_completed_bookings()
        before = self.query("SELECT rating, review_count FROM properties WHERE property_id = 'auman-highland'")[0]
        ok, message = database.add_review(user_id, session_id, "auman-highland", booking_id,
                                          "Test Guest", "Ahmedabad, India", 3.0, "Cold but cosy")
        self.assertTrue(ok, message)
        after = self.query("SELECT rating, review_count FROM properties WHERE property_id = 'auman-highland'")[0]
        expected = round((before["rating"] * before["review_count"] + 3.0) / (before["review_count"] + 1), 2)
        self.assertEqual(after["review_count"], before["review_count"] + 1)
        self.assertAlmostEqual(after["rating"], expected, places=2)
        self.assertTrue(database.has_reviewed_booking(booking_id))
        newest = database.get_listing_reviews("auman-highland")[0]
        self.assertEqual(newest["comment"], "Cold but cosy")

        again = database.add_review(user_id, session_id, "auman-highland", booking_id, "Test Guest", "x", 5.0, "Again")
        self.assertEqual(again, (False, "A review for this booking already exists."))
        self.assertEqual(self.scalar("SELECT review_count FROM properties WHERE property_id = 'auman-highland'"),
                         after["review_count"])

    def test_cannot_review_upcoming_or_someone_elses_stay(self):
        user_id, session_id, _ = self.new_guest()
        check_in, check_out = db_sandbox.unique_stay_dates()
        _, _, ref = database.create_booking_transaction(user_id, session_id, priced_booking(PROPERTY, check_in, check_out), CARD)
        upcoming_id = self.scalar("SELECT booking_id FROM bookings WHERE ref_code = %s", (ref,))
        self.assertFalse(database.add_review(user_id, session_id, PROPERTY, upcoming_id, "A", "B", 5.0, "x")[0])

        owner_id, _, past_id = self.past_booking()
        database.update_completed_bookings()
        self.assertFalse(database.add_review(user_id, session_id, "cabin-seminyak", past_id, "A", "B", 5.0, "x")[0])
        self.assertFalse(database.has_reviewed_booking(past_id))


if __name__ == "__main__":
    unittest.main()
