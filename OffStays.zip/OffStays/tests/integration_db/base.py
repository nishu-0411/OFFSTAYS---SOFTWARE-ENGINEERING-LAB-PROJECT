# Shared base class for the real-database integration tests.
#
# setUpClass:
#   - skips the whole class with a clear message if the test database is not configured,
#   - builds the separate test database once per run and points the app's db_config at it,
#   - double-checks the connection really lands in the marked test database.
# tearDownClass puts the original db_config values back.

import unittest
from unittest import mock

import auth
import database
from tests.support import db_sandbox
from tests.support.fakes import FakeStreamlit


class RealDatabaseTestCase(unittest.TestCase):
    # Non-UI tests call auth.py directly, so they need a fake `st.session_state`.
    # AppTest-based tests set this to False and use Streamlit's real session instead.
    use_fake_streamlit = True

    @classmethod
    def setUpClass(cls):
        reason = db_sandbox.skip_reason()
        if reason:
            raise unittest.SkipTest(reason)
        db_sandbox.use_test_database()

    @classmethod
    def tearDownClass(cls):
        db_sandbox.restore_app_database_config()

    def setUp(self):
        # Safety check before every test: still connected to the marked test database?
        db_sandbox.verify_connected_to_test_database()
        if self.use_fake_streamlit:
            self.st = FakeStreamlit()
            patcher = mock.patch.object(auth, "st", self.st)
            patcher.start()
            self.addCleanup(patcher.stop)

    # ---------------------------------------------------------------- helpers
    def new_guest(self, name="Test Guest", password="Secure@2026"):
        # Registers a brand-new guest through the REAL auth.register_user and returns
        # (user_id, session_id, email). Each test gets its own user, so tests stay independent.
        email = db_sandbox.unique_email()
        self.st.session_state.clear()
        ok, message = auth.register_user(name, email, "", password, password, "Ahmedabad", "India")
        self.assertTrue(ok, message)
        user = self.st.session_state["user"]
        return user["user_id"], self.st.session_state["session_id"], email

    def query(self, sql, params=()):
        return database.fetch_all(sql, params)

    def scalar(self, sql, params=()):
        row = database.fetch_one(sql, params)
        return None if row is None else list(row.values())[0]

    def log_types(self, user_id):
        rows = self.query("SELECT activity_type FROM activity_logs WHERE user_id = %s ORDER BY log_id", (user_id,))
        return [r["activity_type"] for r in rows]
