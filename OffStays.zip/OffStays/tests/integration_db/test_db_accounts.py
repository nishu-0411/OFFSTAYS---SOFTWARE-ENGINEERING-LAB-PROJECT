# Real-database integration tests for accounts: auth.py + database.py + MySQL together.

import unittest

import pymysql

import auth
import database
from tests.integration_db.base import RealDatabaseTestCase
from tests.support import db_sandbox


class RegistrationAndLoginTests(RealDatabaseTestCase):
    def test_registration_writes_user_notification_session_and_logs(self):
        user_id, session_id, email = self.new_guest("Ketan Trivedi")
        user = database.get_user_by_email(email)
        self.assertEqual((user["full_name"], user["role"], user["is_active"]), ("Ketan Trivedi", "guest", 1))
        # Password is stored only as a PBKDF2 hash + salt.
        self.assertEqual(len(user["password_hash"]), 64)
        self.assertTrue(auth.verify_password("Secure@2026", user["password_hash"], user["password_salt"]))
        self.assertIsNotNone(user["last_login_at"])
        # Welcome notification and an open session row.
        notes = database.get_notifications(user_id)
        self.assertEqual([n["title"] for n in notes], ["Welcome to OFFSTAYS"])
        session = database.get_user_sessions(user_id)[0]
        self.assertEqual((session["session_id"], session["is_active"]), (session_id, 1))
        # REGISTER then LOGIN, and the LOGIN log is linked to the session row.
        self.assertEqual(self.log_types(user_id), ["REGISTER", "LOGIN"])
        self.assertEqual(self.scalar("SELECT session_id FROM activity_logs WHERE user_id = %s AND activity_type = 'LOGIN'",
                                     (user_id,)), session_id)

    def test_logout_closes_session_in_mysql(self):
        user_id, session_id, _ = self.new_guest()
        auth.logout_user()
        session = database.get_user_sessions(user_id)[0]
        self.assertEqual(session["is_active"], 0)
        self.assertIsNotNone(session["logout_at"])
        self.assertEqual(self.log_types(user_id)[-1], "LOGOUT")

    def test_login_with_seeded_sample_user(self):
        # Sarah Vance comes from sql/02_seed_data.sql with password Password@123.
        ok, message = auth.login_user("sarah.vance@example.com", "Password@123")
        self.assertTrue(ok, message)
        self.assertEqual(self.st.session_state["user"]["full_name"], "Sarah Vance")

    def test_duplicate_email_is_rejected_by_app_and_by_unique_constraint(self):
        _, _, email = self.new_guest()
        auth.logout_user()
        ok, message = auth.register_user("Someone Else", email, "", "Secure@2026", "Secure@2026", "", "")
        self.assertFalse(ok)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM users WHERE email = %s", (email,)), 1)
        # Even if the app check were skipped, MySQL's UNIQUE key stops it and the transaction rolls back.
        before = self.scalar("SELECT COUNT(*) FROM notifications")
        h, s = auth.hash_password("Secure@2026")
        with self.assertRaises(pymysql.err.IntegrityError):
            database.create_user("Someone Else", email, "", h, s, "", "")
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM notifications"), before)

    def test_failed_logins_are_counted_from_mysql_json_and_trigger_lockout(self):
        _, _, email = self.new_guest()
        auth.logout_user()
        for _ in range(5):
            self.assertFalse(auth.login_user(email, "Wrong@2026")[0])
        # count_recent_failed_logins reads the email out of the JSON `details` column.
        self.assertEqual(database.count_recent_failed_logins(email, 15), 5)
        ok, message = auth.login_user(email, "Secure@2026")
        self.assertFalse(ok)
        self.assertIn("Too many failed attempts", message)
        # Move the failures 20 minutes into the past: the 15-minute window no longer covers them.
        database.execute("""UPDATE activity_logs SET created_at = created_at - INTERVAL 20 MINUTE
                            WHERE activity_type = 'LOGIN_FAILED' AND JSON_UNQUOTE(JSON_EXTRACT(details, '$.email')) = %s""",
                         (email,))
        self.assertEqual(database.count_recent_failed_logins(email, 15), 0)
        self.assertTrue(auth.login_user(email, "Secure@2026")[0])

    def test_unknown_email_failure_is_logged_without_user(self):
        email = db_sandbox.unique_email("ghost")
        auth.login_user(email, "Whatever@1")
        rows = self.query("""SELECT user_id, status FROM activity_logs WHERE activity_type = 'LOGIN_FAILED'
                             AND JSON_UNQUOTE(JSON_EXTRACT(details, '$.email')) = %s""", (email,))
        self.assertEqual(rows, [{"user_id": None, "status": "FAILED"}])

    def test_deactivated_account_is_refused(self):
        user_id, _, email = self.new_guest()
        auth.logout_user()
        database.execute("UPDATE users SET is_active = 0 WHERE user_id = %s", (user_id,))
        ok, message = auth.login_user(email, "Secure@2026")
        self.assertFalse(ok)
        self.assertIn("deactivated", message)

    def test_password_change_is_persisted(self):
        user_id, _, email = self.new_guest()
        ok, _ = auth.change_password("Secure@2026", "Newpass#2027", "Newpass#2027")
        self.assertTrue(ok)
        auth.logout_user()
        self.assertFalse(auth.login_user(email, "Secure@2026")[0])
        self.assertTrue(auth.login_user(email, "Newpass#2027")[0])
        self.assertIn("PASSWORD_CHANGED", self.log_types(user_id))

    def test_profile_update_and_refresh(self):
        user_id, _, _ = self.new_guest()
        database.update_profile(user_id, "Ketan T", "+91 90000 00000", "Vadodara", "India")
        auth.refresh_user()
        self.assertEqual(self.st.session_state["user"]["full_name"], "Ketan T")
        self.assertEqual(self.st.session_state["user"]["city"], "Vadodara")


class SandboxIdentityTests(RealDatabaseTestCase):
    def test_app_connection_points_at_marked_test_database(self):
        settings = db_sandbox.load_settings()
        self.assertEqual(self.scalar("SELECT DATABASE()"), settings["name"])
        self.assertNotEqual(settings["name"], "offstays")
        self.assertEqual(self.scalar(f"SELECT created_for FROM `{db_sandbox.MARKER_TABLE}`"), settings["name"])

    def test_health_check_passes_on_test_database(self):
        self.assertEqual(database.check_database_ready(), (True, ""))

    def test_health_check_reports_missing_database_and_wrong_password(self):
        # Read-only connection attempts with deliberately wrong settings; nothing is modified.
        import db_config
        original_name, original_password = db_config.DB_NAME, db_config.DB_PASSWORD
        try:
            db_config.DB_NAME = "offstays_missing_test"
            ok, message = database.check_database_ready()
            self.assertFalse(ok)
            self.assertIn("does not exist yet", message)
            db_config.DB_NAME = original_name
            db_config.DB_PASSWORD = original_password + "-wrong"
            ok, message = database.check_database_ready()
            self.assertFalse(ok)
            self.assertIn("rejected the username/password", message)
        finally:
            db_config.DB_NAME, db_config.DB_PASSWORD = original_name, original_password


if __name__ == "__main__":
    unittest.main()
