# Real-database integration tests. They use a SEPARATE MySQL database (default name
# `offstays_test`) built from the project's SQL scripts by tests/support/db_sandbox.py.
# They are skipped automatically unless the test database is enabled (see TESTING.md).
