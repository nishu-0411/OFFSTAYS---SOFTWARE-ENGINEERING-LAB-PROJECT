# Mocked integration tests: several REAL modules work together; only MySQL is replaced
# (by tests/support/memory_db.py or tests/support/fakes.py). No database server is needed.
