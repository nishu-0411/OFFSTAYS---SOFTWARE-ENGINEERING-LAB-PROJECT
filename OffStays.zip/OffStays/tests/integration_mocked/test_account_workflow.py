# Mocked integration test: the REAL auth.py + activity.py working together over a full
# account lifecycle. MySQL is replaced by InMemoryDatabase, so the lockout rule is driven by
# the failed-login audit logs that auth.py itself writes, exactly like in the real app.

import datetime
import json
import unittest
from unittest import mock

import activity
import auth
from tests.support.fakes import FakeStreamlit
from tests.support.memory_db import InMemoryDatabase, patched_database


class AccountLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.db = InMemoryDatabase()
        self.st = FakeStreamlit()
        stack = [patched_database(self.db), mock.patch.object(auth, "st", self.st),
                 mock.patch.object(activity, "st", self.st)]
        for cm in stack:
            cm.__enter__()
            self.addCleanup(cm.__exit__, None, None, None)

    def register_ketan(self):
        return auth.register_user("Ketan Trivedi", "Ketan@Example.com", "+91 98765 43210",
                                  "Secure@2026", "Secure@2026", "Ahmedabad", "India")

    def test_register_logout_login_cycle_is_fully_audited(self):
        ok, _ = self.register_ketan()
        self.assertTrue(ok)
        user_id = self.st.session_state["user"]["user_id"]
        activity.log_event("SEARCH", "Searched stays: Bali")  # an action while signed in
        auth.logout_user()
        self.assertFalse(auth.is_logged_in())

        ok, message = auth.login_user("ketan@example.com", "Secure@2026")
        self.assertTrue(ok, message)
        self.assertEqual(self.db.log_types(user_id), ["REGISTER", "LOGIN", "SEARCH", "LOGOUT", "LOGIN"])
        # The SEARCH log is linked to the first login session; the second login opened session 2.
        search = next(l for l in self.db.logs if l["activity_type"] == "SEARCH")
        self.assertEqual(search["session_id"], 1)
        self.assertEqual(self.st.session_state["session_id"], 2)
        self.assertEqual(self.db.sessions[0]["is_active"], 0)

    def test_password_is_stored_hashed_and_old_password_stops_working_after_change(self):
        self.register_ketan()
        stored = self.db.users[0]
        self.assertNotEqual(stored["password_hash"], "Secure@2026")
        self.assertTrue(auth.verify_password("Secure@2026", stored["password_hash"], stored["password_salt"]))

        ok, _ = auth.change_password("Secure@2026", "Newpass#2027", "Newpass#2027")
        self.assertTrue(ok)
        auth.logout_user()
        self.assertEqual(auth.login_user("ketan@example.com", "Secure@2026"), (False, "Incorrect email or password."))
        self.assertTrue(auth.login_user("ketan@example.com", "Newpass#2027")[0])

    def test_five_wrong_passwords_lock_the_account_for_fifteen_minutes(self):
        self.register_ketan()
        auth.logout_user()
        for _ in range(5):
            self.assertEqual(auth.login_user("ketan@example.com", "Wrong@2026")[1], "Incorrect email or password.")
        # 6th attempt is blocked even with the correct password.
        ok, message = auth.login_user("ketan@example.com", "Secure@2026")
        self.assertFalse(ok)
        self.assertIn("Too many failed attempts", message)
        self.assertEqual(self.db.log_types().count("LOGIN_FAILED"), 5)
        self.assertEqual(self.db.log_types()[-1], "LOGIN_BLOCKED")

        # 16 minutes later the failures are outside the window and login works again.
        self.db.now += datetime.timedelta(minutes=16)
        ok, _ = auth.login_user("ketan@example.com", "Secure@2026")
        self.assertTrue(ok)

    def test_lockout_is_per_email(self):
        self.register_ketan()
        auth.logout_user()
        other_hash, other_salt = auth.hash_password("Password@123")
        self.db.add_user("Sarah Vance", "sarah.vance@example.com", other_hash, other_salt)
        for _ in range(5):
            auth.login_user("ketan@example.com", "Wrong@2026")
        self.assertTrue(auth.login_user("sarah.vance@example.com", "Password@123")[0])

    def test_failed_logins_never_store_the_typed_password(self):
        self.register_ketan()
        auth.logout_user()
        auth.login_user("ketan@example.com", "MySecretGuess#1")
        auth.login_user("nobody@example.com", "MySecretGuess#2")
        all_logs = json.dumps([l["details"] for l in self.db.logs])
        self.assertNotIn("MySecretGuess", all_logs)
        unknown = self.db.logs[-1]
        self.assertIsNone(unknown["user_id"])  # unknown email -> no user linked
        self.assertEqual(json.loads(unknown["details"])["reason"], "unknown_email")

    def test_registering_the_same_email_twice_fails(self):
        self.register_ketan()
        auth.logout_user()
        ok, message = self.register_ketan()
        self.assertFalse(ok)
        self.assertIn("already exists", message)
        self.assertEqual(len(self.db.users), 1)


if __name__ == "__main__":
    unittest.main()
