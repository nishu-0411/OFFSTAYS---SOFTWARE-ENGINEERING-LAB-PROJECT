# Mocked integration test: pricing.py -> page_checkout.validate_payment_details ->
# database.create_booking_transaction -> page_trips.calculate_cancellation_refund ->
# database.cancel_booking, all REAL code. Only the MySQL connection is a FakeConnection,
# so we can check that the numbers flow correctly from one module to the next.

import datetime
import unittest
from unittest import mock

import database
import page_checkout
import page_trips
import pricing
from tests.support.fakes import FakeConnection, FakeCursor


class CheckoutToCancellationTests(unittest.TestCase):
    def build_booking(self, price_per_night, check_in, check_out):
        # Same payload shape page_checkout.render() sends to the database.
        price = pricing.calculate_price_breakdown(price_per_night, check_in, check_out)
        return {"listing_id": "villa-paradiso", "listing_title": "Villa Paradiso",
                "check_in": check_in.isoformat(), "check_out": check_out.isoformat(),
                "nights": price["nights"], "guests": 2, "stay_cost": price["stay_cost"],
                "cleaning_fee": price["cleaning_fee"], "service_fee": price["service_fee"],
                "taxes": price["taxes"], "total_price": price["total_price"], "host_note": "Late arrival"}

    def test_priced_card_booking_is_saved_with_matching_amounts(self):
        booking = self.build_booking(185, datetime.date(2031, 1, 1), datetime.date(2031, 1, 5))
        error, payment = page_checkout.validate_payment_details(
            "Card (demo)", "Sarah Vance", "4000 1234 5678 9010", "12/29", "123", "", datetime.date(2026, 10, 27))
        self.assertIsNone(error)

        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None])
        with mock.patch.object(database, "get_connection", return_value=FakeConnection(cursor)):
            ok, _, ref_code = database.create_booking_transaction(2, 55, booking, payment)
        self.assertTrue(ok)

        booking_row = cursor.find("INSERT INTO bookings")[0][1]
        payment_row = cursor.find("INSERT INTO payments")[0][1]
        self.assertEqual(booking_row[7:11], (740.0, 45.0, 40.0, 74.0))  # stay, cleaning, service, taxes
        self.assertEqual(booking_row[11], 899.0)                       # total from pricing.py
        self.assertEqual(booking_row[12], "Late arrival")               # note for the host
        self.assertEqual(payment_row[3], 899.0)                        # payment amount == booking total
        self.assertEqual(payment_row[5], "9010")
        system_message = cursor.find("INSERT INTO messages")[0][1][2]
        self.assertIn(f"Ref: {ref_code}", system_message)
        self.assertIn("$899.00", system_message)

    def test_upi_payment_stores_masked_handle_only(self):
        booking = self.build_booking(1110, datetime.date(2031, 2, 1), datetime.date(2031, 2, 4))
        _, payment = page_checkout.validate_payment_details(
            "UPI (demo)", "", "", "", "", "sarah@okhdfcbank", datetime.date(2026, 10, 27))
        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None])
        with mock.patch.object(database, "get_connection", return_value=FakeConnection(cursor)):
            database.create_booking_transaction(2, 55, booking, payment)
        payment_row = cursor.find("INSERT INTO payments")[0][1]
        self.assertEqual(payment_row[5:7], (None, "sa****@okhdfcbank"))
        self.assertNotIn("sarah@okhdfcbank", str(cursor.executed))

    def test_late_cancellation_refund_flows_into_partial_payment_status(self):
        booking = self.build_booking(185, datetime.date(2031, 1, 1), datetime.date(2031, 1, 5))
        refund, note = page_trips.calculate_cancellation_refund(booking, days_to_arrival=1)
        self.assertEqual(refund, 415.0)  # 50% of 740 + 45 cleaning

        info = {"ref_code": "#OFS-12345", "status": "Confirmed", "total_price": booking["total_price"],
                "property_id": "villa-paradiso", "title": "Villa Paradiso"}
        cursor = FakeCursor(fetchone_results=[info])
        with mock.patch.object(database, "get_connection", return_value=FakeConnection(cursor)):
            self.assertTrue(database.cancel_booking(2, 55, 10, refund, note))
        self.assertEqual(cursor.find("UPDATE payments")[0][1][:2], ("Partially Refunded", 415.0))
        notification = cursor.find("INSERT INTO notifications")[0][1][1]
        self.assertIn("Simulated refund: $415.00", notification)

    def test_early_cancellation_refunds_everything(self):
        booking = self.build_booking(185, datetime.date(2031, 1, 1), datetime.date(2031, 1, 5))
        refund, note = page_trips.calculate_cancellation_refund(booking, days_to_arrival=30)
        info = {"ref_code": "#OFS-12345", "status": "Confirmed", "total_price": booking["total_price"],
                "property_id": "villa-paradiso", "title": "Villa Paradiso"}
        cursor = FakeCursor(fetchone_results=[info])
        with mock.patch.object(database, "get_connection", return_value=FakeConnection(cursor)):
            database.cancel_booking(2, 55, 10, refund, note)
        self.assertEqual(cursor.find("UPDATE payments")[0][1][:2], ("Refunded", 899.0))

    def test_invalid_payment_never_reaches_the_database(self):
        error, payment = page_checkout.validate_payment_details(
            "Card (demo)", "Sarah", "4000 1234 5678 9010", "01/24", "123", "", datetime.date(2026, 10, 27))
        self.assertIsNotNone(error)
        self.assertIsNone(payment)  # page_checkout.render() returns before create_booking_transaction


if __name__ == "__main__":
    unittest.main()
