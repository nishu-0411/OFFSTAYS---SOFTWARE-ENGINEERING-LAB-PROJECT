# Mocked integration test of the WHOLE Streamlit app (app.py) using Streamlit's own
# testing tool, AppTest. AppTest runs app.py without a browser, lets us type into inputs
# and click buttons, and then inspect what was rendered.
#
# MySQL is replaced by InMemoryDatabase, so these tests check the app's wiring:
#   database health check -> login gate -> sidebar/navigation -> role-based admin access -> logout.

import logging
import os
import unittest

from streamlit.testing.v1 import AppTest

import auth
from tests.support.memory_db import InMemoryDatabase, patched_database, sample_listing

APP_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "app.py")
logging.getLogger("streamlit").setLevel(logging.ERROR)  # hide "missing ScriptRunContext" noise


def make_fake_db():
    db = InMemoryDatabase()
    guest_hash, guest_salt = auth.hash_password("Password@123")
    admin_hash, admin_salt = auth.hash_password("Admin@123")
    db.add_user("Sarah Vance", "sarah.vance@example.com", guest_hash, guest_salt)
    db.add_user("OffStays Admin", "admin@offstays.com", admin_hash, admin_salt, role="admin")
    db.listings = [sample_listing("villa-paradiso", "Villa Paradiso", "Bali", "Ubud", 185),
                   sample_listing("zermatt-chalet", "Alpine Chalet", "Swiss Alps", "Zermatt", 425)]
    return db


class StreamlitAppTestCase(unittest.TestCase):
    def setUp(self):
        self.db = make_fake_db()
        cm = patched_database(self.db)
        cm.__enter__()
        self.addCleanup(cm.__exit__, None, None, None)
        self.at = AppTest.from_file(os.path.abspath(APP_PATH), default_timeout=60)

    def run_app(self):
        self.at.run()
        self.assertEqual(len(self.at.exception), 0, [e.value for e in self.at.exception])
        return self.at

    def login(self, email, password):
        self.run_app()
        inputs = {t.label: t for t in self.at.text_input}
        inputs["Email"].input(email)
        inputs["Password"].input(password)
        self.button("Log in").click()
        return self.run_app()

    def button(self, label, sidebar=False):
        buttons = self.at.sidebar.button if sidebar else self.at.button
        return next(b for b in buttons if b.label == label)

    def titles(self):
        return [t.value for t in self.at.title]

    def sidebar_buttons(self):
        return [b.label for b in self.at.sidebar.button]


class LoginGateTests(StreamlitAppTestCase):
    def test_visitor_sees_only_login_and_register(self):
        at = self.run_app()
        self.assertEqual([t.label for t in at.tabs], ["🔐 Log in", "✨ Create account"])
        self.assertEqual(self.sidebar_buttons(), [])        # no navigation before sign-in
        self.assertNotIn("Find Your Sanctuary", self.titles())

    def test_wrong_password_shows_error_and_stays_on_login(self):
        at = self.login("sarah.vance@example.com", "wrong-password")
        self.assertIn("Incorrect email or password.", [e.value for e in at.error])
        self.assertIsNone(at.session_state["user"])
        self.assertEqual(self.db.log_types(), ["LOGIN_FAILED"])

    def test_successful_login_opens_explore_with_sidebar(self):
        at = self.login("sarah.vance@example.com", "Password@123")
        self.assertIn("Find Your Sanctuary", self.titles())
        self.assertIn("Showing 2 stays", [s.value for s in at.subheader])
        self.assertIn("**Sarah Vance**", [m.value for m in at.sidebar.markdown])
        self.assertEqual(self.sidebar_buttons(),
                         ["Explore Stays", "Messages", "My Trips", "Become a Host", "My Profile", "🚪 Log out"])
        self.assertEqual(self.db.log_types(), ["LOGIN", "SEARCH"])

    def test_registration_form_creates_account_and_signs_in(self):
        self.run_app()
        inputs = {t.label: t for t in self.at.text_input}
        inputs["Full name *"].input("Ketan Trivedi")
        inputs["Email *"].input("ketan@example.com")
        inputs["Password *"].input("Secure@2026")
        inputs["Confirm password *"].input("Secure@2026")
        self.at.checkbox[0].check()  # accept terms
        self.button("Create account").click()
        at = self.run_app()
        self.assertEqual(at.session_state["user"]["email"], "ketan@example.com")
        self.assertIn("Find Your Sanctuary", self.titles())
        self.assertEqual(self.db.log_types()[:2], ["REGISTER", "LOGIN"])

    def test_registration_requires_accepting_terms(self):
        self.run_app()
        inputs = {t.label: t for t in self.at.text_input}
        inputs["Full name *"].input("Ketan Trivedi")
        inputs["Email *"].input("ketan@example.com")
        inputs["Password *"].input("Secure@2026")
        inputs["Confirm password *"].input("Secure@2026")
        self.button("Create account").click()
        at = self.run_app()
        self.assertIn("Please accept the terms to create an account.", [e.value for e in at.error])
        self.assertEqual(len(self.db.users), 2)  # no new user


class PermissionTests(StreamlitAppTestCase):
    def test_guest_has_no_admin_menu_and_cannot_force_admin_page(self):
        self.login("sarah.vance@example.com", "Password@123")
        self.assertNotIn("🛡️ Admin Dashboard", self.sidebar_buttons())
        # Simulate a guest trying to jump straight to the admin page.
        self.at.session_state["current_page"] = "admin"
        self.run_app()
        self.assertNotIn("🛡️ Admin Dashboard", self.titles())
        self.assertIn("Find Your Sanctuary", self.titles())

    def test_admin_can_open_dashboard_with_activity_log(self):
        self.login("admin@offstays.com", "Admin@123")
        self.assertIn("🛡️ Admin Dashboard", self.sidebar_buttons())
        self.button("🛡️ Admin Dashboard", sidebar=True).click()
        at = self.run_app()
        self.assertIn("🛡️ Admin Dashboard", self.titles())
        self.assertGreaterEqual(len(at.dataframe), 1)  # activity log table is shown
        self.assertIn("PAGE_VIEW", self.db.log_types())


class LogoutAndHealthTests(StreamlitAppTestCase):
    def test_logout_returns_to_login_and_closes_session(self):
        self.login("sarah.vance@example.com", "Password@123")
        self.button("🚪 Log out", sidebar=True).click()
        at = self.run_app()
        self.assertIn("You have been logged out.", [s.value for s in at.success])
        self.assertEqual([t.label for t in at.tabs], ["🔐 Log in", "✨ Create account"])
        self.assertIsNone(at.session_state["user"])
        # Note: AppTest keeps the previous run's sidebar elements after st.stop(), so we do not
        # assert on the sidebar here. In a real browser the sidebar is removed (checked manually).
        self.assertEqual(self.db.sessions[0]["is_active"], 0)
        self.assertEqual(self.db.log_types()[-1], "LOGOUT")

    def test_database_problem_shows_setup_help_instead_of_crashing(self):
        self.db.check_database_ready = lambda: (False, "Cannot reach MySQL server on localhost:3306.")
        with patched_database(self.db):
            at = self.run_app()
        self.assertTrue(any("Database not ready" in e.value for e in at.error))
        self.assertTrue(any("Checklist" in m.value for m in at.markdown))
        self.assertEqual(len(at.tabs), 0)  # login form is not shown


if __name__ == "__main__":
    unittest.main()
