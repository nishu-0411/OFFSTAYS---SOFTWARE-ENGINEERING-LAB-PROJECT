# Unit tests for the security helpers in auth.py: password hashing and input validation.

import hashlib
import unittest

import auth


class PasswordHashingTests(unittest.TestCase):
    def test_hash_is_pbkdf2_sha256_with_100000_iterations(self):
        # Recompute the hash independently to prove the algorithm and iteration count.
        salt = "00112233445566778899aabbccddeeff"
        expected = hashlib.pbkdf2_hmac("sha256", b"Password@123", bytes.fromhex(salt), 100_000).hex()
        pw_hash, returned_salt = auth.hash_password("Password@123", salt)
        self.assertEqual(pw_hash, expected)
        self.assertEqual(returned_salt, salt)

    def test_new_salt_is_random_32_hex_characters(self):
        _, salt_a = auth.hash_password("Password@123")
        _, salt_b = auth.hash_password("Password@123")
        self.assertEqual(len(salt_a), 32)
        int(salt_a, 16)  # raises ValueError if not hexadecimal
        self.assertNotEqual(salt_a, salt_b)

    def test_same_password_gives_different_hashes_for_different_users(self):
        # This is what defeats rainbow tables: a unique salt per user.
        hash_a, _ = auth.hash_password("Password@123")
        hash_b, _ = auth.hash_password("Password@123")
        self.assertNotEqual(hash_a, hash_b)

    def test_hash_never_contains_the_plain_password(self):
        pw_hash, salt = auth.hash_password("Secure@2026")
        self.assertNotIn("Secure@2026", pw_hash + salt)
        self.assertEqual(len(pw_hash), 64)  # matches CHAR(64) column in users table

    def test_verify_accepts_correct_password(self):
        pw_hash, salt = auth.hash_password("Secure@2026")
        self.assertTrue(auth.verify_password("Secure@2026", pw_hash, salt))

    def test_verify_rejects_wrong_or_differently_cased_password(self):
        pw_hash, salt = auth.hash_password("Secure@2026")
        for wrong in ("secure@2026", "Secure@2025", "", "Secure@2026 "):
            with self.subTest(wrong=wrong):
                self.assertFalse(auth.verify_password(wrong, pw_hash, salt))

    def test_verify_works_with_sample_data_credentials(self):
        # Sarah Vance's row from sql/02_seed_data.sql (password "Password@123").
        import csv, os
        path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "01_users.csv")
        with open(path, newline="", encoding="utf-8") as f:
            sarah = next(r for r in csv.DictReader(f) if r["email"] == "sarah.vance@example.com")
        self.assertTrue(auth.verify_password("Password@123", sarah["password_hash"], sarah["password_salt"]))
        self.assertFalse(auth.verify_password("password@123", sarah["password_hash"], sarah["password_salt"]))


class EmailValidationTests(unittest.TestCase):
    def test_valid_emails(self):
        for email in ("sarah.vance@example.com", "a+b@mail.co.in", "KETAN_T@offstays.com"):
            with self.subTest(email=email):
                self.assertIsNone(auth.validate_email(email))

    def test_invalid_emails(self):
        for email in ("", None, "sarah", "sarah@", "@example.com", "sarah@example", "sa rah@example.com"):
            with self.subTest(email=email):
                self.assertEqual(auth.validate_email(email), "Please enter a valid email address (e.g. name@example.com).")


class PasswordRuleTests(unittest.TestCase):
    def test_strong_password_passes(self):
        self.assertIsNone(auth.validate_password("Secure@2026"))

    def test_each_rule_has_its_own_message(self):
        cases = {
            "Ab@1": "Password must be at least 8 characters long.",
            "12345678@": "Password must contain at least one letter.",
            "Password@": "Password must contain at least one number.",
            "Password1": "Password must contain at least one special character (e.g. @, #, !).",
        }
        for password, message in cases.items():
            with self.subTest(password=password):
                self.assertEqual(auth.validate_password(password), message)

    def test_exactly_eight_characters_is_enough(self):
        self.assertIsNone(auth.validate_password("Abcd@123"))


class PhoneValidationTests(unittest.TestCase):
    def test_phone_is_optional(self):
        self.assertIsNone(auth.validate_phone(""))
        self.assertIsNone(auth.validate_phone(None))

    def test_valid_phone_formats(self):
        for phone in ("+91 98765 43210", "(022) 2345-6789", "9876543210"):
            with self.subTest(phone=phone):
                self.assertIsNone(auth.validate_phone(phone))

    def test_invalid_phone_formats(self):
        for phone in ("98765", "+91 98765 4321O", "call me", "+91-98765-43210-12345-678"):
            with self.subTest(phone=phone):
                self.assertEqual(auth.validate_phone(phone), "Phone number can contain digits, spaces, +, ( ) and - only.")


if __name__ == "__main__":
    unittest.main()
