# Unit tests for activity.py: audit logging for the current user and page navigation.
# `activity.st` is replaced by FakeStreamlit and `activity.database` by a Mock.

import unittest
from unittest import mock

import activity
from tests.support.fakes import FakeStreamlit, RerunCalled


class ActivityTestCase(unittest.TestCase):
    def setUp(self):
        self.st = FakeStreamlit()
        self.db = mock.Mock()
        for p in (mock.patch.object(activity, "st", self.st), mock.patch.object(activity, "database", self.db)):
            p.start()
            self.addCleanup(p.stop)

    def sign_in(self, page="explore"):
        self.st.session_state.update({"user": {"user_id": 2}, "session_id": 55, "current_page": page})


class LogEventTests(ActivityTestCase):
    def test_logs_with_current_user_and_session(self):
        self.sign_in()
        activity.log_event("SAVE_PROPERTY", "Saved Villa", "property", "villa-paradiso", {"source": "explore"})
        self.db.log_activity.assert_called_once_with(2, "SAVE_PROPERTY", "Saved Villa", "property",
                                                     "villa-paradiso", {"source": "explore"}, "SUCCESS", 55)

    def test_failed_status_is_passed_through(self):
        self.sign_in()
        activity.log_event("PAYMENT_FAILED", "Bad card", status="FAILED")
        self.assertEqual(self.db.log_activity.call_args.args[6], "FAILED")

    def test_nothing_is_logged_for_anonymous_visitors(self):
        activity.log_event("PAGE_VIEW", "Opened Explore")
        self.db.log_activity.assert_not_called()

    def test_logging_failure_never_breaks_the_page(self):
        # If MySQL is down while logging, the guest's action must still work.
        self.sign_in()
        self.db.log_activity.side_effect = RuntimeError("MySQL went away")
        with mock.patch("builtins.print") as fake_print:
            activity.log_event("SEARCH", "Searched")  # must not raise
        self.assertIn("could not log SEARCH", fake_print.call_args.args[0])


class NavigationTests(ActivityTestCase):
    def test_go_to_new_page_logs_page_view_and_reruns(self):
        self.sign_in(page="explore")
        with self.assertRaises(RerunCalled):
            activity.go_to("trips")
        self.assertEqual(self.st.session_state["current_page"], "trips")
        args = self.db.log_activity.call_args.args
        self.assertEqual(args[1:5], ("PAGE_VIEW", "Opened My Trips", "page", "trips"))
        self.db.touch_session.assert_called_once_with(55)

    def test_go_to_same_page_does_not_log_again(self):
        self.sign_in(page="trips")
        with self.assertRaises(RerunCalled):
            activity.go_to("trips")
        self.db.log_activity.assert_not_called()
        self.db.touch_session.assert_called_once_with(55)

    def test_unknown_page_key_is_logged_by_its_key(self):
        self.sign_in()
        with self.assertRaises(RerunCalled):
            activity.go_to("secret-page")
        self.assertEqual(self.db.log_activity.call_args.args[2], "Opened secret-page")

    def test_open_property_resets_details_state_and_logs_view(self):
        self.sign_in()
        self.st.session_state.update({"details_photo_index": 4, "show_share_modal": True})
        with self.assertRaises(RerunCalled):
            activity.open_property("cliffside-uluwatu", "saved")
        state = self.st.session_state
        self.assertEqual((state["selected_listing_id"], state["details_photo_index"], state["show_share_modal"],
                          state["current_page"]), ("cliffside-uluwatu", 0, False, "details"))
        args = self.db.log_activity.call_args.args
        self.assertEqual(args[1], "VIEW_PROPERTY")
        self.assertEqual(args[5], {"source": "saved"})

    def test_every_sidebar_page_has_a_readable_name(self):
        for key in ("explore", "details", "checkout", "messages", "trips", "host", "profile", "admin"):
            self.assertIn(key, activity.PAGE_NAMES)


if __name__ == "__main__":
    unittest.main()
