# Unit tests for the booking business rules that live in the page modules:
#   - page_trips.calculate_cancellation_refund   (48-hour refund rule)
#   - page_checkout.validate_payment_details     (demo card / UPI validation + data minimisation)
#   - page_trips.generate_invoice_text            (downloadable invoice)

import datetime
import unittest

import page_checkout
import page_trips

TODAY = datetime.date(2026, 10, 27)  # fixed "today" so expiry tests never depend on the real date


class CancellationRefundTests(unittest.TestCase):
    BOOKING = {"total_price": 899.0, "stay_cost": 740.0, "cleaning_fee": 45.0}

    def test_full_refund_two_or_more_days_before_check_in(self):
        refund, note = page_trips.calculate_cancellation_refund(self.BOOKING, 2)
        self.assertEqual(refund, 899.0)
        self.assertIn("Full refund", note)

    def test_full_refund_far_in_advance(self):
        refund, _ = page_trips.calculate_cancellation_refund(self.BOOKING, 60)
        self.assertEqual(refund, 899.0)

    def test_late_cancellation_refunds_half_stay_plus_cleaning(self):
        # One day before check-in: 50% of 740 + 45 cleaning = 415.
        refund, note = page_trips.calculate_cancellation_refund(self.BOOKING, 1)
        self.assertEqual(refund, 415.0)
        self.assertIn("late cancellation", note)

    def test_boundary_between_rules_is_exactly_two_days(self):
        full, _ = page_trips.calculate_cancellation_refund(self.BOOKING, 2)
        late, _ = page_trips.calculate_cancellation_refund(self.BOOKING, 1)
        self.assertGreater(full, late)

    def test_late_refund_is_rounded_to_cents(self):
        booking = {"total_price": 300.0, "stay_cost": 199.99, "cleaning_fee": 45.0}
        refund, _ = page_trips.calculate_cancellation_refund(booking, 0)
        self.assertEqual(refund, 145.0)  # 99.995 + 45 -> 145.00


class CardValidationTests(unittest.TestCase):
    def check(self, name="Sarah Vance", number="4000 1234 5678 9010", expiry="12/29", cvv="123"):
        return page_checkout.validate_payment_details("Card (demo)", name, number, expiry, cvv, "", TODAY)

    def test_valid_card_keeps_only_last_four_digits(self):
        error, info = self.check()
        self.assertIsNone(error)
        self.assertEqual(info, {"method": "Card (demo)", "card_last4": "9010"})
        # Data minimisation: the full card number and CVV never leave this function.
        self.assertNotIn("4000123456789010", str(info))
        self.assertNotIn("123", str(info).replace("9010", ""))

    def test_blank_cardholder_name_is_rejected(self):
        error, info = self.check(name="   ")
        self.assertEqual(error, "Please enter the cardholder's name.")
        self.assertIsNone(info)

    def test_card_number_must_have_sixteen_digits(self):
        for bad in ("4000 1234 5678 901", "4000 1234 5678 90100", "4000-1234-5678-9010", "abcd efgh ijkl mnop"):
            with self.subTest(number=bad):
                error, _ = self.check(number=bad)
                self.assertEqual(error, "Please enter a valid 16-digit card number (numbers only).")

    def test_expiry_must_be_mm_slash_yy(self):
        for bad in ("1229", "12-29", "1/29", "aa/bb", ""):
            with self.subTest(expiry=bad):
                error, _ = self.check(expiry=bad)
                self.assertEqual(error, "Expiration must be in MM/YY format (e.g., 12/28).")

    def test_expiry_month_must_be_1_to_12(self):
        for bad in ("00/29", "13/29"):
            with self.subTest(expiry=bad):
                error, _ = self.check(expiry=bad)
                self.assertEqual(error, "Card expiration month must be between 01 and 12.")

    def test_expired_card_is_rejected(self):
        error, _ = self.check(expiry="09/26")  # September 2026 is before October 2026
        self.assertEqual(error, "This card has expired. Please use a card with a future expiry date.")

    def test_card_expiring_this_month_is_still_valid(self):
        error, _ = self.check(expiry="10/26")
        self.assertIsNone(error)

    def test_cvv_must_be_three_digits(self):
        for bad in ("12", "1234", "12a", ""):
            with self.subTest(cvv=bad):
                error, _ = self.check(cvv=bad)
                self.assertEqual(error, "CVV must be exactly 3 digits.")

    def test_checks_run_in_order_name_first(self):
        # With several problems, the user sees the first one (same order as the UI form).
        error, _ = self.check(name="", number="1", expiry="x", cvv="")
        self.assertEqual(error, "Please enter the cardholder's name.")


class UpiValidationTests(unittest.TestCase):
    def check(self, upi):
        return page_checkout.validate_payment_details("UPI (demo)", "", "", "", "", upi, TODAY)

    def test_valid_upi_is_masked(self):
        error, info = self.check("sarah@okhdfcbank")
        self.assertIsNone(error)
        self.assertEqual(info, {"method": "UPI (demo)", "upi_masked": "sa****@okhdfcbank"})

    def test_surrounding_spaces_are_ignored(self):
        error, info = self.check("  ketan@okaxis  ")
        self.assertIsNone(error)
        self.assertEqual(info["upi_masked"], "ke****@okaxis")

    def test_invalid_upi_ids_are_rejected(self):
        for bad in ("", "   ", "sarahokhdfc", "@okhdfc", "sarah@", "a@b@c"):
            with self.subTest(upi=bad):
                error, info = self.check(bad)
                self.assertEqual(error, "Please enter a valid UPI ID containing an '@' symbol (e.g. user@bank).")
                self.assertIsNone(info)


class InvoiceTests(unittest.TestCase):
    def test_invoice_contains_guest_booking_and_money_details(self):
        booking = {
            "ref_code": "#OFS-70001", "status": "Confirmed", "created_at": "2026-09-07T10:00:00",
            "listing_title": "Cabin Oasis near Seminyak", "listing_location": "Seminyak, Bali",
            "host_name": "Dewi Lestari", "check_in": "2026-09-12", "check_out": "2026-09-16",
            "nights": 4, "guests": 2, "price_per_night": 135, "stay_cost": 540.0, "cleaning_fee": 45.0,
            "service_fee": 40.0, "taxes": 54.0, "total_price": 679.0, "payment_method": "Card (demo)",
            "transaction_ref": "TXN123456789012",
        }
        user = {"full_name": "Sarah Vance", "user_id": 2, "email": "sarah.vance@example.com"}
        text = page_trips.generate_invoice_text(booking, user)
        self.assertIn("Booking Reference : #OFS-70001", text)
        self.assertIn("Sarah Vance (#USR-0002)", text)
        self.assertIn("Date Issued       : 2026-09-07", text)
        self.assertIn("TOTAL AMOUNT PAID : $679.00 (USD)", text)
        self.assertIn("Nightly Rate      : $135.00", text)
        self.assertIn("Transaction Ref   : TXN123456789012", text)


if __name__ == "__main__":
    unittest.main()
