# Unit tests: one function at a time, no MySQL server needed.
