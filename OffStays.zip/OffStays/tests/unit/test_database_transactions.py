# Unit tests for the multi-step transactions in database.py, with MySQL MOCKED by FakeCursor.
# These check the decision logic: when we commit, when we roll back, and what gets written.

import unittest
from unittest import mock

import pymysql

import database
from tests.support.fakes import FakeConnection, FakeCursor

BOOKING = {
    "listing_id": "villa-paradiso", "listing_title": "Villa Paradiso",
    "check_in": "2031-01-01", "check_out": "2031-01-05", "nights": 4, "guests": 2,
    "stay_cost": 740.0, "cleaning_fee": 45.0, "service_fee": 40.0, "taxes": 74.0, "total_price": 899.0,
    "host_note": "",
}
CARD = {"method": "Card (demo)", "card_last4": "9010"}


def run_with(cursor, func, *args):
    conn = FakeConnection(cursor)
    with mock.patch.object(database, "get_connection", return_value=conn):
        result = func(*args)
    return result, conn


class CreateBookingTransactionTests(unittest.TestCase):
    def test_successful_booking_writes_all_records_then_commits_once(self):
        # fetchone answers in order: overlap count 0, ref-code is free, transaction ref is free.
        # (The FOR UPDATE lock statement is executed but its row is never read.)
        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None])
        (ok, message, ref_code), conn = run_with(cursor, database.create_booking_transaction, 2, 55, BOOKING, CARD)

        self.assertTrue(ok)
        self.assertEqual(message, "Booking confirmed successfully!")
        self.assertRegex(ref_code, r"^#OFS-\d{5}$")
        self.assertEqual((conn.commits, conn.rollbacks), (1, 0))
        # Row lock first, so two guests cannot book the same dates at the same moment.
        self.assertIn("FOR UPDATE", cursor.statements()[0])
        self.assertEqual(len(cursor.find("INSERT INTO bookings")), 1)
        self.assertEqual(len(cursor.find("INSERT INTO payments")), 1)
        self.assertEqual(len(cursor.find("INSERT INTO messages")), 1)
        self.assertEqual(len(cursor.find("INSERT INTO notifications")), 1)
        log_types = [params[2] for _, params in cursor.find("INSERT INTO activity_logs")]
        self.assertEqual(log_types, ["PAYMENT_SUCCESS", "BOOKING_CREATED"])

    def test_booking_row_uses_the_priced_amounts_and_a_keyless_pin(self):
        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None])
        run_with(cursor, database.create_booking_transaction, 2, 55, BOOKING, CARD)
        params = cursor.find("INSERT INTO bookings")[0][1]
        self.assertEqual(params[1:13], (2, "villa-paradiso", "2031-01-01", "2031-01-05", 4, 2,
                                        740.0, 45.0, 40.0, 74.0, 899.0, None))
        self.assertRegex(params[13], r"^\d{4}#$")  # keyless PIN

    def test_payment_row_stores_only_masked_card_data(self):
        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None])
        run_with(cursor, database.create_booking_transaction, 2, 55, BOOKING, CARD)
        params = cursor.find("INSERT INTO payments")[0][1]
        self.assertEqual(params[2], "Card (demo)")
        self.assertEqual(params[3], 899.0)
        self.assertEqual(params[5:7], ("9010", None))

    def test_overlapping_dates_roll_back_and_log_failure(self):
        cursor = FakeCursor(fetchone_results=[{"n": 1}])
        with mock.patch.object(database, "log_activity") as log:
            (ok, message, ref_code), conn = run_with(cursor, database.create_booking_transaction, 2, 55, BOOKING, CARD)
        self.assertFalse(ok)
        self.assertEqual(message, "This property was just booked for the selected dates. Please choose other dates.")
        self.assertIsNone(ref_code)
        self.assertEqual((conn.commits, conn.rollbacks), (0, 1))
        self.assertEqual(cursor.find("INSERT INTO bookings"), [])
        self.assertEqual(log.call_args.args[1], "BOOKING_FAILED")
        self.assertEqual(log.call_args.kwargs["status"], "FAILED")

    def test_database_error_mid_transaction_rolls_everything_back(self):
        # The payment insert fails AFTER the booking insert: nothing may be committed.
        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None],
                            fail_on={"INSERT INTO payments": pymysql.err.OperationalError(1205, "Lock wait timeout")})
        with mock.patch.object(database, "log_activity") as log:
            (ok, message, ref_code), conn = run_with(cursor, database.create_booking_transaction, 2, 55, BOOKING, CARD)
        self.assertFalse(ok)
        self.assertTrue(message.startswith("Database transaction failed:"))
        self.assertEqual((conn.commits, conn.rollbacks, conn.closed), (0, 1, True))
        self.assertEqual(log.call_args.args[1], "BOOKING_FAILED")

    def test_failure_logging_problem_does_not_hide_the_original_error(self):
        cursor = FakeCursor(fetchone_results=[{"n": 0}, None, None],
                            fail_on={"INSERT INTO bookings": pymysql.err.OperationalError(2013, "Lost connection")})
        with mock.patch.object(database, "log_activity", side_effect=RuntimeError("log down")):
            (ok, message, _), conn = run_with(cursor, database.create_booking_transaction, 2, 55, BOOKING, CARD)
        self.assertFalse(ok)
        self.assertIn("Lost connection", message)


class UniqueCodeTests(unittest.TestCase):
    def test_retries_until_code_is_unused(self):
        # First two random codes "exist", third is free.
        cursor = FakeCursor(fetchone_results=[(1,), (1,), None])
        with mock.patch.object(database.random, "randint", side_effect=[11111, 22222, 33333]):
            code = database._unique_code(cursor, "#OFS-", 5, "bookings", "ref_code")
        self.assertEqual(code, "#OFS-33333")
        self.assertEqual(len(cursor.executed), 3)


class CancelBookingTests(unittest.TestCase):
    INFO = {"ref_code": "#OFS-12345", "status": "Confirmed", "total_price": 899.0,
            "property_id": "villa-paradiso", "title": "Villa Paradiso"}

    def test_full_refund_marks_payment_refunded(self):
        cursor = FakeCursor(fetchone_results=[dict(self.INFO)])
        ok, conn = run_with(cursor, database.cancel_booking, 2, 55, 10, 899.0, "Full refund.")
        self.assertTrue(ok)
        self.assertEqual(conn.commits, 1)
        self.assertEqual(cursor.find("UPDATE payments")[0][1][0], "Refunded")
        self.assertIn("status = 'Cancelled'", cursor.find("UPDATE bookings")[0][0])
        log_params = cursor.find("INSERT INTO activity_logs")[0][1]
        self.assertEqual(log_params[2], "BOOKING_CANCELLED")

    def test_partial_refund_marks_payment_partially_refunded(self):
        cursor = FakeCursor(fetchone_results=[dict(self.INFO)])
        run_with(cursor, database.cancel_booking, 2, 55, 10, 415.0, "Late.")
        self.assertEqual(cursor.find("UPDATE payments")[0][1][:2], ("Partially Refunded", 415.0))

    def test_lookup_is_restricted_to_the_owner(self):
        cursor = FakeCursor(fetchone_results=[dict(self.INFO)])
        run_with(cursor, database.cancel_booking, 2, 55, 10, 899.0, "x")
        sql, params = cursor.executed[0]
        self.assertIn("b.booking_id = %s AND b.user_id = %s FOR UPDATE", sql)
        self.assertEqual(params, (10, 2))

    def test_unknown_or_foreign_booking_is_not_cancelled(self):
        cursor = FakeCursor(fetchone_results=[None])
        ok, conn = run_with(cursor, database.cancel_booking, 3, 55, 10, 899.0, "x")
        self.assertFalse(ok)
        self.assertEqual((conn.commits, conn.rollbacks), (0, 1))
        self.assertEqual(cursor.find("UPDATE bookings"), [])
        self.assertEqual(cursor.find("UPDATE payments"), [])

    def test_already_cancelled_or_completed_booking_is_not_changed(self):
        for status in ("Cancelled", "Completed"):
            with self.subTest(status=status):
                cursor = FakeCursor(fetchone_results=[dict(self.INFO, status=status)])
                ok, conn = run_with(cursor, database.cancel_booking, 2, 55, 10, 899.0, "x")
                self.assertFalse(ok)
                self.assertEqual(conn.commits, 0)


class AddReviewTests(unittest.TestCase):
    def test_running_average_keeps_historic_review_count(self):
        # 142 reviews averaging 4.98, plus a new 4.0 -> (4.98*142 + 4.0) / 143 = 4.97
        cursor = FakeCursor(fetchone_results=[{"user_id": 2, "status": "Completed"},
                                              {"rating": 4.98, "review_count": 142}])
        (ok, message), conn = run_with(cursor, database.add_review, 2, 55, "villa-paradiso", 10,
                                       "Sarah Vance", "London", 4.0, "Lovely")
        self.assertTrue(ok)
        self.assertEqual(message, "Thank you! Your review has been published.")
        self.assertEqual(cursor.find("UPDATE properties")[0][1], (4.97, 143, "villa-paradiso"))
        self.assertEqual(conn.commits, 1)

    def test_first_review_sets_the_rating(self):
        cursor = FakeCursor(fetchone_results=[{"user_id": 2, "status": "Completed"},
                                              {"rating": 0, "review_count": 0}])
        run_with(cursor, database.add_review, 2, 55, "new-villa", 10, "A", "B", 4.5, "Nice")
        self.assertEqual(cursor.find("UPDATE properties")[0][1], (4.5, 1, "new-villa"))

    def test_only_the_owner_of_a_completed_stay_can_review(self):
        cases = [None, {"user_id": 3, "status": "Completed"}, {"user_id": 2, "status": "Confirmed"},
                 {"user_id": 2, "status": "Cancelled"}]
        for booking in cases:
            with self.subTest(booking=booking):
                cursor = FakeCursor(fetchone_results=[booking])
                (ok, message), conn = run_with(cursor, database.add_review, 2, 55, "villa-paradiso", 10,
                                               "A", "B", 5.0, "x")
                self.assertFalse(ok)
                self.assertEqual(message, "You can only review your own completed stays.")
                self.assertEqual(cursor.find("INSERT INTO reviews"), [])
                self.assertEqual(conn.commits, 0)

    def test_duplicate_review_is_reported_and_rolled_back(self):
        cursor = FakeCursor(fetchone_results=[{"user_id": 2, "status": "Completed"}],
                            fail_on={"INSERT INTO reviews": pymysql.err.IntegrityError(1062, "Duplicate entry")})
        (ok, message), conn = run_with(cursor, database.add_review, 2, 55, "villa-paradiso", 10, "A", "B", 5.0, "x")
        self.assertFalse(ok)
        self.assertEqual(message, "A review for this booking already exists.")
        self.assertEqual(conn.rollbacks, 1)


class AccountTransactionTests(unittest.TestCase):
    def test_create_user_inserts_user_welcome_notification_and_log_together(self):
        cursor = FakeCursor(first_lastrowid=77)
        user_id, conn = run_with(cursor, database.create_user, "Ketan Trivedi", "ketan@example.com",
                                 "", "h" * 64, "s" * 32, "", "India")
        self.assertEqual(user_id, 77)
        self.assertEqual(conn.commits, 1)
        params = cursor.find("INSERT INTO users")[0][1]
        self.assertEqual(params[2], None)   # empty phone stored as NULL
        self.assertEqual(params[5], None)   # empty city stored as NULL
        self.assertIn("Ketan+Trivedi", params[7])  # generated avatar URL
        self.assertIn("Hi Ketan", cursor.find("INSERT INTO notifications")[0][1][1])
        self.assertEqual(cursor.find("INSERT INTO activity_logs")[0][1][2], "REGISTER")

    def test_create_user_rolls_back_if_any_insert_fails(self):
        cursor = FakeCursor(fail_on={"INSERT INTO notifications": pymysql.err.OperationalError(1205, "timeout")})
        conn = FakeConnection(cursor)
        with mock.patch.object(database, "get_connection", return_value=conn):
            with self.assertRaises(pymysql.err.OperationalError):
                database.create_user("A B", "a@b.com", "", "h" * 64, "s" * 32, "", "")
        self.assertEqual((conn.commits, conn.rollbacks), (0, 1))

    def test_start_session_records_login_and_hides_full_token_in_log(self):
        cursor = FakeCursor(first_lastrowid=300)
        session_id, conn = run_with(cursor, database.start_session, 7, "abcdef0123456789" * 2, "Mozilla/5.0")
        self.assertEqual(session_id, 300)
        self.assertEqual(len(cursor.find("UPDATE users SET last_login_at")), 1)
        log_params = cursor.find("INSERT INTO activity_logs")[0][1]
        self.assertEqual(log_params[1], 300)          # session id linked to the LOGIN log
        self.assertNotIn("abcdef0123456789abcdef0123456789", log_params[6])
        self.assertIn("abcdef01...", log_params[6])

    def test_end_session_closes_only_this_users_session(self):
        cursor = FakeCursor()
        run_with(cursor, database.end_session, 7, 300)
        sql, params = cursor.find("UPDATE user_sessions")[0]
        self.assertIn("WHERE session_id = %s AND user_id = %s", sql)
        self.assertEqual(params[2:], (300, 7))
        self.assertEqual(cursor.find("INSERT INTO activity_logs")[0][1][2], "LOGOUT")


if __name__ == "__main__":
    unittest.main()
