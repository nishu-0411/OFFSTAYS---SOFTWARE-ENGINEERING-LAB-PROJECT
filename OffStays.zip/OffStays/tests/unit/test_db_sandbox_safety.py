# Unit tests for the safety rules of the test-database sandbox (tests/support/db_sandbox.py).
# These run WITHOUT MySQL and prove the tests can never be pointed at the app database.

import os
import unittest
from unittest import mock

from tests.support import db_sandbox


class SafeNameTests(unittest.TestCase):
    def test_dedicated_test_names_are_accepted(self):
        for name in ("offstays_test", "ketan_offstays_test"):
            db_sandbox.assert_safe_test_db_name(name)  # no exception

    def test_app_system_and_badly_named_databases_are_refused(self):
        for name in ("offstays", "OFFSTAYS", "mysql", "sys", "offstays_prod", "offstays_testing",
                     "test", "", None, "offstays_test; DROP DATABASE offstays", "a`b_test"):
            with self.subTest(name=name):
                with self.assertRaises(db_sandbox.UnsafeDatabaseError):
                    db_sandbox.assert_safe_test_db_name(name)


class SqlRewriteTests(unittest.TestCase):
    def read(self, filename):
        with open(os.path.join(db_sandbox.SQL_DIR, filename), encoding="utf-8") as f:
            return f.read()

    def test_schema_script_is_redirected_to_the_test_database(self):
        sql = db_sandbox.rewrite_sql_for_test_db(self.read("01_schema.sql"), "offstays_test")
        self.assertNotIn("DROP DATABASE IF EXISTS offstays;", sql)  # the tests drop only marked DBs themselves
        self.assertIn("CREATE DATABASE `offstays_test` CHARACTER SET utf8mb4", sql)
        self.assertIn("USE `offstays_test`;", sql)
        self.assertNotRegex(sql, r"(?im)^\s*USE\s+offstays\s*;")

    def test_seed_and_view_scripts_are_redirected(self):
        for filename in ("02_seed_data.sql", "04_views_and_reports.sql"):
            with self.subTest(filename=filename):
                sql = db_sandbox.rewrite_sql_for_test_db(self.read(filename), "offstays_test")
                self.assertIn("USE `offstays_test`;", sql)
                self.assertNotRegex(sql, r"(?im)^\s*USE\s+offstays\s*;")

    def test_sample_data_values_are_not_changed(self):
        # The admin email contains "offstays." but is data, not a database name.
        sql = db_sandbox.rewrite_sql_for_test_db(self.read("02_seed_data.sql"), "offstays_test")
        self.assertIn("admin@offstays.com", sql)

    def test_rewriting_refuses_an_unsafe_target(self):
        with self.assertRaises(db_sandbox.UnsafeDatabaseError):
            db_sandbox.rewrite_sql_for_test_db("USE offstays;", "offstays")


class SettingsTests(unittest.TestCase):
    def test_tests_are_skipped_unless_explicitly_enabled(self):
        env = {k: v for k, v in os.environ.items() if not k.startswith("OFFSTAYS_TEST_DB_")}
        with mock.patch.dict(os.environ, env, clear=True), \
             mock.patch.object(db_sandbox, "INI_PATH", "/nonexistent/test_database.ini"):
            self.assertFalse(db_sandbox.load_settings()["enabled"])
            self.assertIn("switched off", db_sandbox.skip_reason())

    def test_environment_variables_override_defaults(self):
        env = {"OFFSTAYS_TEST_DB_ENABLED": "1", "OFFSTAYS_TEST_DB_NAME": "mine_test", "OFFSTAYS_TEST_DB_PORT": "3307"}
        with mock.patch.dict(os.environ, env), \
             mock.patch.object(db_sandbox, "INI_PATH", "/nonexistent/test_database.ini"):
            settings = db_sandbox.load_settings()
        self.assertEqual((settings["enabled"], settings["name"], settings["port"]), (True, "mine_test", 3307))

    def test_unsafe_name_is_reported_as_skip_reason_before_connecting(self):
        env = {"OFFSTAYS_TEST_DB_ENABLED": "1", "OFFSTAYS_TEST_DB_NAME": "offstays"}
        with mock.patch.dict(os.environ, env), \
             mock.patch.object(db_sandbox, "_server_connection") as connect:
            reason = db_sandbox.skip_reason()
        self.assertIn("Refusing to use database 'offstays'", reason)
        connect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
