# Unit tests for pricing.py: night counting and the itemised price breakdown.
# These rules decide what every guest pays, so we check exact amounts, not just "it runs".

import datetime
import unittest

import pricing

D = datetime.date


class CalculateNightsTests(unittest.TestCase):
    def test_counts_nights_between_dates(self):
        self.assertEqual(pricing.calculate_nights(D(2026, 12, 18), D(2026, 12, 22)), 4)

    def test_counts_across_month_and_year_boundaries(self):
        self.assertEqual(pricing.calculate_nights(D(2026, 12, 30), D(2027, 1, 2)), 3)

    def test_leap_day_is_counted(self):
        # 2028 is a leap year, so February has 29 days.
        self.assertEqual(pricing.calculate_nights(D(2028, 2, 27), D(2028, 3, 1)), 3)

    def test_same_day_is_zero_nights(self):
        self.assertEqual(pricing.calculate_nights(D(2026, 5, 1), D(2026, 5, 1)), 0)

    def test_reversed_dates_give_negative_value(self):
        # calculate_nights itself does not clamp; calculate_price_breakdown does (tested below).
        self.assertEqual(pricing.calculate_nights(D(2026, 5, 5), D(2026, 5, 1)), -4)


class PriceBreakdownTests(unittest.TestCase):
    def test_villa_paradiso_four_nights_matches_seeded_booking(self):
        # Same numbers as the sample booking #OFS-70001 rule: $185 x 4 nights at Villa Paradiso.
        result = pricing.calculate_price_breakdown(185, D(2026, 12, 18), D(2026, 12, 22))
        self.assertEqual(result, {
            "nights": 4,
            "price_per_night": 185,
            "stay_cost": 740.0,
            "cleaning_fee": 45.0,
            "service_fee": 40.0,
            "taxes": 74.0,
            "total_price": 899.0,
        })

    def test_cleaning_and_service_fees_are_flat_per_stay(self):
        one = pricing.calculate_price_breakdown(100, D(2026, 1, 1), D(2026, 1, 2))
        seven = pricing.calculate_price_breakdown(100, D(2026, 1, 1), D(2026, 1, 8))
        self.assertEqual(one["cleaning_fee"], seven["cleaning_fee"])
        self.assertEqual(one["service_fee"], seven["service_fee"])
        self.assertEqual(seven["stay_cost"], 700.0)

    def test_tax_is_ten_percent_of_stay_cost_only(self):
        # Taxes apply to the nightly charges, not to the cleaning or service fee.
        result = pricing.calculate_price_breakdown(340, D(2026, 3, 1), D(2026, 3, 5))
        self.assertEqual(result["stay_cost"], 1360.0)
        self.assertEqual(result["taxes"], 136.0)
        self.assertEqual(result["total_price"], 1360.0 + 45.0 + 40.0 + 136.0)

    def test_total_is_sum_of_the_parts(self):
        result = pricing.calculate_price_breakdown(1110, D(2026, 11, 10), D(2026, 11, 17))
        parts = result["stay_cost"] + result["cleaning_fee"] + result["service_fee"] + result["taxes"]
        self.assertAlmostEqual(result["total_price"], parts, places=2)

    def test_fractional_nightly_rate_is_rounded_to_cents(self):
        result = pricing.calculate_price_breakdown(99.99, D(2026, 6, 1), D(2026, 6, 4))
        self.assertEqual(result["stay_cost"], 299.97)
        self.assertEqual(result["taxes"], 30.0)  # 29.997 rounds to 30.00
        self.assertEqual(result["total_price"], 414.97)

    def test_same_day_dates_are_charged_as_one_night(self):
        # Defensive rule in pricing.py: never charge zero or negative nights.
        result = pricing.calculate_price_breakdown(200, D(2026, 6, 1), D(2026, 6, 1))
        self.assertEqual(result["nights"], 1)
        self.assertEqual(result["stay_cost"], 200.0)

    def test_reversed_dates_are_charged_as_one_night(self):
        result = pricing.calculate_price_breakdown(200, D(2026, 6, 5), D(2026, 6, 1))
        self.assertEqual(result["nights"], 1)
        self.assertGreater(result["total_price"], 0)

    def test_values_are_plain_floats_ready_for_mysql(self):
        result = pricing.calculate_price_breakdown(185, D(2026, 1, 1), D(2026, 1, 3))
        for key in ("stay_cost", "cleaning_fee", "service_fee", "taxes", "total_price"):
            self.assertIsInstance(result[key], float, key)


if __name__ == "__main__":
    unittest.main()
