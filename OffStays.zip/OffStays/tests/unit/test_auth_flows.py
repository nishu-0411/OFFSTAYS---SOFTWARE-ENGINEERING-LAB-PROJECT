# Unit tests for the account workflows in auth.py with the database MOCKED.
# We replace `auth.database` with a Mock and `auth.st` with a FakeStreamlit, so each test
# controls exactly what "MySQL" answers and can check what auth.py asked it to do.

import unittest
from unittest import mock

import auth
from tests.support.fakes import FakeStreamlit

PASSWORD = "Secure@2026"
HASH, SALT = auth.hash_password(PASSWORD, "aa" * 16)


def stored_user(**changes):
    user = {"user_id": 7, "full_name": "Ketan Trivedi", "email": "ketan@example.com", "phone": None,
            "role": "guest", "city": "Ahmedabad", "country": "India", "avatar_url": None,
            "created_at": "2026-10-27T10:00:00", "is_active": 1,
            "password_hash": HASH, "password_salt": SALT}
    user.update(changes)
    return user


class AuthTestCase(unittest.TestCase):
    def setUp(self):
        self.st = FakeStreamlit()
        self.db = mock.Mock()
        self.db.count_recent_failed_logins.return_value = 0
        self.db.start_session.return_value = 55
        patchers = [mock.patch.object(auth, "st", self.st), mock.patch.object(auth, "database", self.db)]
        for p in patchers:
            p.start()
            self.addCleanup(p.stop)

    def logged_types(self):
        # activity_type argument of every database.log_activity(...) call, in order.
        return [c.args[1] for c in self.db.log_activity.call_args_list]


class RegisterTests(AuthTestCase):
    def register(self, **overrides):
        args = dict(full_name="  Ketan Trivedi ", email=" Ketan@Example.com ", phone=" +91 98765 43210 ",
                    password=PASSWORD, confirm_password=PASSWORD, city="Ahmedabad", country="India")
        args.update(overrides)
        return auth.register_user(**args)

    def test_successful_registration_creates_user_and_signs_in(self):
        self.db.get_user_by_email.return_value = None
        self.db.create_user.return_value = 7
        self.db.get_user_by_id.return_value = stored_user()
        ok, message = self.register()
        self.assertTrue(ok)
        self.assertEqual(message, "Welcome to OFFSTAYS, Ketan! Your account has been created.")
        # Input is cleaned: trimmed name, lower-case email, trimmed phone.
        name, email, phone, pw_hash, pw_salt, city, country = self.db.create_user.call_args.args
        self.assertEqual((name, email, phone), ("Ketan Trivedi", "ketan@example.com", "+91 98765 43210"))
        # The stored hash must verify the original password, and must not be the password itself.
        self.assertNotEqual(pw_hash, PASSWORD)
        self.assertTrue(auth.verify_password(PASSWORD, pw_hash, pw_salt))
        # A session is opened and the safe user dict is in session state.
        self.db.start_session.assert_called_once()
        self.assertEqual(self.st.session_state["session_id"], 55)
        self.assertEqual(self.st.session_state["user"]["email"], "ketan@example.com")
        self.assertEqual(self.st.session_state["current_page"], "explore")

    def test_session_state_never_contains_password_data(self):
        self.db.get_user_by_email.return_value = None
        self.db.create_user.return_value = 7
        self.db.get_user_by_id.return_value = stored_user()
        self.register()
        user = self.st.session_state["user"]
        self.assertNotIn("password_hash", user)
        self.assertNotIn("password_salt", user)

    def test_duplicate_email_is_rejected_and_logged(self):
        self.db.get_user_by_email.return_value = stored_user()
        ok, message = self.register()
        self.assertFalse(ok)
        self.assertEqual(message, "An account with this email already exists. Please log in instead.")
        self.db.create_user.assert_not_called()
        self.assertEqual(self.logged_types(), ["REGISTER_FAILED"])
        self.assertNotIn("user", self.st.session_state)

    def test_invalid_input_is_rejected_before_touching_users_table(self):
        cases = [
            (dict(full_name="K"), "Please enter your full name."),
            (dict(email="not-an-email"), "Please enter a valid email address (e.g. name@example.com)."),
            (dict(phone="abc"), "Phone number can contain digits, spaces, +, ( ) and - only."),
            (dict(password="short", confirm_password="short"), "Password must be at least 8 characters long."),
            (dict(confirm_password="Different@2026"), "Passwords do not match."),
        ]
        for overrides, expected in cases:
            with self.subTest(expected=expected):
                self.db.reset_mock()
                ok, message = self.register(**overrides)
                self.assertFalse(ok)
                self.assertEqual(message, expected)
                self.db.get_user_by_email.assert_not_called()
                self.db.create_user.assert_not_called()
                # The rejected attempt is still audited, with the reason but without the password.
                call = self.db.log_activity.call_args
                self.assertEqual(call.args[1], "REGISTER_FAILED")
                self.assertEqual(call.kwargs["status"], "FAILED")
                self.assertNotIn(PASSWORD, str(call))


class LoginTests(AuthTestCase):
    def test_successful_login_starts_session(self):
        self.db.get_user_by_email.return_value = stored_user()
        ok, message = auth.login_user("  KETAN@example.com ", PASSWORD)
        self.assertTrue(ok)
        self.assertEqual(message, "Welcome back, Ketan!")
        self.db.get_user_by_email.assert_called_with("ketan@example.com")
        self.db.start_session.assert_called_once()
        token = self.db.start_session.call_args.args[1]
        self.assertEqual(len(token), 32)  # 16 random bytes as hex
        self.assertTrue(auth.is_logged_in())
        self.assertEqual(auth.current_user()["user_id"], 7)

    def test_blank_fields_are_rejected_without_database_calls(self):
        for email, password in (("", PASSWORD), ("ketan@example.com", ""), (None, None)):
            with self.subTest(email=email, password=password):
                ok, message = auth.login_user(email, password)
                self.assertFalse(ok)
                self.assertEqual(message, "Please enter both email and password.")
        self.db.count_recent_failed_logins.assert_not_called()

    def test_unknown_email_and_wrong_password_give_the_same_message(self):
        # Same message for both, so attackers cannot find out which emails are registered.
        self.db.get_user_by_email.return_value = None
        _, unknown_message = auth.login_user("ghost@example.com", PASSWORD)
        self.db.get_user_by_email.return_value = stored_user()
        _, wrong_message = auth.login_user("ketan@example.com", "Wrong@2026")
        self.assertEqual(unknown_message, "Incorrect email or password.")
        self.assertEqual(unknown_message, wrong_message)
        self.assertEqual(self.logged_types(), ["LOGIN_FAILED", "LOGIN_FAILED"])
        self.db.start_session.assert_not_called()

    def test_failed_login_log_records_email_and_reason_for_lockout_counting(self):
        self.db.get_user_by_email.return_value = stored_user()
        auth.login_user("ketan@example.com", "Wrong@2026")
        details = self.db.log_activity.call_args.args[5]
        self.assertEqual(details, {"email": "ketan@example.com", "reason": "wrong_password"})

    def test_lockout_after_five_recent_failures(self):
        self.db.count_recent_failed_logins.return_value = 5
        self.db.get_user_by_email.return_value = stored_user()
        ok, message = auth.login_user("ketan@example.com", PASSWORD)  # even the right password
        self.assertFalse(ok)
        self.assertEqual(message, "Too many failed attempts. Please wait 15 minutes and try again.")
        self.db.count_recent_failed_logins.assert_called_with("ketan@example.com", 15)
        self.assertEqual(self.logged_types(), ["LOGIN_BLOCKED"])
        self.db.start_session.assert_not_called()

    def test_four_failures_still_allow_login(self):
        self.db.count_recent_failed_logins.return_value = 4
        self.db.get_user_by_email.return_value = stored_user()
        ok, _ = auth.login_user("ketan@example.com", PASSWORD)
        self.assertTrue(ok)

    def test_deactivated_account_cannot_log_in(self):
        self.db.get_user_by_email.return_value = stored_user(is_active=0)
        ok, message = auth.login_user("ketan@example.com", PASSWORD)
        self.assertFalse(ok)
        self.assertEqual(message, "This account has been deactivated. Please contact support.")
        self.assertEqual(self.db.log_activity.call_args.args[5]["reason"], "inactive")
        self.db.start_session.assert_not_called()


class LogoutAndPasswordTests(AuthTestCase):
    def sign_in(self):
        self.st.session_state.update({"user": {"user_id": 7, "full_name": "Ketan Trivedi"},
                                      "session_id": 55, "current_page": "trips", "pending_booking": {"x": 1}})

    def test_logout_closes_session_and_clears_all_state(self):
        self.sign_in()
        auth.logout_user()
        self.db.end_session.assert_called_once_with(7, 55)
        self.assertEqual(self.st.session_state, {})
        self.assertFalse(auth.is_logged_in())

    def test_logout_when_not_signed_in_does_not_touch_database(self):
        auth.logout_user()
        self.db.end_session.assert_not_called()

    def test_change_password_with_correct_current_password(self):
        self.sign_in()
        self.db.get_user_by_id.return_value = stored_user()
        ok, message = auth.change_password(PASSWORD, "Newpass#2027", "Newpass#2027")
        self.assertTrue(ok)
        self.assertEqual(message, "Password updated successfully.")
        user_id, new_hash, new_salt = self.db.update_password.call_args.args
        self.assertEqual(user_id, 7)
        self.assertTrue(auth.verify_password("Newpass#2027", new_hash, new_salt))
        self.assertNotEqual(new_salt, SALT)  # a fresh salt every time
        self.assertEqual(self.logged_types(), ["PASSWORD_CHANGED"])

    def test_change_password_with_wrong_current_password(self):
        self.sign_in()
        self.db.get_user_by_id.return_value = stored_user()
        ok, message = auth.change_password("Wrong@2026", "Newpass#2027", "Newpass#2027")
        self.assertFalse(ok)
        self.assertEqual(message, "Your current password is incorrect.")
        self.db.update_password.assert_not_called()
        self.assertEqual(self.logged_types(), ["PASSWORD_CHANGE_FAILED"])

    def test_change_password_enforces_rules_and_confirmation(self):
        self.sign_in()
        self.db.get_user_by_id.return_value = stored_user()
        self.assertEqual(auth.change_password(PASSWORD, "weak", "weak"),
                         (False, "Password must be at least 8 characters long."))
        self.assertEqual(auth.change_password(PASSWORD, "Newpass#2027", "Newpass#2028"),
                         (False, "New passwords do not match."))
        self.db.update_password.assert_not_called()

    def test_refresh_user_reloads_profile_but_keeps_session(self):
        self.sign_in()
        self.db.get_user_by_id.return_value = stored_user(city="Vadodara")
        auth.refresh_user()
        self.assertEqual(self.st.session_state["user"]["city"], "Vadodara")
        self.assertEqual(self.st.session_state["session_id"], 55)


if __name__ == "__main__":
    unittest.main()
