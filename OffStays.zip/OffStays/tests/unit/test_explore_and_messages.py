# Unit tests for page logic that does not need the UI:
#   - page_explore.filter_stays and its sort helpers
#   - page_messages.get_automated_host_reply and get_sample_wifi_credentials
#   - page_profile.session_status (login-history labels)

import unittest
from unittest import mock

import page_explore
import page_messages
import page_profile
from tests.support.fakes import FakeStreamlit

ALL_D, ALL_A = page_explore.ALL_DESTINATIONS, page_explore.ALL_AREAS


def stay(stay_id, **changes):
    data = {"id": stay_id, "destination": "Bali", "area": "Ubud", "category": "Amazing pools",
            "price_per_night": 200, "max_guests": 4, "has_pool": 1, "has_wifi": 1,
            "host_superhost": 1, "rating": 4.9}
    data.update(changes)
    return data


STAYS = [
    stay("ubud-pool"),
    stay("seminyak-cabin", area="Seminyak", category="Eco Cabins", price_per_night=90, has_pool=0, rating=4.7),
    stay("goa-villa", destination="Goa", area="Anjuna", price_per_night=150, host_superhost=0, max_guests=2),
    stay("zermatt-chalet", destination="Swiss Alps", area="Zermatt", category="Mountain Chalets",
         price_per_night=425, has_pool=0, has_wifi=0, max_guests=8, rating=4.95),
]


def ids(results):
    return [s["id"] for s in results]


class FilterStaysTests(unittest.TestCase):
    def run_filter(self, destination=ALL_D, area=ALL_A, category="All Categories", min_p=0, max_p=2000,
                   pool=False, wifi=False, superhost=False, guests=1, unavailable=frozenset()):
        return page_explore.filter_stays(STAYS, destination, area, category, min_p, max_p,
                                         pool, wifi, superhost, guests, unavailable)

    def test_no_filters_returns_everything_in_original_order(self):
        self.assertEqual(ids(self.run_filter()), ["ubud-pool", "seminyak-cabin", "goa-villa", "zermatt-chalet"])

    def test_destination_and_area(self):
        self.assertEqual(ids(self.run_filter(destination="Bali")), ["ubud-pool", "seminyak-cabin"])
        self.assertEqual(ids(self.run_filter(destination="Bali", area="Seminyak")), ["seminyak-cabin"])

    def test_category(self):
        self.assertEqual(ids(self.run_filter(category="Mountain Chalets")), ["zermatt-chalet"])

    def test_price_range_is_inclusive(self):
        self.assertEqual(ids(self.run_filter(min_p=150, max_p=200)), ["ubud-pool", "goa-villa"])

    def test_guest_capacity(self):
        self.assertEqual(ids(self.run_filter(guests=5)), ["zermatt-chalet"])
        self.assertIn("goa-villa", ids(self.run_filter(guests=2)))

    def test_amenity_and_superhost_checkboxes(self):
        self.assertEqual(ids(self.run_filter(pool=True)), ["ubud-pool", "goa-villa"])
        self.assertEqual(ids(self.run_filter(wifi=True)), ["ubud-pool", "seminyak-cabin", "goa-villa"])
        self.assertNotIn("goa-villa", ids(self.run_filter(superhost=True)))

    def test_booked_properties_are_hidden(self):
        self.assertEqual(ids(self.run_filter(unavailable={"ubud-pool", "zermatt-chalet"})),
                         ["seminyak-cabin", "goa-villa"])

    def test_filters_combine(self):
        result = self.run_filter(destination="Bali", pool=True, guests=4, max_p=250)
        self.assertEqual(ids(result), ["ubud-pool"])

    def test_no_match_returns_empty_list(self):
        self.assertEqual(self.run_filter(destination="Kyoto"), [])

    def test_sort_helpers(self):
        by_price = sorted(STAYS, key=page_explore.sort_by_price)
        self.assertEqual(ids(by_price)[0], "seminyak-cabin")
        by_rating = sorted(STAYS, key=page_explore.sort_by_rating, reverse=True)
        self.assertEqual(ids(by_rating)[0], "zermatt-chalet")


class AutomatedHostReplyTests(unittest.TestCase):
    LISTING = {"nearest_airport": "Zurich Airport (ZRH)", "destination": "Swiss Alps"}

    def reply(self, text, booking=None, listing=LISTING):
        db = mock.Mock()
        db.get_latest_booking_for_listing.return_value = booking
        db.get_listing_by_id.return_value = listing
        with mock.patch.object(page_messages, "database", db):
            return page_messages.get_automated_host_reply(text, "zermatt-chalet", 2), db

    def test_pin_question_returns_pin_for_confirmed_booking(self):
        text, db = self.reply("What is the gate passcode?", booking={"status": "Confirmed", "keyless_pin": "4821#"})
        self.assertIn("4821#", text)
        # The PIN lookup is always for THIS user only.
        db.get_latest_booking_for_listing.assert_called_once_with(2, "zermatt-chalet")

    def test_pin_is_hidden_without_confirmed_booking(self):
        for booking in (None, {"status": "Cancelled", "keyless_pin": "4821#"},
                        {"status": "Completed", "keyless_pin": "4821#"}):
            with self.subTest(booking=booking):
                text, _ = self.reply("door lock code?", booking=booking)
                self.assertNotIn("4821#", text)
                self.assertIn("activated upon confirmed reservation", text)

    def test_airport_question_names_the_destinations_airport(self):
        text, _ = self.reply("Could you arrange an airport pickup?")
        self.assertIn("Zurich Airport (ZRH)", text)

    def test_early_check_in_question(self):
        text, _ = self.reply("Can we get EARLY check-in?")
        self.assertIn("Standard check-in is at 2:00 PM", text)

    def test_other_questions_get_destination_greeting(self):
        text, _ = self.reply("Is there a hairdryer?")
        self.assertIn("make your Swiss Alps stay unforgettable", text)

    def test_missing_listing_uses_safe_defaults(self):
        text, _ = self.reply("Need a driver from the airport", listing=None)
        self.assertIn("the nearest airport", text)

    def test_pin_rule_wins_over_other_keywords(self):
        # "pin" is checked first, so this never reveals airport info instead of the PIN rule.
        text, _ = self.reply("airport pickup and PIN please", booking={"status": "Confirmed", "keyless_pin": "1111#"})
        self.assertIn("1111#", text)

    def test_wifi_credentials(self):
        self.assertEqual(page_messages.get_sample_wifi_credentials("villa-paradiso"), ("ParadisoJungle_5G", "ubudescape2026"))
        # Other properties get a network name built from the first 18 characters of the property id.
        self.assertEqual(page_messages.get_sample_wifi_credentials("misty-alpine-chalet-in-zermatt"),
                         ("OffStays_misty-alpine-chale", "welcome2026"))


class SessionStatusTests(unittest.TestCase):
    def test_labels_for_login_history(self):
        with mock.patch.object(page_profile, "st", FakeStreamlit({"session_id": 10})):
            self.assertEqual(page_profile.session_status({"session_id": 10, "is_active": 1}), "This session")
            self.assertEqual(page_profile.session_status({"session_id": 9, "is_active": 1}), "Not logged out")
            self.assertEqual(page_profile.session_status({"session_id": 8, "is_active": 0}), "Logged out")


if __name__ == "__main__":
    unittest.main()
