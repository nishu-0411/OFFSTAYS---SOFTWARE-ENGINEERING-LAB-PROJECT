# Unit tests for the small helpers in database.py. MySQL is MOCKED:
# either fetch_one / fetch_all / execute are patched, or get_connection returns a FakeConnection.

import datetime
import decimal
import json
import unittest
from unittest import mock

import pymysql

import database
from tests.support.fakes import FakeConnection, FakeCursor


class CleanValueTests(unittest.TestCase):
    def test_whole_decimal_becomes_int(self):
        value = database._clean_value(decimal.Decimal("185.00"))
        self.assertEqual(value, 185)
        self.assertIsInstance(value, int)

    def test_fractional_decimal_becomes_float(self):
        value = database._clean_value(decimal.Decimal("4.98"))
        self.assertEqual(value, 4.98)
        self.assertIsInstance(value, float)

    def test_datetime_and_date_become_iso_strings(self):
        self.assertEqual(database._clean_value(datetime.datetime(2026, 10, 27, 9, 15, 30, 123)), "2026-10-27T09:15:30")
        self.assertEqual(database._clean_value(datetime.date(2026, 10, 27)), "2026-10-27")

    def test_other_values_are_unchanged(self):
        for value in ("Bali", 3, None, 1.5):
            self.assertEqual(database._clean_value(value), value)

    def test_clean_row_and_rows(self):
        self.assertIsNone(database._clean_row(None))
        rows = database._clean_rows([{"price": decimal.Decimal("340.00"), "day": datetime.date(2026, 1, 2)}])
        self.assertEqual(rows, [{"price": 340, "day": "2026-01-02"}])


class QueryRunnerTests(unittest.TestCase):
    def test_execute_commits_and_returns_new_id(self):
        cursor = FakeCursor(first_lastrowid=42)
        conn = FakeConnection(cursor)
        with mock.patch.object(database, "get_connection", return_value=conn):
            new_id = database.execute("INSERT INTO saved_listings VALUES (%s)", (1,))
        self.assertEqual(new_id, 42)
        self.assertEqual((conn.commits, conn.rollbacks, conn.closed), (1, 0, True))

    def test_execute_rolls_back_and_re_raises_on_error(self):
        cursor = FakeCursor(fail_on={"INSERT": pymysql.err.IntegrityError(1062, "Duplicate")})
        conn = FakeConnection(cursor)
        with mock.patch.object(database, "get_connection", return_value=conn):
            with self.assertRaises(pymysql.err.IntegrityError):
                database.execute("INSERT INTO users VALUES (%s)", ("x",))
        self.assertEqual((conn.commits, conn.rollbacks, conn.closed), (0, 1, True))

    def test_fetch_helpers_clean_rows_and_close_connection(self):
        cursor = FakeCursor(fetchall_results=[[{"n": decimal.Decimal("2.50")}]],
                            fetchone_results=[{"n": decimal.Decimal("7.00")}])
        conn = FakeConnection(cursor)
        with mock.patch.object(database, "get_connection", return_value=conn):
            self.assertEqual(database.fetch_all("SELECT 1"), [{"n": 2.5}])
            self.assertEqual(database.fetch_one("SELECT 1"), {"n": 7})
        self.assertTrue(conn.closed)


class CheckDatabaseReadyTests(unittest.TestCase):
    # app.py shows these messages instead of crashing, so each MySQL error code is mapped.
    def ready(self, side_effect=None, return_value=None):
        with mock.patch.object(database, "fetch_one", side_effect=side_effect, return_value=return_value):
            return database.check_database_ready()

    def test_ready_when_properties_exist(self):
        self.assertEqual(self.ready(return_value={"n": 100}), (True, ""))

    def test_empty_properties_table(self):
        ok, message = self.ready(return_value={"n": 0})
        self.assertFalse(ok)
        self.assertIn("02_seed_data.sql", message)

    def test_error_codes_are_translated_to_friendly_messages(self):
        cases = [
            (pymysql.err.OperationalError(1045, "Access denied"), "DB_PASSWORD"),
            (pymysql.err.OperationalError(1049, "Unknown database"), "does not exist yet"),
            (pymysql.err.OperationalError(2003, "Can't connect"), "Make sure the MySQL service is running"),
            (pymysql.err.OperationalError(2013, "Lost connection"), "Make sure the MySQL service is running"),
            (pymysql.err.ProgrammingError(1146, "Table doesn't exist"), "Tables are missing"),
            (pymysql.err.OperationalError(1205, "Lock wait timeout"), "MySQL error 1205"),
        ]
        for error, expected in cases:
            with self.subTest(code=error.args[0]):
                ok, message = self.ready(side_effect=error)
                self.assertFalse(ok)
                self.assertIn(expected, message)


class LogActivityTests(unittest.TestCase):
    def test_without_cursor_uses_execute_with_all_columns(self):
        with mock.patch.object(database, "execute") as execute:
            database.log_activity(7, "SEARCH", "Searched stays", "search", 12, {"guests": 2},
                                  status="SUCCESS", session_id=55)
        sql, params = execute.call_args.args
        self.assertIn("INSERT INTO activity_logs", sql)
        user_id, session_id, activity_type, entity_type, entity_id, description, details, status, created_at = params
        self.assertEqual((user_id, session_id, activity_type, entity_type), (7, 55, "SEARCH", "search"))
        self.assertEqual(entity_id, "12")  # stored as text in VARCHAR(60)
        self.assertEqual(json.loads(details), {"guests": 2})
        self.assertIsInstance(created_at, datetime.datetime)
        self.assertEqual(created_at.microsecond, 0)

    def test_with_cursor_joins_the_callers_transaction(self):
        cursor = FakeCursor()
        with mock.patch.object(database, "execute") as execute:
            database.log_activity(7, "BOOKING_CREATED", "Booking confirmed", cursor=cursor)
        execute.assert_not_called()
        self.assertEqual(len(cursor.find("INSERT INTO activity_logs")), 1)

    def test_long_description_is_cut_to_500_characters(self):
        with mock.patch.object(database, "execute") as execute:
            database.log_activity(None, "REGISTER_FAILED", "x" * 900)
        self.assertEqual(len(execute.call_args.args[1][5]), 500)

    def test_empty_details_and_missing_entity_are_stored_as_null(self):
        with mock.patch.object(database, "execute") as execute:
            database.log_activity(None, "LOGIN_FAILED", "Login failed")
        params = execute.call_args.args[1]
        self.assertIsNone(params[4])  # entity_id
        self.assertIsNone(params[6])  # details

    def test_dates_in_details_are_serialised(self):
        with mock.patch.object(database, "execute") as execute:
            database.log_activity(1, "X", "d", details={"day": datetime.date(2026, 1, 2)})
        self.assertEqual(json.loads(execute.call_args.args[1][6]), {"day": "2026-01-02"})


class SmallQueryTests(unittest.TestCase):
    def test_failed_login_count_uses_time_window(self):
        with mock.patch.object(database, "fetch_one", return_value={"n": 3}) as fetch_one:
            count = database.count_recent_failed_logins("a@b.com", 15)
        self.assertEqual(count, 3)
        sql, (email, cutoff) = fetch_one.call_args.args
        self.assertIn("LOGIN_FAILED", sql)
        self.assertEqual(email, "a@b.com")
        age = datetime.datetime.now() - cutoff
        self.assertTrue(datetime.timedelta(minutes=14) < age < datetime.timedelta(minutes=16))

    def test_toggle_saved_listing_removes_existing_bookmark(self):
        with mock.patch.object(database, "fetch_one", return_value={"x": 1}), \
             mock.patch.object(database, "execute") as execute:
            self.assertFalse(database.toggle_saved_listing(2, "villa-paradiso"))
        self.assertIn("DELETE FROM saved_listings", execute.call_args.args[0])

    def test_toggle_saved_listing_adds_new_bookmark(self):
        with mock.patch.object(database, "fetch_one", return_value=None), \
             mock.patch.object(database, "execute") as execute:
            self.assertTrue(database.toggle_saved_listing(2, "villa-paradiso"))
        self.assertIn("INSERT INTO saved_listings", execute.call_args.args[0])
        self.assertEqual(execute.call_args.args[1][:2], (2, "villa-paradiso"))

    def test_price_bounds_fall_back_when_no_properties(self):
        with mock.patch.object(database, "fetch_one", return_value={"lo": None, "hi": None}):
            self.assertEqual(database.get_price_bounds(), (50, 400))
        with mock.patch.object(database, "fetch_one", return_value={"lo": 60, "hi": 1110}):
            self.assertEqual(database.get_price_bounds(), (60, 1110))

    def test_availability_true_only_when_no_overlapping_booking(self):
        with mock.patch.object(database, "fetch_one", return_value={"n": 0}) as fetch_one:
            self.assertTrue(database.is_listing_available("villa-paradiso", "2026-12-01", "2026-12-05"))
        # Overlap rule parameters: (property, new_check_out, new_check_in)
        self.assertEqual(fetch_one.call_args.args[1], ("villa-paradiso", "2026-12-05", "2026-12-01"))
        with mock.patch.object(database, "fetch_one", return_value={"n": 1}):
            self.assertFalse(database.is_listing_available("villa-paradiso", "2026-12-01", "2026-12-05"))

    def test_reviews_get_friendly_month_dates_and_alias_fields(self):
        rows = [{"review_id": 1, "author_name": "Aarav Kapoor", "author_location": "Mumbai, India",
                 "review_date": "2026-08-14", "rating": 5}]
        with mock.patch.object(database, "fetch_all", return_value=rows):
            review = database.get_listing_reviews("villa-paradiso")[0]
        self.assertEqual(review["review_date"], "August 2026")
        self.assertEqual(review["author"], "Aarav Kapoor")
        self.assertEqual(review["location"], "Mumbai, India")

    def test_bookings_by_status_always_filters_by_user(self):
        with mock.patch.object(database, "fetch_all", return_value=[]) as fetch_all:
            database.get_bookings_by_status(9, ["Completed", "Cancelled"])
        sql, params = fetch_all.call_args.args
        self.assertIn("WHERE b.user_id = %s AND b.status IN (%s,%s)", sql)
        self.assertEqual(params, (9, "Completed", "Cancelled"))

    def test_attach_media_groups_images_and_amenities(self):
        listings = [{"id": "a"}, {"id": "b"}]
        images = [{"property_id": "a", "image_url": "u1"}, {"property_id": "a", "image_url": "u2"}]
        amenities = [{"property_id": "b", "label": "Sauna"}, {"property_id": "b", "label": "Fireplace"}]
        with mock.patch.object(database, "fetch_all", side_effect=[images, amenities]):
            result = database._attach_media(listings)
        self.assertEqual(result[0]["image_urls"], "u1|u2")
        self.assertEqual(result[0]["amenities"], "")
        self.assertEqual(result[1]["amenities"], "Sauna|Fireplace")
        self.assertTrue(result[1]["image_urls"].startswith("https://images.unsplash.com/"))  # default photo

    def test_attach_media_skips_queries_for_empty_list(self):
        with mock.patch.object(database, "fetch_all") as fetch_all:
            self.assertEqual(database._attach_media([]), [])
        fetch_all.assert_not_called()

    def test_mark_thread_read_returns_number_of_updated_messages(self):
        cursor = FakeCursor(execute_results=[3])
        conn = FakeConnection(cursor)
        with mock.patch.object(database, "get_connection", return_value=conn):
            self.assertEqual(database.mark_thread_read(2, "villa-paradiso"), 3)
        self.assertEqual(conn.commits, 1)
        self.assertEqual(cursor.executed[0][1], (2, "villa-paradiso"))

    def test_notification_updates_are_scoped_to_the_user(self):
        with mock.patch.object(database, "execute") as execute:
            database.mark_notification_as_read(2, 99)
        sql, params = execute.call_args.args
        self.assertIn("notification_id = %s AND user_id = %s", sql)
        self.assertEqual(params, (99, 2))


if __name__ == "__main__":
    unittest.main()
