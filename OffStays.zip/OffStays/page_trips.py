# page_trips.py: My Trips, Reviews, Bookmarks & Notifications Dashboard.
#
# WHAT THIS FILE DOES:
#   Renders a 4-tab post-booking management center for the logged-in guest:
#     - Tab 1: Upcoming Stays (live countdowns, keyless door PIN guides, plain-text
#       invoice downloads, and booking cancellations with automated refund rules).
#     - Tab 2: Past Stays & Reviews (history of completed/cancelled stays, plus an
#       interactive form to write reviews and star ratings for completed trips).
#     - Tab 3: Saved Sanctuaries (the user's wishlist, with direct detail links and removal).
#     - Tab 4: In-App Notifications (chronological alert feed with category filters and
#       'Mark all as read' functionality).
#
# WHY THIS STEP IS NECESSARY:
#   Guests need a centralized dashboard to track their upcoming travel dates, retrieve
#   access codes on arrival day, obtain itemized VAT receipts for expense reporting,
#   and review stays they have experienced.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Queries MySQL tables: `bookings`, `reviews`, `saved_listings`, `notifications`.
#   - Calls `database.cancel_booking()` to process cancellations and issue refunds.
#   - Calls `database.add_review()` to publish ratings and recalculate the property's
#     cached average score in MySQL.
#   - Logs `INVOICE_DOWNLOADED`, `UNSAVE_PROPERTY`, and `NOTIFICATION_READ` events.

import streamlit as st  # Streamlit UI framework (tabs, expanders, forms, sliders, download buttons).
import datetime  # Standard module for calendar countdowns and cancellation policy math.
import database  # Database queries for bookings, reviews, saved listings, and notifications.
import activity  # Audit logging (INVOICE_DOWNLOADED, NOTIFICATIONS_READ_ALL, etc.) and navigation.
import auth  # Retrieves current authenticated user dictionary.


def generate_invoice_text(booking, user):
    # WHAT: Generates an itemized plain-text receipt suitable for download.
    # WHY:  Provides guests with a formal record of their reservation and tax breakdown.
    inv = f"""============================================================
OFFSTAYS SANCTUARY RESERVATION INVOICE
============================================================
Booking Reference : {booking['ref_code']}
Status            : {booking['status']}
Date Issued       : {booking['created_at'][:10]}

GUEST DETAILS
Name              : {user['full_name']} (#USR-{user['user_id']:04d})
Email             : {user['email']}

PROPERTY DETAILS
Sanctuary         : {booking['listing_title']}
Location          : {booking['listing_location']}
Host              : {booking['host_name']}

STAY SCHEDULE
Check-in Date     : {booking['check_in']} (from 2:00 PM)
Check-out Date    : {booking['check_out']} (by 11:00 AM)
Total Duration    : {booking['nights']} night(s)
Total Guests      : {booking['guests']}

FINANCIAL BREAKDOWN
Nightly Rate      : ${booking['price_per_night']:.2f}
Stay Subtotal     : ${booking['stay_cost']:.2f}
Cleaning Fee      : ${booking['cleaning_fee']:.2f}
Service Concierge : ${booking['service_fee']:.2f}
Occupancy Taxes   : ${booking['taxes']:.2f}
------------------------------------------------------------
TOTAL AMOUNT PAID : ${booking['total_price']:.2f} (USD)
Payment Method    : {booking['payment_method']} (Simulated)
Transaction Ref   : {booking['transaction_ref']}
============================================================
Thank you for booking with OFFSTAYS. Have a restful journey!
============================================================
"""
    return inv


def calculate_cancellation_refund(booking, days_to_arrival):
    # WHAT: Applies the 48-hour cancellation rule and returns (refund_amount, policy_note).
    # WHY:  Kept as a separate function so the refund rule can be unit tested without the UI.
    #   >= 2 days before check-in: 100% full refund
    #   <  2 days before check-in: 50% of stay cost + cleaning fee
    if days_to_arrival >= 2:
        refund_est = booking["total_price"]
        policy_note = "Full refund (simulated) as cancellation is more than 48 hours prior to check-in."
    else:
        refund_est = max(0.0, round((booking["stay_cost"] * 0.50) + booking["cleaning_fee"], 2))
        policy_note = "50% of stay cost plus cleaning fee refunded (simulated) due to late cancellation."
    return refund_est, policy_note


def log_invoice_download(booking_id, ref_code):
    # Callback triggered by st.download_button: records invoice download in MySQL activity log.
    activity.log_event("INVOICE_DOWNLOADED", f"Downloaded invoice {ref_code}", "booking", booking_id)


def render():
    user = auth.current_user()
    user_id = user["user_id"]
    session_id = st.session_state.get("session_id")
    st.title("My Trips & Activity")
    
    # Check for any success flash message carried over after a cancellation or review submission
    trips_flash = st.session_state.pop("trips_flash", None)
    if trips_flash:
        st.success(trips_flash)

    # 4 distinct tabs organizing user engagement
    tab_upcoming, tab_past, tab_saved, tab_notifs = st.tabs([
        "Upcoming Stays",
        "Past Stays & Reviews",
        "Saved Sanctuaries",
        "Notifications"
    ])

    today = datetime.date.today()
    today_str = today.isoformat()

    # ---------------- TAB 1: UPCOMING STAYS
    with tab_upcoming:
        st.subheader("Your Upcoming Sanctuaries")
        # Query confirmed bookings for this user from MySQL
        confirmed_bookings = database.get_bookings_by_status(user_id, ["Confirmed"])

        # Filter stays where check-out date has not passed
        upcoming = [b for b in confirmed_bookings if b["check_out"] >= today_str]
        upcoming.reverse()  # Display the soonest arrival first

        if len(upcoming) == 0:
            st.info("You have no upcoming stays booked.")
            if st.button("Explore Stays to Book", key="empty_up_btn"):
                activity.go_to("explore")
        else:
            for b in upcoming:
                with st.container(border=True):
                    up_col1, up_col2 = st.columns([1, 2])
                    with up_col1:
                        photos = b["listing_images"].split("|")
                        st.image(photos[0], use_container_width=True)
                    with up_col2:
                        st.markdown(f"### {b['listing_title']}")
                        st.caption(f"Ref: **{b['ref_code']}** · {b['listing_location']}")

                        # Compute countdown days until arrival
                        check_in_dt = datetime.date.fromisoformat(b["check_in"])
                        days_to_arrival = (check_in_dt - today).days
                        if days_to_arrival > 0:
                            st.markdown(f"⏳ **Countdown:** {days_to_arrival} day(s) until check-in ({b['check_in']} to {b['check_out']})")
                        else:
                            st.markdown(f"🏝️ **Checked in** · Enjoy your stay! ({b['check_in']} to {b['check_out']})")
                        st.write(f"Guests: {b['guests']} · Nights: {b['nights']} · Total Paid: **\\${b['total_price']:.2f}**")

                        # Keyless Smart Lock PIN Guide
                        with st.expander("🔑 Check-in Guide & Keyless PIN"):
                            st.write(f"**Check-in Time:** Anytime after 2:00 PM")
                            st.write(f"**Check-out Time:** By 11:00 AM")
                            st.write(f"**Keyless Smart Lock PIN:** `{b['keyless_pin']}`")
                            st.caption("Upon arrival, enter this 4-digit code followed by the '#' key on the smart door lock keypad.")

                        # Action row: Message host, Download Invoice, Cancel Booking
                        act_c1, act_c2, act_c3 = st.columns(3)
                        with act_c1:
                            if st.button("💬 Message Host", key=f"msg_host_btn_{b['id']}", use_container_width=True):
                                st.session_state["chat_listing_id"] = b["listing_id"]
                                activity.go_to("messages")
                        with act_c2:
                            invoice_content = generate_invoice_text(b, user)
                            st.download_button(
                                label="📄 Download Invoice",
                                data=invoice_content,
                                file_name=f"Invoice_{b['ref_code'].replace('#', '')}.txt",
                                mime="text/plain",
                                key=f"dl_inv_{b['id']}",
                                use_container_width=True,
                                on_click=log_invoice_download,
                                args=(b["id"], b["ref_code"])
                            )
                        with act_c3:
                            # Cancellation expander with automated refund rule evaluation
                            if days_to_arrival <= 0:
                                st.caption("Stay in progress - cancellation is no longer available.")
                            else:
                                with st.expander("Cancel Booking"):
                                    st.write("Cancellation Policy:")
                                    # 48-Hour Cancellation Rule (see calculate_cancellation_refund above).
                                    refund_est, policy_note = calculate_cancellation_refund(b, days_to_arrival)

                                    st.write(f"Estimated Refund: **\\${refund_est:.2f}**")
                                    st.caption(policy_note)
                                    confirm_cancel = st.checkbox("Confirm cancellation", key=f"confirm_c_{b['id']}")
                                    if st.button("Submit Cancellation", key=f"do_cancel_{b['id']}"):
                                        if confirm_cancel:
                                            if database.cancel_booking(user_id, session_id, b["id"], refund_est, policy_note):
                                                st.session_state["trips_flash"] = f"Booking {b['ref_code']} cancelled. Simulated refund: \\${refund_est:.2f}"
                                            st.rerun()
                                        else:
                                            st.error("Please tick the confirmation checkbox.")

    # ---------------- TAB 2: PAST STAYS & REVIEWS
    with tab_past:
        st.subheader("Past Sanctuaries & Written Reviews")
        past_bookings = database.get_bookings_by_status(user_id, ["Completed", "Cancelled"])

        if len(past_bookings) == 0:
            st.info("No past stays recorded.")
        else:
            for pb in past_bookings:
                with st.container(border=True):
                    p_c1, p_c2 = st.columns([1, 2])
                    with p_c1:
                        photos = pb["listing_images"].split("|")
                        st.image(photos[0], use_container_width=True)
                    with p_c2:
                        st.markdown(f"### {pb['listing_title']}")
                        st.caption(f"Ref: {pb['ref_code']} · Status: **{pb['status']}** · Dates: {pb['check_in']} to {pb['check_out']}")
                        st.write(f"Total: \\${pb['total_price']:.2f} · Host: {pb['host_name']}")

                        # If stay is completed, check if guest has already submitted a review
                        if pb["status"] == "Completed":
                            already_reviewed = database.has_reviewed_booking(pb["id"])
                            if already_reviewed:
                                st.success("✓ You have submitted a review for this stay.")
                            else:
                                with st.expander("✍️ Write a Review for this Stay"):
                                    # Wrap in st.form to prevent re-execution while adjusting slider/text
                                    with st.form(key=f"review_form_{pb['id']}"):
                                        star_rating = st.slider("Rating (Stars)", min_value=1.0, max_value=5.0, value=5.0, step=0.1)
                                        review_text = st.text_area("Your Review Feedback", placeholder="Describe your experience at this sanctuary...")
                                        submit_rev = st.form_submit_button("Submit Review")

                                        if submit_rev:
                                            if not review_text.strip():
                                                st.error("Please enter review comments.")
                                            else:
                                                # Use the logged-in user's profile location (e.g. "Mumbai, India")
                                                author_location = ", ".join([x for x in [user.get("city"), user.get("country")] if x]) or "OffStays guest"
                                                ok, msg = database.add_review(
                                                    user_id,
                                                    session_id,
                                                    pb["listing_id"],
                                                    pb["id"],
                                                    user["full_name"],
                                                    author_location,
                                                    round(star_rating, 2),
                                                    review_text.strip()
                                                )
                                                if ok:
                                                    st.session_state["trips_flash"] = msg
                                                    st.rerun()
                                                else:
                                                    st.error(msg)

    # ---------------- TAB 3: SAVED SANCTUARIES
    with tab_saved:
        st.subheader("Your Bookmarked Stays")
        saved_listing_ids = database.get_saved_listing_ids(user_id)

        if len(saved_listing_ids) == 0:
            st.info("You haven't saved any sanctuaries yet. Click the heart icon on any stay card to save it here.")
        else:
            for s_id in saved_listing_ids:
                s_stay = database.get_listing_by_id(s_id)
                if s_stay:
                    with st.container(border=True):
                        s_c1, s_c2 = st.columns([1, 2])
                        with s_c1:
                            s_photos = s_stay["image_urls"].split("|")
                            st.image(s_photos[0], use_container_width=True)
                        with s_c2:
                            st.markdown(f"### {s_stay['title']}")
                            st.caption(f"{s_stay['badge']} · {s_stay['location']}")
                            st.write(f"★ {s_stay['rating']:.2f} · **\\${s_stay['price_per_night']}** / night")

                            s_btn1, s_btn2 = st.columns(2)
                            with s_btn1:
                                if st.button("View Details", key=f"view_saved_{s_stay['id']}", use_container_width=True):
                                    activity.open_property(s_stay["id"], "saved")
                            with s_btn2:
                                if st.button("Remove Bookmark", key=f"rem_saved_{s_stay['id']}", use_container_width=True):
                                    database.toggle_saved_listing(user_id, s_stay["id"])
                                    activity.log_event("UNSAVE_PROPERTY", f"Removed {s_stay['title']} from wishlist", "property", s_stay["id"], {"source": "trips"})
                                    st.rerun()

    # ---------------- TAB 4: NOTIFICATIONS
    with tab_notifs:
        st.subheader("Activity & Notifications")

        # Notification filter & Mark all read controls
        notif_top1, notif_top2 = st.columns([3, 1])
        with notif_top1:
            notif_filter = st.radio("Filter", ["All", "Bookings", "Account"], horizontal=True)
        with notif_top2:
            if st.button("Mark all as read", use_container_width=True):
                database.mark_all_notifications_as_read(user_id)
                activity.log_event("NOTIFICATIONS_READ_ALL", "Marked all notifications as read", "notification", None)
                st.rerun()

        st.markdown("---")

        # Fetch notifications matching filter from MySQL
        notifs = database.get_notifications(user_id, notif_filter)
        if len(notifs) == 0:
            st.info("No notifications to display.")
        else:
            for n in notifs:
                with st.container(border=True):
                    n_col1, n_col2 = st.columns([4, 1])
                    with n_col1:
                        read_icon = "⚪" if n["is_read"] == 0 else "✓"
                        st.markdown(f"**{read_icon} {n['title']}** · *{n['kind'].capitalize()}*")
                        st.write(n["description"])
                        st.caption(f"Received: {n['created_at'][:16].replace('T', ' ')}")
                    with n_col2:
                        if n["is_read"] == 0:
                            if st.button("Mark read", key=f"mark_read_{n['notification_id']}", use_container_width=True):
                                database.mark_notification_as_read(user_id, n["notification_id"])
                                activity.log_event("NOTIFICATION_READ", f"Read notification: {n['title']}", "notification", n["notification_id"])
                                st.rerun()