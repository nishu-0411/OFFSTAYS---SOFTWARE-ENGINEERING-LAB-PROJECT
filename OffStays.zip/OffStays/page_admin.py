# page_admin.py: Administrative Operations & Platform Telemetry Dashboard.
#
# WHAT THIS FILE DOES:
#   Renders an administrative control center accessible strictly to users with role = 'admin':
#     1. Security Guard: Verifies that the authenticated user possesses administrative rights;
#        non-admin users are immediately rejected.
#     2. Platform Metrics: Displays high-level business telemetry (total user count with new
#        signups today, active confirmed bookings, gross booking volume in USD, and today's
#        successful versus failed login attempts).
#     3. Global Activity Log: An interactive audit feed querying all system events across
#        all users, with dropdown filtering by activity type, free-text search (name/email),
#        configurable row limits, and a one-click CSV export button.
#     4. User Directory: A complete tabular view of all registered guests, hosts, and admins
#        in the MySQL `users` table.
#
# WHY THIS STEP IS NECESSARY:
#   Provides administrative visibility into platform performance, customer adoption,
#   security incidents (such as brute-force password guessing attacks), and system integrity.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Protects administrative routes by checking `auth.current_user()["role"]`.
#   - Queries aggregate business statistics via `database.get_platform_stats()`.
#   - Queries filtered audit trails via `database.get_activity_logs()`.
#   - Queries the full user directory via `database.get_all_users()`.
#   - Logs `EXPORT_ACTIVITY_LOG` whenever an administrator downloads an audit CSV.

import pandas as pd  # Formats database rows into DataFrames for st.dataframe display and CSV export.
import streamlit as st  # Streamlit UI framework (metric cards, tabs, selectboxes, dataframes, download buttons).
import auth  # Retrieves current authenticated user to enforce role-based access control.
import activity  # Logs administrative actions (EXPORT_ACTIVITY_LOG).
import database  # MySQL queries for platform statistics, activity audit logs, and user directory.


def log_export(row_count):
    # WHAT: Callback function executed when an admin clicks the CSV download button.
    # WHY:  Auditing the download of compliance or user activity logs is standard security practice.
    # HOW:  Calls activity.log_event to record an 'EXPORT_ACTIVITY_LOG' entry in MySQL.
    activity.log_event("EXPORT_ACTIVITY_LOG", f"Exported {row_count} activity log rows", "activity_logs", None)


def render():
    user = auth.current_user()
    
    # ROLE-BASED ACCESS CONTROL GUARD:
    # Non-admin users are strictly blocked from rendering or viewing the dashboard.
    if user["role"] != "admin":
        st.error("Admins only. Access restricted.")
        return

    st.title("🛡️ Admin Dashboard")
    st.caption("Live data from MySQL · every register, login and action is recorded in `activity_logs`.")

    # Fetch aggregate platform metrics from MySQL
    stats = database.get_platform_stats()
    
    # 4-Column Business KPI Cards
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Users", stats["users"], f"+{stats['new_users_today']} today")
    m2.metric("Active bookings", stats["active_bookings"])
    m3.metric("Gross booking value", f"${stats['revenue']:,.0f}")
    # Display failed logins with an inverse delta color (red highlight indicates security alert)
    m4.metric("Logins today", stats["logins_today"], f"{stats['failed_today']} failed", delta_color="inverse")

    # Split dashboard into two primary tabs: Activity Log and User Directory
    tab_logs, tab_users = st.tabs(["Activity log", "Users"])

    # ---------------- TAB 1: GLOBAL AUDIT LOG
    with tab_logs:
        # Search & Filter Controls: [Activity Type Dropdown, Search Box, Row Limit Slider]
        f1, f2, f3 = st.columns([1.2, 2, 1])
        with f1:
            types = ["All activities"] + database.get_activity_types()
            chosen_type = st.selectbox("Activity type", types)
        with f2:
            search = st.text_input("Search user name / email", placeholder="e.g. sarah")
        with f3:
            limit = st.number_input("Rows", min_value=50, max_value=2000, value=300, step=50)

        # Query filtered audit logs from MySQL
        logs = database.get_activity_logs(
            None if chosen_type == "All activities" else chosen_type,
            search.strip() or None,
            int(limit)
        )
        
        st.caption(f"Showing {len(logs)} of {stats['total_logs']} log rows (newest first).")
        
        if logs:
            df = pd.DataFrame(logs)[["log_id", "created_at", "user_name", "email", "activity_type", "status",
                                     "description", "entity_type", "entity_id", "session_id", "details"]]
            # Clean ISO timestamps into human-readable date-time strings
            df["created_at"] = df["created_at"].str.replace("T", " ")
            st.dataframe(df, use_container_width=True, hide_index=True, height=480)
            
            # Export CSV Download Button
            st.download_button(
                "⬇️ Export as CSV",
                df.to_csv(index=False),
                file_name="offstays_activity_log.csv",
                mime="text/csv",
                on_click=log_export,
                args=(len(df),)
            )

    # ---------------- TAB 2: REGISTERED USERS DIRECTORY
    with tab_users:
        st.caption("Complete directory of registered accounts in MySQL `users` table.")
        users = database.get_all_users()
        st.dataframe(pd.DataFrame(users), use_container_width=True, hide_index=True, height=480)