# setup_database.py: Automated Database Initialization & Deployment Script.
#
# WHAT THIS FILE DOES:
#   This is a command-line setup utility that automates the deployment of our MySQL database.
#   Instead of manually opening MySQL Workbench and running three separate SQL files in order,
#   a developer or examiner can simply run:
#       python setup_database.py          (asks for interactive confirmation)
#       python setup_database.py --yes    (automated execution without prompt)
#
#   It connects to the MySQL server using `db_config.py`, drops any existing `offstays`
#   database, and sequentially executes:
#     1. `sql/01_schema.sql` (Creates database and all 16 tables with keys & constraints).
#     2. `sql/02_seed_data.sql` (Inserts realistic sample records for users, stays, reviews, etc.).
#     3. `sql/04_views_and_reports.sql` (Creates analytical database views and reporting queries).
#
# WHY THIS STEP IS NECESSARY:
#   Provides a reliable, one-command deployment mechanism. It guarantees that our database
#   schema, sample stays, and administrative accounts can be reproduced consistently on any
#   evaluator's computer in seconds without manual SQL errors.
#
# HOW IT WORKS:
#   - Uses PyMySQL with the `CLIENT.MULTI_STATEMENTS` flag enabled, allowing entire
#     multi-statement SQL script files to be processed in a single execution call.
#   - Iterates through results with `cursor.nextset()` to ensure every statement executes.
#   - Performs a post-installation count check on `users` and `properties` to verify success.

import os  # Standard library for resolving directory and file paths.
import sys  # Standard library for reading command-line arguments (--yes) and exit codes.

import pymysql  # Pure-Python MySQL client driver.
from pymysql.constants import CLIENT  # MULTI_STATEMENTS flag allows executing entire .sql files at once.

import db_config  # Imports host, port, user, and password from our central configuration file.

# Resolve the absolute path to the sql/ folder relative to this setup script
SQL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sql")

# Ordered list of SQL deployment scripts (order matters due to foreign key relationships)
SCRIPTS = ["01_schema.sql", "02_seed_data.sql", "04_views_and_reports.sql"]


def run_script(conn, filename):
    # WHAT: Reads a .sql file from disk and executes all statements inside it on the MySQL server.
    # HOW:  Reads UTF-8 text, executes via cursor, and loops through `cursor.nextset()` until
    #       every statement in the multi-query script has completed.
    with open(os.path.join(SQL_DIR, filename), encoding="utf-8") as f:
        sql = f.read()
    with conn.cursor() as cursor:
        cursor.execute(sql)
        # Advance through all statement results in the script file
        while cursor.nextset():
            pass
    conn.commit()
    print(f"  ✓ {filename}")


def main():
    # Prompt user for safety confirmation unless the --yes flag was supplied
    if "--yes" not in sys.argv:
        answer = input(
            f"This will DROP and recreate the '{db_config.DB_NAME}' database on "
            f"{db_config.DB_HOST}:{db_config.DB_PORT}. Continue? (y/n): "
        )
        if answer.strip().lower() != "y":
            print("Cancelled.")
            return

    # Establish initial connection to MySQL Server
    # Note: We do not specify database=db_config.DB_NAME here because 01_schema.sql
    # contains the `CREATE DATABASE IF NOT EXISTS offstays;` and `USE offstays;` commands.
    try:
        conn = pymysql.connect(
            host=db_config.DB_HOST,
            port=db_config.DB_PORT,
            user=db_config.DB_USER,
            password=db_config.DB_PASSWORD,
            charset="utf8mb4",
            client_flag=CLIENT.MULTI_STATEMENTS  # Crucial flag enabling multi-statement execution.
        )
    except pymysql.err.OperationalError as e:
        print("Could not connect to MySQL:", e)
        print("Check that MySQL is running and that DB_PASSWORD in db_config.py is correct.")
        sys.exit(1)

    try:
        print("Setting up the OFFSTAYS database...")
        # Sequentially execute schema, seed data, and analytical views
        for script in SCRIPTS:
            run_script(conn, script)
            
        # Post-installation verification: Verify row counts in the newly populated tables
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) FROM offstays.users")
            users = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM offstays.properties")
            props = cursor.fetchone()[0]
            
        print(f"Done! {users} users and {props} properties loaded. Now run:  streamlit run app.py")
    finally:
        conn.close()


if __name__ == "__main__":
    main()