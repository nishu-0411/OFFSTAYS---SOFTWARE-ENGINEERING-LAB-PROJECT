# page_messages.py: Guest-Host Communication & Automated Response Engine.
#
# WHAT THIS FILE DOES:
#   Renders a two-column in-app messaging interface:
#     - Left Column: Lists all active and past conversation threads, with search filtering
#       and live unread message badges.
#     - Right Column: Displays the active chat thread with message bubbles, stay contact
#       details (phone, location), sensitive keyless PINs (for confirmed bookings),
#       quick-reply suggestion buttons, and a chat input box.
#     - Automated Response Engine: Simulates intelligent host responses based on keyword
#       detection (e.g. gate PIN inquiries, airport transfers, early check-in).
#
# WHY THIS STEP IS NECESSARY:
#   Provides guests with direct communication with their property hosts. The automated
#   response engine ensures that during viva demonstrations, an examiner can ask typical
#   guest questions and receive instantaneous, context-aware answers without needing
#   a second person to act as the host.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Queries MySQL tables: `messages`, `properties`, `hosts`, and `bookings`.
#   - Calls `database.mark_thread_read()` when opening a conversation to update badge counts.
#   - Calls `database.send_message()` to persist both guest and host messages to MySQL.
#   - Logs `OPEN_CHAT` and `MESSAGE_SENT` events into `activity_logs`.

import streamlit as st  # Streamlit UI framework (chat messages, chat input, columns, expanders).
import database  # Database queries for messages, bookings, thread summaries, and listings.
import activity  # Logs OPEN_CHAT and MESSAGE_SENT audit events.
import auth  # Retrieves current authenticated user dictionary.


def get_automated_host_reply(user_text, listing_id, user_id):
    # WHAT: Generates an intelligent simulated host reply based on keywords in the guest's message.
    # WHY:  Enables realistic, dynamic host interaction during demonstrations.
    # HOW:  Inspects lowercase text for specific keywords and looks up real booking/destination details.
    text_lower = user_text.lower()

    # Rule 1: Check for passcode or door PIN inquiry.
    if "passcode" in text_lower or "pin" in text_lower or "gate" in text_lower or "lock" in text_lower:
        latest_booking = database.get_latest_booking_for_listing(user_id, listing_id)
        if latest_booking and latest_booking["status"] == "Confirmed":
            return f"Your electronic keyless entry PIN is {latest_booking['keyless_pin']}. Simply enter this code followed by the '#' key on the front keypad. (automated demo reply)"
        else:
            return "Keyless PINs are activated upon confirmed reservation. Let us know if you need any assistance! (automated demo reply)"

    # Look up property details to dynamically personalize airport names and destinations.
    listing = database.get_listing_by_id(listing_id)
    airport = listing["nearest_airport"] if listing else "the nearest airport"
    place = listing["destination"] if listing else "OFFSTAYS"

    # Rule 2: Check for airport transfer or pickup request.
    if "pickup" in text_lower or "airport" in text_lower or "driver" in text_lower:
        return f"We would be delighted to organize an airport transfer with our private driver from {airport}. Please share your flight number and arrival time! (automated demo reply)"

    # Rule 3: Check for early arrival or early check-in.
    if "early" in text_lower or "check-in" in text_lower or "checkin" in text_lower:
        return "Standard check-in is at 2:00 PM to give our housekeeping team sufficient time. If the previous guests leave early, we will message you right away! (automated demo reply)"

    # Default friendly fallback reply.
    return f"Thank you for reaching out! We are preparing everything for your arrival to make your {place} stay unforgettable. Let us know if you have any questions! (automated demo reply)"


def get_sample_wifi_credentials(listing_id):
    # WHAT: Returns realistic Wi-Fi network and password credentials for confirmed bookings.
    # HOW:  Returns specific credentials for popular sample stays or derives one from the listing ID.
    if listing_id == "villa-paradiso":
        return "ParadisoJungle_5G", "ubudescape2026"
    elif listing_id == "cliffside-uluwatu":
        return "UluwatuCliff_FastWiFi", "oceanwaves2026"
    elif listing_id == "cabin-seminyak":
        return "SeminyakOasis_Guest", "eatstreet2026"
    else:
        return "OffStays_" + listing_id[:18], "welcome2026"


def render():
    user = auth.current_user()
    user_id = user["user_id"]
    st.title("Messages")
    st.caption("Direct communication with your sanctuary hosts.")

    # Fetch all property conversations associated with this user from MySQL.
    conversations = database.get_conversations_summary(user_id)
    if len(conversations) == 0:
        st.info("You have no active conversations yet. Once you reserve or inquire about a stay, messages will appear here.")
        return

    # Pick the active conversation thread and mark it as read before rendering.
    # This ensures unread badge counters in the sidebar and chat list update immediately.
    conversation_ids = [c["id"] for c in conversations]
    if st.session_state.get("chat_listing_id") not in conversation_ids:
        st.session_state["chat_listing_id"] = conversations[0]["id"]
        
    if database.mark_thread_read(user_id, st.session_state["chat_listing_id"]) > 0:
        st.rerun()

    # Two-column layout: Left = Conversation List, Right = Active Chat Thread.
    col_list, col_chat = st.columns([1.2, 2.5])

    # ---------------- LEFT COLUMN: CONVERSATION LIST
    with col_list:
        st.markdown("### Conversations")
        search_query = st.text_input("Search chats", placeholder="Filter by host or stay...")
        filter_status = st.radio("Show", ["All", "Active", "Past"], horizontal=True)

        st.markdown("---")

        for conv in conversations:
            # Query the latest booking for this property to determine active or past status.
            booking = database.get_latest_booking_for_listing(user_id, conv["id"])
            b_status = booking["status"] if booking else "No Booking"

            # Apply status filter.
            if filter_status == "Active" and b_status != "Confirmed":
                continue
            if filter_status == "Past" and b_status not in ["Completed", "Cancelled"]:
                continue

            # Apply text search filter against title and host name.
            if search_query:
                q = search_query.lower()
                if q not in conv["title"].lower() and q not in conv["host_name"].lower():
                    continue

            # Fetch the latest message to display a preview snippet and count unread messages.
            msgs = database.get_messages_for_listing(user_id, conv["id"])
            last_text = msgs[-1]["text"] if len(msgs) > 0 else "No messages yet."
            unread = sum(1 for m in msgs if m["sender"] != "guest" and m["is_read"] == 0)
            
            # Truncate preview snippet to keep cards compact.
            if len(last_text) > 42:
                last_text = last_text[:40] + "..."

            # Conversation Selection Card
            with st.container(border=True):
                unread_tag = f" 🔴 {unread} new" if unread else ""
                st.markdown(f"**{conv['host_name']}** · *{conv['title']}*{unread_tag}")
                st.caption(f"Status: {b_status} · Last: {last_text}")
                
                # Button sets this conversation as active and records an audit log event.
                if st.button("Open Chat", key=f"chat_sel_{conv['id']}", use_container_width=True):
                    st.session_state["chat_listing_id"] = conv["id"]
                    activity.log_event("OPEN_CHAT", f"Opened chat with {conv['host_name']}", "property", conv["id"])
                    st.rerun()

    # ---------------- RIGHT COLUMN: ACTIVE CHAT THREAD
    with col_chat:
        active_id = st.session_state.get("chat_listing_id")
        listing = database.get_listing_by_id(active_id)
        if not listing:
            st.info("Select a conversation from the left to start chatting.")
            return

        latest_booking = database.get_latest_booking_for_listing(user_id, active_id)

        # Chat header banner
        st.markdown(f"### Chat with {listing['host_name']}")
        st.caption(f"Property: **{listing['title']}**")

        # Stay Details & Host Contact Expander
        with st.expander("Stay Details & Host Contact", expanded=False):
            info_c1, info_c2 = st.columns(2)
            with info_c1:
                st.write(f"📞 **Host Phone (Sample):** {listing['host_phone'] or 'Not shared'}")
                st.write(f"💬 **WhatsApp (Sample):** {listing['host_phone'] or 'Not shared'}")
                st.write(f"📍 {listing['location']}")
            with info_c2:
                # Sensitive entry credentials only reveal if a confirmed reservation exists.
                if latest_booking and latest_booking["status"] == "Confirmed":
                    wifi_net, wifi_pass = get_sample_wifi_credentials(active_id)
                    st.write(f"📶 **Wi-Fi Network:** `{wifi_net}`")
                    st.write(f"🔑 **Wi-Fi Password:** `{wifi_pass}`")
                    st.write(f"🔢 **Entry PIN:** `{latest_booking['keyless_pin']}`")
                else:
                    st.caption("Wi-Fi details and check-in PIN become visible upon a Confirmed reservation.")

        st.markdown("---")

        # Render message bubble history inside a scrollable container
        message_history = database.get_messages_for_listing(user_id, active_id)
        chat_container = st.container(height=380)
        with chat_container:
            for m in message_history:
                sender = m["sender"]
                if sender == "guest":
                    with st.chat_message("user"):
                        st.write(m["text"])
                        st.caption(f"Sent {m['sent_at'][:16].replace('T', ' ')}")
                elif sender == "host":
                    with st.chat_message("assistant"):
                        st.write(m["text"])
                        st.caption(f"{listing['host_name']} · {m['sent_at'][:16].replace('T', ' ')}")
                else:
                    # System notifications shown as info boxes.
                    st.info(f"⚙️ **System:** {m['text']}")

        # Quick Suggestion Chips (Pre-built inquiry buttons)
        st.markdown("**Quick questions:**")
        q_col1, q_col2, q_col3 = st.columns(3)
        quick_sent = None
        with q_col1:
            if st.button("What is the gate passcode?", key="quick_pin", use_container_width=True):
                quick_sent = "What is the gate passcode?"
        with q_col2:
            if st.button("Arrange airport pickup?", key="quick_airport", use_container_width=True):
                quick_sent = "Could you arrange an airport pickup?"
        with q_col3:
            if st.button("Can we get early check-in?", key="quick_early", use_container_width=True):
                quick_sent = "Can we get early check-in?"

        # Chat Input Box
        typed_message = st.chat_input("Write a message to your host...")

        # Process sending message (from quick-click button OR typed input)
        message_to_send = quick_sent if quick_sent else typed_message
        if message_to_send:
            # 1. Save guest message to MySQL.
            message_id = database.send_message(user_id, active_id, "guest", message_to_send)
            activity.log_event(
                "MESSAGE_SENT", f"Sent a message to {listing['host_name']}", "message", message_id,
                {"property_id": active_id, "quick_reply": quick_sent is not None, "length": len(message_to_send)}
            )
            # 2. Compute context-aware simulated host reply.
            auto_reply = get_automated_host_reply(message_to_send, active_id, user_id)
            # 3. Save automated host message (already marked read since user is actively viewing).
            database.send_message(user_id, active_id, "host", auto_reply, is_read=1)
            # 4. Re-run script to display new messages immediately.
            st.rerun()