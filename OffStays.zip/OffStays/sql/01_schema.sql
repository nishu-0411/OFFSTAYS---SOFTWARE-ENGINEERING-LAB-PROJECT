-- =====================================================================
-- OFFSTAYS · 01_schema.sql
-- MySQL 8.0+ schema for the OFFSTAYS luxury stay-booking platform (16 tables).
--
-- HOW TO RUN (MySQL Workbench):
--   File > Open SQL Script > 01_schema.sql > click the lightning bolt (Execute all).
--
-- WARNING: This script DROPS and recreates the `offstays` database.
--          Every booking, user and activity log in it will be deleted.
-- =====================================================================

DROP DATABASE IF EXISTS offstays;
CREATE DATABASE offstays CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE offstays;

-- ---------------------------------------------------------------------
-- 1. USERS: every account (guest, host, admin). Passwords are stored as
--    PBKDF2-SHA256 hashes with a per-user random salt, never as plain text.
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id         INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    full_name       VARCHAR(100)     NOT NULL,
    email           VARCHAR(150)     NOT NULL,
    phone           VARCHAR(20)      NULL,
    password_hash   CHAR(64)         NOT NULL,
    password_salt   CHAR(32)         NOT NULL,
    role            ENUM('guest','host','admin') NOT NULL DEFAULT 'guest',
    city            VARCHAR(80)      NULL,
    country         VARCHAR(80)      NULL,
    date_of_birth   DATE             NULL,
    avatar_url      VARCHAR(500)     NULL,
    is_active       TINYINT(1)       NOT NULL DEFAULT 1,
    created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at   DATETIME         NULL,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. DESTINATIONS: the places OFFSTAYS operates in (Bali, Goa, Maldives ...).
--    map_zoom is the zoom level used when the map shows this destination.
-- ---------------------------------------------------------------------
CREATE TABLE destinations (
    destination_id  INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    name            VARCHAR(60)      NOT NULL,
    country         VARCHAR(60)      NOT NULL,
    continent       VARCHAR(30)      NOT NULL,
    description     VARCHAR(500)     NOT NULL,
    latitude        DECIMAL(9,6)     NOT NULL,
    longitude       DECIMAL(9,6)     NOT NULL,
    map_zoom        TINYINT UNSIGNED NOT NULL DEFAULT 9,
    nearest_airport VARCHAR(120)     NOT NULL,
    timezone        VARCHAR(40)      NOT NULL,
    best_season     VARCHAR(80)      NULL,
    is_active       TINYINT(1)       NOT NULL DEFAULT 1,
    PRIMARY KEY (destination_id),
    UNIQUE KEY uq_destinations_name (name),
    KEY idx_destinations_country (country)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. HOSTS: host profile, one-to-one with a users row (role = 'host').
-- ---------------------------------------------------------------------
CREATE TABLE hosts (
    host_id         INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED     NOT NULL,
    destination_id  INT UNSIGNED     NULL,
    display_name    VARCHAR(100)     NOT NULL,
    avatar_url      VARCHAR(500)     NOT NULL,
    bio             VARCHAR(500)     NULL,
    is_superhost    TINYINT(1)       NOT NULL DEFAULT 0,
    response_rate   VARCHAR(10)      NOT NULL DEFAULT '-',
    response_time   VARCHAR(40)      NOT NULL DEFAULT '-',
    languages       VARCHAR(120)     NULL,
    hosting_since   DATE             NOT NULL,
    PRIMARY KEY (host_id),
    UNIQUE KEY uq_hosts_user (user_id),
    CONSTRAINT fk_hosts_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_hosts_destination FOREIGN KEY (destination_id) REFERENCES destinations(destination_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. PROPERTIES: the stays guests can book. rating / review_count are
--    cached aggregates that are updated whenever a new review is posted.
-- ---------------------------------------------------------------------
CREATE TABLE properties (
    property_id         VARCHAR(60)      NOT NULL,
    host_id             INT UNSIGNED     NOT NULL,
    destination_id      INT UNSIGNED     NOT NULL,
    title               VARCHAR(150)     NOT NULL,
    subtitle            VARCHAR(200)     NOT NULL,
    location            VARCHAR(200)     NOT NULL,
    area                VARCHAR(60)      NOT NULL,
    latitude            DECIMAL(9,6)     NOT NULL,
    longitude           DECIMAL(9,6)     NOT NULL,
    price_per_night     DECIMAL(10,2)    NOT NULL,
    rating              DECIMAL(3,2)     NOT NULL DEFAULT 0.00,
    review_count        INT UNSIGNED     NOT NULL DEFAULT 0,
    badge               VARCHAR(40)      NOT NULL,
    category            VARCHAR(40)      NOT NULL,
    bedrooms            TINYINT UNSIGNED NOT NULL,
    beds                TINYINT UNSIGNED NOT NULL,
    baths               DECIMAL(3,1)     NOT NULL,
    max_guests          TINYINT UNSIGNED NOT NULL,
    description         TEXT             NOT NULL,
    highlights          TEXT             NOT NULL,
    score_cleanliness   DECIMAL(2,1)     NOT NULL,
    score_accuracy      DECIMAL(2,1)     NOT NULL,
    score_checkin       DECIMAL(2,1)     NOT NULL,
    score_communication DECIMAL(2,1)     NOT NULL,
    score_location      DECIMAL(2,1)     NOT NULL,
    score_value         DECIMAL(2,1)     NOT NULL,
    is_active           TINYINT(1)       NOT NULL DEFAULT 1,
    created_at          DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (property_id),
    KEY idx_properties_destination (destination_id, area),
    KEY idx_properties_category (category),
    KEY idx_properties_price (price_per_night),
    CONSTRAINT fk_properties_host FOREIGN KEY (host_id) REFERENCES hosts(host_id),
    CONSTRAINT fk_properties_destination FOREIGN KEY (destination_id) REFERENCES destinations(destination_id),
    CONSTRAINT chk_properties_price CHECK (price_per_night > 0),
    CONSTRAINT chk_properties_guests CHECK (max_guests >= 1),
    CONSTRAINT chk_properties_rating CHECK (rating BETWEEN 0 AND 5)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. PROPERTY_IMAGES: photo gallery, ordered by sort_order (0 = cover).
-- ---------------------------------------------------------------------
CREATE TABLE property_images (
    image_id        INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    property_id     VARCHAR(60)      NOT NULL,
    image_url       VARCHAR(500)     NOT NULL,
    caption         VARCHAR(150)     NULL,
    sort_order      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    is_cover        TINYINT(1)       NOT NULL DEFAULT 0,
    PRIMARY KEY (image_id),
    KEY idx_images_property (property_id, sort_order),
    CONSTRAINT fk_images_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. AMENITIES: master list of amenities. The category drives the
--    "Private pool" (category = 'Pool') and "Fast Wi-Fi" (category = 'Internet') filters.
-- ---------------------------------------------------------------------
CREATE TABLE amenities (
    amenity_id      INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    name            VARCHAR(80)      NOT NULL,
    category        VARCHAR(30)      NOT NULL,
    icon            VARCHAR(10)      NULL,
    PRIMARY KEY (amenity_id),
    UNIQUE KEY uq_amenities_name (name),
    KEY idx_amenities_category (category)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. PROPERTY_AMENITIES: many-to-many bridge between properties and amenities.
--    `detail` holds a property-specific description (e.g. "Private heated infinity pool (18m)").
-- ---------------------------------------------------------------------
CREATE TABLE property_amenities (
    property_id     VARCHAR(60)      NOT NULL,
    amenity_id      INT UNSIGNED     NOT NULL,
    detail          VARCHAR(200)     NULL,
    sort_order      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (property_id, amenity_id),
    KEY idx_pa_amenity (amenity_id),
    CONSTRAINT fk_pa_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
    CONSTRAINT fk_pa_amenity  FOREIGN KEY (amenity_id)  REFERENCES amenities(amenity_id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. BOOKINGS: reservations. Overlap rule used by the app:
--    new_check_in < existing_check_out AND new_check_out > existing_check_in
-- ---------------------------------------------------------------------
CREATE TABLE bookings (
    booking_id      INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    ref_code        VARCHAR(12)      NOT NULL,
    user_id         INT UNSIGNED     NOT NULL,
    property_id     VARCHAR(60)      NOT NULL,
    check_in        DATE             NOT NULL,
    check_out       DATE             NOT NULL,
    nights          SMALLINT UNSIGNED NOT NULL,
    guests          TINYINT UNSIGNED NOT NULL,
    stay_cost       DECIMAL(10,2)    NOT NULL,
    cleaning_fee    DECIMAL(10,2)    NOT NULL,
    service_fee     DECIMAL(10,2)    NOT NULL,
    taxes           DECIMAL(10,2)    NOT NULL,
    total_price     DECIMAL(10,2)    NOT NULL,
    host_note       VARCHAR(500)     NULL,
    status          ENUM('Confirmed','Completed','Cancelled') NOT NULL DEFAULT 'Confirmed',
    keyless_pin     VARCHAR(6)       NOT NULL,
    created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelled_at    DATETIME         NULL,
    refund_amount   DECIMAL(10,2)    NULL,
    PRIMARY KEY (booking_id),
    UNIQUE KEY uq_bookings_ref (ref_code),
    KEY idx_bookings_user (user_id),
    KEY idx_bookings_availability (property_id, status, check_in, check_out),
    CONSTRAINT fk_bookings_user     FOREIGN KEY (user_id)     REFERENCES users(user_id),
    CONSTRAINT fk_bookings_property FOREIGN KEY (property_id) REFERENCES properties(property_id),
    CONSTRAINT chk_bookings_dates  CHECK (check_out > check_in),
    CONSTRAINT chk_bookings_guests CHECK (guests >= 1)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 9. PAYMENTS: one simulated payment per booking. Only the last 4 card
--    digits or a masked UPI handle are kept; full card numbers / CVV never are.
-- ---------------------------------------------------------------------
CREATE TABLE payments (
    payment_id      INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    booking_id      INT UNSIGNED     NOT NULL,
    user_id         INT UNSIGNED     NOT NULL,
    method          ENUM('Card (demo)','UPI (demo)') NOT NULL,
    amount          DECIMAL(10,2)    NOT NULL,
    currency        CHAR(3)          NOT NULL DEFAULT 'USD',
    payment_status  ENUM('Paid','Refunded','Partially Refunded') NOT NULL DEFAULT 'Paid',
    transaction_ref VARCHAR(20)      NOT NULL,
    card_last4      CHAR(4)          NULL,
    upi_masked      VARCHAR(60)      NULL,
    paid_at         DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    refunded_amount DECIMAL(10,2)    NOT NULL DEFAULT 0.00,
    refunded_at     DATETIME         NULL,
    PRIMARY KEY (payment_id),
    UNIQUE KEY uq_payments_booking (booking_id),
    UNIQUE KEY uq_payments_txn (transaction_ref),
    KEY idx_payments_user (user_id),
    CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    CONSTRAINT fk_payments_user    FOREIGN KEY (user_id)    REFERENCES users(user_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 10. REVIEWS: guest reviews. booking_id is UNIQUE so one review per booking;
--    it is NULL for legacy reviews imported before the booking system existed.
-- ---------------------------------------------------------------------
CREATE TABLE reviews (
    review_id       INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    property_id     VARCHAR(60)      NOT NULL,
    booking_id      INT UNSIGNED     NULL,
    user_id         INT UNSIGNED     NULL,
    author_name     VARCHAR(100)     NOT NULL,
    author_location VARCHAR(100)     NOT NULL,
    rating          DECIMAL(3,2)     NOT NULL,
    comment         TEXT             NOT NULL,
    review_date     DATE             NOT NULL,
    created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (review_id),
    UNIQUE KEY uq_reviews_booking (booking_id),
    KEY idx_reviews_property (property_id),
    CONSTRAINT fk_reviews_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
    CONSTRAINT fk_reviews_booking  FOREIGN KEY (booking_id)  REFERENCES bookings(booking_id)   ON DELETE SET NULL,
    CONSTRAINT fk_reviews_user     FOREIGN KEY (user_id)     REFERENCES users(user_id)         ON DELETE SET NULL,
    CONSTRAINT chk_reviews_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 11. MESSAGES: guest <-> host chat. Each thread = (user_id, property_id).
-- ---------------------------------------------------------------------
CREATE TABLE messages (
    message_id      INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED     NOT NULL,
    property_id     VARCHAR(60)      NOT NULL,
    sender          ENUM('guest','host','system') NOT NULL,
    text            TEXT             NOT NULL,
    sent_at         DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read         TINYINT(1)       NOT NULL DEFAULT 0,
    PRIMARY KEY (message_id),
    KEY idx_messages_thread (user_id, property_id, message_id),
    CONSTRAINT fk_messages_user     FOREIGN KEY (user_id)     REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_messages_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 12. NOTIFICATIONS: in-app alerts per user.
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    notification_id INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED     NOT NULL,
    kind            ENUM('booking','checkin','message','review','account','host') NOT NULL,
    title           VARCHAR(120)     NOT NULL,
    description     VARCHAR(500)     NOT NULL,
    created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read         TINYINT(1)       NOT NULL DEFAULT 0,
    PRIMARY KEY (notification_id),
    KEY idx_notifications_user (user_id, is_read),
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 13. SAVED_LISTINGS: wishlist / bookmarks per user.
-- ---------------------------------------------------------------------
CREATE TABLE saved_listings (
    user_id         INT UNSIGNED     NOT NULL,
    property_id     VARCHAR(60)      NOT NULL,
    saved_at        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, property_id),
    CONSTRAINT fk_saved_user     FOREIGN KEY (user_id)     REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_saved_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 14. HOST_APPLICATIONS: "Become a Host" form submissions.
-- ---------------------------------------------------------------------
CREATE TABLE host_applications (
    application_id  INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED     NULL,
    full_name       VARCHAR(100)     NOT NULL,
    email           VARCHAR(150)     NOT NULL,
    city            VARCHAR(80)      NOT NULL,
    property_type   VARCHAR(40)      NOT NULL,
    message         TEXT             NOT NULL,
    status          ENUM('Submitted','Under Review','Approved','Rejected') NOT NULL DEFAULT 'Submitted',
    submitted_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (application_id),
    KEY idx_host_app_status (status),
    CONSTRAINT fk_host_app_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 15. USER_SESSIONS: one row per successful login (login history).
-- ---------------------------------------------------------------------
CREATE TABLE user_sessions (
    session_id       INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    user_id          INT UNSIGNED    NOT NULL,
    session_token    CHAR(32)        NOT NULL,
    login_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_activity_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    logout_at        DATETIME        NULL,
    user_agent       VARCHAR(300)    NULL,
    is_active        TINYINT(1)      NOT NULL DEFAULT 1,
    PRIMARY KEY (session_id),
    UNIQUE KEY uq_sessions_token (session_token),
    KEY idx_sessions_user (user_id, login_at),
    CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 16. ACTIVITY_LOGS: audit trail of EVERY user action (register, login,
--     failed login, logout, page views, searches, bookings, payments,
--     messages, reviews, cancellations, profile changes ...).
--     user_id is NULL for failed logins with an unknown email.
-- ---------------------------------------------------------------------
CREATE TABLE activity_logs (
    log_id          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED     NULL,
    session_id      INT UNSIGNED     NULL,
    activity_type   VARCHAR(40)      NOT NULL,
    entity_type     VARCHAR(30)      NULL,
    entity_id       VARCHAR(60)      NULL,
    description     VARCHAR(500)     NOT NULL,
    details         JSON             NULL,
    status          ENUM('SUCCESS','FAILED') NOT NULL DEFAULT 'SUCCESS',
    created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (log_id),
    KEY idx_logs_user_time (user_id, created_at),
    KEY idx_logs_type (activity_type),
    KEY idx_logs_time (created_at),
    CONSTRAINT fk_logs_user    FOREIGN KEY (user_id)    REFERENCES users(user_id)            ON DELETE SET NULL,
    CONSTRAINT fk_logs_session FOREIGN KEY (session_id) REFERENCES user_sessions(session_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Done. Next: run 02_seed_data.sql (or 03_load_csv.sql) to insert the sample rows,
-- then 04_views_and_reports.sql for handy views.
