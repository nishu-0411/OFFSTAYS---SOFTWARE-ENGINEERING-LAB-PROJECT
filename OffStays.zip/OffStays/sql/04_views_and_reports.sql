-- =====================================================================
-- OFFSTAYS · 04_views_and_reports.sql
-- Handy views + report queries to explore the data in MySQL Workbench.
-- Run after 01_schema.sql and 02_seed_data.sql.
-- =====================================================================
USE offstays;

-- ---------------------------------------------------------------------
-- VIEW 1: Every booking with guest, property, host and payment details.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_booking_details AS
SELECT b.booking_id, b.ref_code, b.status,
       u.user_id, u.full_name AS guest_name, u.email AS guest_email,
       p.property_id, p.title AS property_title, d.name AS destination, p.area,
       h.display_name AS host_name,
       b.check_in, b.check_out, b.nights, b.guests,
       b.total_price, pay.method AS payment_method, pay.payment_status,
       pay.refunded_amount, b.created_at
FROM bookings b
JOIN users u        ON u.user_id = b.user_id
JOIN properties p   ON p.property_id = b.property_id
JOIN destinations d ON d.destination_id = p.destination_id
JOIN hosts h        ON h.host_id = p.host_id
LEFT JOIN payments pay ON pay.booking_id = b.booking_id;

-- ---------------------------------------------------------------------
-- VIEW 2: Property summary with host, amenity count, bookings and revenue.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_property_summary AS
SELECT p.property_id, p.title, d.name AS destination, d.country, p.area, p.category, p.price_per_night,
       p.rating, p.review_count, h.display_name AS host_name, h.is_superhost,
       (SELECT COUNT(*) FROM property_amenities pa WHERE pa.property_id = p.property_id) AS amenity_count,
       (SELECT COUNT(*) FROM bookings b WHERE b.property_id = p.property_id AND b.status <> 'Cancelled') AS total_bookings,
       (SELECT COALESCE(SUM(b.total_price), 0) FROM bookings b WHERE b.property_id = p.property_id AND b.status <> 'Cancelled') AS gross_revenue
FROM properties p
JOIN destinations d ON d.destination_id = p.destination_id
JOIN hosts h ON h.host_id = p.host_id;

-- ---------------------------------------------------------------------
-- VIEW 5: Destination overview (properties, price range, bookings, revenue).
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_destination_summary AS
SELECT d.destination_id, d.name AS destination, d.country, d.continent,
       COUNT(DISTINCT p.property_id) AS properties,
       COUNT(DISTINCT p.area)        AS areas,
       MIN(p.price_per_night)        AS min_price,
       MAX(p.price_per_night)        AS max_price,
       ROUND(AVG(p.rating), 2)       AS avg_rating,
       (SELECT COUNT(*) FROM bookings b JOIN properties p2 ON p2.property_id = b.property_id
         WHERE p2.destination_id = d.destination_id AND b.status <> 'Cancelled') AS bookings,
       (SELECT COALESCE(SUM(b.total_price), 0) FROM bookings b JOIN properties p2 ON p2.property_id = b.property_id
         WHERE p2.destination_id = d.destination_id AND b.status <> 'Cancelled') AS revenue_usd
FROM destinations d
LEFT JOIN properties p ON p.destination_id = d.destination_id
GROUP BY d.destination_id, d.name, d.country, d.continent;

-- ---------------------------------------------------------------------
-- VIEW 3: Per-user activity summary (logins, failed logins, bookings ...).
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_user_activity_summary AS
SELECT u.user_id, u.full_name, u.email, u.role, u.created_at, u.last_login_at,
       SUM(l.activity_type = 'LOGIN')            AS logins,
       SUM(l.activity_type = 'LOGIN_FAILED')     AS failed_logins,
       SUM(l.activity_type = 'BOOKING_CREATED')  AS bookings_made,
       SUM(l.activity_type = 'BOOKING_CANCELLED') AS cancellations,
       SUM(l.activity_type = 'MESSAGE_SENT')     AS messages_sent,
       COUNT(l.log_id)                           AS total_actions,
       MAX(l.created_at)                         AS last_activity
FROM users u
LEFT JOIN activity_logs l ON l.user_id = u.user_id
GROUP BY u.user_id, u.full_name, u.email, u.role, u.created_at, u.last_login_at;

-- ---------------------------------------------------------------------
-- VIEW 4: Readable activity feed (latest first) joined to user names.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_activity_feed AS
SELECT l.log_id, l.created_at, l.activity_type, l.status,
       COALESCE(u.full_name, '(unknown user)') AS user_name, u.email,
       l.entity_type, l.entity_id, l.description, l.details, l.session_id
FROM activity_logs l
LEFT JOIN users u ON u.user_id = l.user_id;

-- =====================================================================
-- REPORT QUERIES (select one and press Ctrl+Enter in Workbench)
-- =====================================================================

-- R1. Latest 50 activities across the whole platform
SELECT * FROM vw_activity_feed ORDER BY log_id DESC LIMIT 50;

-- R2. All register / login / logout / failed-login events
SELECT * FROM vw_activity_feed
WHERE activity_type IN ('REGISTER', 'LOGIN', 'LOGOUT', 'LOGIN_FAILED', 'LOGIN_BLOCKED')
ORDER BY log_id DESC;

-- R3. Activity count by type
SELECT activity_type, COUNT(*) AS total FROM activity_logs GROUP BY activity_type ORDER BY total DESC;

-- R4. Destinations ranked by revenue (cancelled excluded)
SELECT * FROM vw_destination_summary ORDER BY revenue_usd DESC;

-- R4b. Revenue by destination and area
SELECT d.name AS destination, p.area, COUNT(*) AS bookings, SUM(b.total_price) AS revenue_usd
FROM bookings b
JOIN properties p   ON p.property_id = b.property_id
JOIN destinations d ON d.destination_id = p.destination_id
WHERE b.status <> 'Cancelled'
GROUP BY d.name, p.area ORDER BY destination, revenue_usd DESC;

-- R4c. Properties per country
SELECT d.country, COUNT(p.property_id) AS properties
FROM destinations d LEFT JOIN properties p ON p.destination_id = d.destination_id
GROUP BY d.country ORDER BY properties DESC;

-- R5. Top 10 properties by revenue
SELECT * FROM vw_property_summary ORDER BY gross_revenue DESC LIMIT 10;

-- R6. Properties that have a pool AND fast internet
SELECT p.property_id, p.title
FROM properties p
WHERE EXISTS (SELECT 1 FROM property_amenities pa JOIN amenities a ON a.amenity_id = pa.amenity_id
              WHERE pa.property_id = p.property_id AND a.category = 'Pool')
  AND EXISTS (SELECT 1 FROM property_amenities pa JOIN amenities a ON a.amenity_id = pa.amenity_id
              WHERE pa.property_id = p.property_id AND a.category = 'Internet');

-- R7. Most popular amenities
SELECT a.name, a.category, COUNT(*) AS properties_with_it
FROM property_amenities pa JOIN amenities a ON a.amenity_id = pa.amenity_id
GROUP BY a.amenity_id, a.name, a.category ORDER BY properties_with_it DESC LIMIT 15;

-- R8. Login history for one user (change the email)
SELECT s.session_id, s.login_at, s.logout_at,
       TIMESTAMPDIFF(MINUTE, s.login_at, COALESCE(s.logout_at, s.last_activity_at)) AS minutes_active
FROM user_sessions s JOIN users u ON u.user_id = s.user_id
WHERE u.email = 'sarah.vance@example.com'
ORDER BY s.login_at DESC;

-- R9. Is a property free for given dates? (0 = available)
SELECT COUNT(*) AS clashing_bookings
FROM bookings
WHERE property_id = 'villa-paradiso' AND status = 'Confirmed'
  AND check_in < '2026-12-20' AND check_out > '2026-12-17';

-- R10. Users with repeated failed logins in the last 30 days
SELECT JSON_UNQUOTE(JSON_EXTRACT(details, '$.email')) AS email_tried, COUNT(*) AS failures
FROM activity_logs
WHERE activity_type = 'LOGIN_FAILED' AND created_at >= NOW() - INTERVAL 30 DAY
GROUP BY email_tried ORDER BY failures DESC;
