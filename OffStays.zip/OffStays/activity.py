# activity.py: User Activity Tracking and Navigation Helper.
#
# WHAT THIS FILE DOES:
#   This module provides high-level helper functions for two key tasks:
#     1. Recording user actions (such as viewing a stay, searching, or saving a bookmark)
#        into the MySQL `activity_logs` audit table.
#     2. Managing seamless page-to-page navigation across our Streamlit application.
#
# WHY THIS STEP IS NECESSARY:
#   Enterprise booking systems require a reliable audit trail for compliance, security
#   investigations (like tracking failed logins), and analytics. Centralizing navigation
#   and event logging here keeps the individual page files uncluttered and prevents
#   duplicated logging code.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - It reads user identity and active session tokens from Streamlit's `st.session_state`.
#   - It delegates write operations to `database.log_activity()` and `database.touch_session()`.
#   - When a user clicks navigation buttons or property cards, this module handles the state
#     updates and initiates `st.rerun()` so the new screen renders immediately.

import streamlit as st  # Accesses Streamlit session state (current user, active session, active page).
import database  # Provides the underlying MySQL query functions: log_activity() and touch_session().

# Human-readable dictionary mapping internal page keys to clean display titles.
# Used when generating descriptive log entries (e.g., logging "Opened Explore Stays" instead of "explore").
PAGE_NAMES = {
    "explore": "Explore Stays",
    "details": "Property Details",
    "checkout": "Checkout",
    "messages": "Messages",
    "trips": "My Trips",
    "host": "Become a Host",
    "profile": "My Profile",
    "admin": "Admin Dashboard",
}


def log_event(activity_type, description, entity_type=None, entity_id=None, details=None, status="SUCCESS"):
    # WHAT: Writes an entry into the MySQL `activity_logs` table for the currently logged-in user.
    # WHY:  Maintains full accountability for actions such as PAGE_VIEW, SEARCH, VIEW_PROPERTY, and BOOKING_CREATED.
    # HOW:  It grabs the active user and session ID from Streamlit memory and forwards them to database.py.
    
    # Retrieve the active user dictionary from session memory.
    user = st.session_state.get("user")
    
    # If no visitor is logged in (e.g., before authentication), we silently exit.
    # This prevents unauthenticated browsing noise from polluting our user audit table.
    if not user:
        return
        
    try:
        # Pass user ID, event type, human description, affected entity, and session token to MySQL.
        database.log_activity(
            user["user_id"],
            activity_type,
            description,
            entity_type,
            entity_id,
            details,
            status,
            st.session_state.get("session_id")
        )
    except Exception as e:
        # FAIL-SAFE MECHANISM:
        # Logging is a secondary background concern. An audit logging failure must NEVER crash
        # the user's booking workflow or display an unhandled error screen to the customer.
        # We catch the exception and log it to the server console for administrative inspection.
        print(f"[activity] could not log {activity_type}: {e}")


def go_to(page):
    # WHAT: Transitions the application to a new page view.
    # WHY:  Streamlit is a single-page app framework. Changing screens requires updating
    #       `st.session_state["current_page"]` and asking Streamlit to re-execute from top to bottom.
    # HOW:  Logs a PAGE_VIEW event, refreshes the active session's last activity timestamp in MySQL,
    #       updates the current page key, and calls `st.rerun()`.
    
    # Only record a PAGE_VIEW event if the user is genuinely navigating to a different page.
    if st.session_state.get("current_page") != page:
        log_event("PAGE_VIEW", f"Opened {PAGE_NAMES.get(page, page)}", "page", page)
        
    # Keep the user's MySQL session active by updating `last_activity_at` with the current time.
    database.touch_session(st.session_state.get("session_id"))
    
    # Update the routing key in session memory and trigger an immediate script rerun.
    st.session_state["current_page"] = page
    st.rerun()


def open_property(listing_id, source):
    # WHAT: Opens the detailed property view for a specific luxury sanctuary.
    # WHY:  When a user clicks "View details" from Explore or their Wishlist, the application
    #       needs to know which property ID was selected, reset photo gallery indexes, and log the action.
    # HOW:  Stores the property ID in session state, resets the photo carousel index to 0,
    #       closes any open share dialog, records the VIEW_PROPERTY audit event, and routes to "details".
    
    # Set the selected property ID so page_details.py knows which stay to fetch from MySQL.
    st.session_state["selected_listing_id"] = listing_id
    
    # Always reset the image carousel index back to the first photo (index 0).
    st.session_state["details_photo_index"] = 0
    
    # Ensure the copyable share link box starts closed.
    st.session_state["show_share_modal"] = False
    
    # Log that this property was viewed, capturing the source page (e.g. "explore" or "saved").
    log_event("VIEW_PROPERTY", f"Viewed property {listing_id}", "property", listing_id, {"source": source})
    
    # Update the session's active timestamp in the database.
    database.touch_session(st.session_state.get("session_id"))
    
    # Switch the active screen to the details page and re-render.
    st.session_state["current_page"] = "details"
    st.rerun()
