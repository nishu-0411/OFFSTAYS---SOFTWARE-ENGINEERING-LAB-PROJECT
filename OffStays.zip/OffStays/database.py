# database.py: Central MySQL Data Access Layer & Business Logic Queries.
#
# WHAT THIS FILE DOES:
#   This module serves as the primary bridge between our Python frontend and the MySQL 8
#   relational database. It manages connection pooling, executes parameterized SQL queries,
#   converts MySQL data types into clean Python formats, and coordinates atomic multi-table
#   transactions (such as booking creation, payment simulation, and review submissions).
#
# WHY THIS STEP IS NECESSARY:
#   1. SQL INJECTION IMMUNITY:
#      Every query uses parameterized placeholders (%s). PyMySQL sends the query text
#      and parameter values separately to the MySQL engine, making SQL injection impossible.
#   2. CONCURRENCY & RACE-CONDITION PROTECTION:
#      During booking creation, it executes `SELECT ... FOR UPDATE` inside a transaction.
#      This row-level lock prevents two users from booking the same sanctuary on overlapping dates.
#   3. DATA PRIVACY & ISOLATION:
#      All queries for bookings, messages, reviews, and notifications filter strictly by `user_id`.
#      A guest can never inspect another guest's messages or keyless door lock PINs.

import datetime  # Handles timestamps, date range comparisons, and booking availability.
import decimal  # MySQL DECIMAL columns arrive as decimal.Decimal; we sanitize them into int/float.
import json  # Serializes structured audit details into MySQL's native JSON columns.
import random  # Generates realistic booking reference codes (#OFS-XXXXX) and door PINs.

import pymysql  # Pure-Python MySQL client driver.
import pymysql.cursors  # DictCursor returns database rows as Python dictionaries (row["title"]).

import db_config  # Imports host, port, user, password, and database name from configuration.


# =====================================================================
# CONNECTION & SANITIZATION HELPERS
# =====================================================================

def get_connection():
    # WHAT: Opens and returns an active connection to the MySQL database.
    # WHY:  Every database operation requires a connection. We set `autocommit=False`
    #       so we have full control over transaction commits and rollbacks.
    # HOW:  Uses PyMySQL with DictCursor so column values can be accessed by name.
    return pymysql.connect(
        host=db_config.DB_HOST,
        port=db_config.DB_PORT,
        user=db_config.DB_USER,
        password=db_config.DB_PASSWORD,
        database=db_config.DB_NAME,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
        connect_timeout=5,
    )


def _now():
    # Helper returning current local time rounded to the nearest second (matches MySQL DATETIME).
    return datetime.datetime.now().replace(microsecond=0)


def _clean_value(value):
    # WHAT: Converts MySQL-specific data types into standard Python types for Streamlit.
    # WHY:  MySQL returns DECIMAL(10,2) as decimal.Decimal('185.00'). If not converted,
    #       UI cards might display awkward formatting. We convert whole decimals to int (185)
    #       and fractional decimals to float (4.98), while converting dates to ISO strings.
    if isinstance(value, decimal.Decimal):
        if value == value.to_integral_value():
            return int(value)
        return float(value)
    if isinstance(value, datetime.datetime):
        return value.isoformat(timespec="seconds")  # E.g. "2026-10-27T09:15:00"
    if isinstance(value, datetime.date):
        return value.isoformat()  # E.g. "2026-10-27"
    return value


def _clean_row(row):
    # Cleans all fields in a single dictionary row returned from fetchone().
    if row is None:
        return None
    cleaned = {}
    for key, value in row.items():
        cleaned[key] = _clean_value(value)
    return cleaned


def _clean_rows(rows):
    # Cleans a list of dictionary rows returned from fetchall().
    result = []
    for row in rows:
        result.append(_clean_row(row))
    return result


def fetch_all(query, params=()):
    # WHAT: Executes a parameterized SELECT query and returns all matching rows as cleaned dicts.
    # HOW:  Opens a connection, executes with cursor, fetches all, cleans values, and closes connection.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            return _clean_rows(cursor.fetchall())
    finally:
        conn.close()


def fetch_one(query, params=()):
    # WHAT: Executes a parameterized SELECT query and returns the first matching row (or None).
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            return _clean_row(cursor.fetchone())
    finally:
        conn.close()


def execute(query, params=()):
    # WHAT: Executes an INSERT, UPDATE, or DELETE query and commits the transaction.
    # RETURNS: The newly created AUTO_INCREMENT ID (`cursor.lastrowid`).
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            new_id = cursor.lastrowid
        conn.commit()
        return new_id
    except Exception:
        conn.rollback()  # Rollback on error to ensure database remains in a consistent state.
        raise
    finally:
        conn.close()


def check_database_ready():
    # WHAT: Verifies that MySQL Server is running and our tables/seed data have been loaded.
    # WHY:  Called at application boot time in app.py to present friendly setup instructions
    #       instead of crashing with an unhandled exception.
    # HOW:  Attempts to count rows in `properties`. Catches specific MySQL error codes.
    try:
        row = fetch_one("SELECT COUNT(*) AS n FROM properties")
        if row["n"] == 0:
            return False, "The `properties` table is empty. Run sql/02_seed_data.sql in MySQL Workbench."
        return True, ""
    except pymysql.err.OperationalError as e:
        code = e.args[0]
        if code == 1045:
            return False, "MySQL rejected the username/password. Open db_config.py and set DB_PASSWORD to your MySQL root password."
        if code == 1049:
            return False, "Database `offstays` does not exist yet. Run sql/01_schema.sql and sql/02_seed_data.sql in MySQL Workbench."
        if code in (2003, 2013):
            return False, f"Cannot reach MySQL server on {db_config.DB_HOST}:{db_config.DB_PORT}. Make sure the MySQL service is running."
        return False, f"MySQL error {code}: {e.args[1] if len(e.args) > 1 else e}"
    except pymysql.err.ProgrammingError as e:
        if e.args[0] == 1146:
            return False, "Tables are missing. Run sql/01_schema.sql and sql/02_seed_data.sql in MySQL Workbench."
        return False, f"MySQL error: {e}"


# =====================================================================
# ACTIVITY AUDIT LOGGING
# =====================================================================

def log_activity(user_id, activity_type, description, entity_type=None, entity_id=None,
                 details=None, status="SUCCESS", session_id=None, cursor=None):
    # WHAT: Inserts a detailed audit trail record into the MySQL `activity_logs` table.
    # HOW:  Accepts an optional `cursor` parameter. If passed, this insert becomes part
    #       of an ongoing atomic transaction (such as a booking or cancellation).
    details_json = json.dumps(details, default=str) if details else None
    query = """
        INSERT INTO activity_logs
            (user_id, session_id, activity_type, entity_type, entity_id, description, details, status, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    params = (
        user_id, session_id, activity_type, entity_type,
        None if entity_id is None else str(entity_id),
        description[:500], details_json, status, _now()
    )
    if cursor is not None:
        cursor.execute(query, params)
    else:
        execute(query, params)


def count_recent_failed_logins(email, minutes):
    # WHAT: Counts failed login attempts recorded for an email in the last N minutes.
    # WHY:  Used in `auth.login_user()` to enforce temporary brute-force account lockout.
    # HOW:  Uses MySQL's native JSON_EXTRACT to check the email inside the `details` JSON column.
    cutoff = _now() - datetime.timedelta(minutes=minutes)
    row = fetch_one("""
        SELECT COUNT(*) AS n FROM activity_logs
        WHERE activity_type = 'LOGIN_FAILED'
          AND JSON_UNQUOTE(JSON_EXTRACT(details, '$.email')) = %s
          AND created_at >= %s
    """, (email, cutoff))
    return row["n"]


def get_user_activity(user_id, limit=100):
    # Returns recent activity logs for a specific user to display on their Profile screen.
    return fetch_all("""
        SELECT log_id, created_at, activity_type, description, status, entity_type, entity_id
        FROM activity_logs WHERE user_id = %s ORDER BY log_id DESC LIMIT %s
    """, (user_id, limit))


def get_activity_logs(activity_type=None, search_text=None, limit=300):
    # WHAT: Queries the global activity log for the Admin Dashboard.
    # WHY:  Allows platform administrators to audit security events and user interactions.
    query = """
        SELECT l.log_id, l.created_at, l.activity_type, l.status,
               COALESCE(u.full_name, '(unknown)') AS user_name, u.email,
               l.description, l.entity_type, l.entity_id, l.details, l.session_id
        FROM activity_logs l
        LEFT JOIN users u ON u.user_id = l.user_id
        WHERE 1 = 1
    """
    params = []
    if activity_type:
        query += " AND l.activity_type = %s"
        params.append(activity_type)
    if search_text:
        query += " AND (u.full_name LIKE %s OR u.email LIKE %s OR l.details LIKE %s)"
        like = f"%{search_text}%"
        params += [like, like, like]
    query += " ORDER BY l.log_id DESC LIMIT %s"
    params.append(limit)
    return fetch_all(query, tuple(params))


def get_activity_types():
    # Returns all distinct activity types currently recorded in MySQL for filter dropdowns.
    rows = fetch_all("SELECT DISTINCT activity_type FROM activity_logs ORDER BY activity_type")
    return [r["activity_type"] for r in rows]


# =====================================================================
# USERS, SESSIONS & CREDENTIALS
# =====================================================================

def get_user_by_email(email):
    # Finds a user record by email address (used during login and registration checks).
    return fetch_one("SELECT * FROM users WHERE email = %s", (email,))


def get_user_by_id(user_id):
    # Finds a user record by primary key ID.
    return fetch_one("SELECT * FROM users WHERE user_id = %s", (user_id,))


def create_user(full_name, email, phone, password_hash, password_salt, city, country):
    # WHAT: Inserts a new user record, generates a welcome notification, and logs registration.
    # HOW:  Executes inside a single database transaction so no partial accounts can ever be created.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            now = _now()
            # Generate a clean avatar using the ui-avatars service
            avatar = "https://ui-avatars.com/api/?name=" + full_name.replace(" ", "+") + "&background=E0565C&color=fff&size=200"
            cursor.execute("""
                INSERT INTO users (full_name, email, phone, password_hash, password_salt, role, city, country, avatar_url, created_at)
                VALUES (%s, %s, %s, %s, %s, 'guest', %s, %s, %s, %s)
            """, (full_name, email, phone or None, password_hash, password_salt, city or None, country or None, avatar, now))
            user_id = cursor.lastrowid
            
            # Create a welcome notification
            cursor.execute("""
                INSERT INTO notifications (user_id, kind, title, description, created_at, is_read)
                VALUES (%s, 'account', 'Welcome to OFFSTAYS', %s, %s, 0)
            """, (user_id, f"Hi {full_name.split()[0]}, your account is ready. Start exploring hand-picked stays across our destinations.", now))
            
            # Log the registration event
            log_activity(user_id, "REGISTER", "New account registered", "user", user_id,
                         {"email": email, "role": "guest"}, cursor=cursor)
        conn.commit()
        return user_id
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def start_session(user_id, token, user_agent):
    # WHAT: Creates a new login row in `user_sessions` and updates the user's `last_login_at` timestamp.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            now = _now()
            cursor.execute("""
                INSERT INTO user_sessions (user_id, session_token, login_at, last_activity_at, user_agent, is_active)
                VALUES (%s, %s, %s, %s, %s, 1)
            """, (user_id, token, now, now, (user_agent or "")[:300] or None))
            session_id = cursor.lastrowid
            cursor.execute("UPDATE users SET last_login_at = %s WHERE user_id = %s", (now, user_id))
            log_activity(user_id, "LOGIN", "User logged in successfully", "user", user_id,
                         {"session_token": token[:8] + "..."}, session_id=session_id, cursor=cursor)
        conn.commit()
        return session_id
    finally:
        conn.close()


def end_session(user_id, session_id):
    # WHAT: Marks a session as inactive upon logout and logs the event.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            now = _now()
            cursor.execute("""
                UPDATE user_sessions SET logout_at = %s, last_activity_at = %s, is_active = 0
                WHERE session_id = %s AND user_id = %s
            """, (now, now, session_id, user_id))
            log_activity(user_id, "LOGOUT", "User logged out", "user", user_id, session_id=session_id, cursor=cursor)
        conn.commit()
    finally:
        conn.close()


def touch_session(session_id):
    # WHAT: Updates `last_activity_at` on the active session row to track how long a user stays active.
    if session_id:
        execute("UPDATE user_sessions SET last_activity_at = %s WHERE session_id = %s", (_now(), session_id))


def get_user_sessions(user_id, limit=30):
    # Returns the login history for the logged-in user to show in the Profile history tab.
    return fetch_all("""
        SELECT session_id, login_at, last_activity_at, logout_at, is_active, user_agent
        FROM user_sessions WHERE user_id = %s ORDER BY session_id DESC LIMIT %s
    """, (user_id, limit))


def update_profile(user_id, full_name, phone, city, country):
    # Updates profile details in the `users` table.
    execute("UPDATE users SET full_name = %s, phone = %s, city = %s, country = %s WHERE user_id = %s",
            (full_name, phone or None, city or None, country or None, user_id))


def update_password(user_id, password_hash, password_salt):
    # Updates password hash and salt for a user.
    execute("UPDATE users SET password_hash = %s, password_salt = %s WHERE user_id = %s",
            (password_hash, password_salt, user_id))


def get_all_users():
    # Returns all registered accounts for the Admin Dashboard user directory.
    return fetch_all("""
        SELECT user_id, full_name, email, role, city, country, is_active, created_at, last_login_at
        FROM users ORDER BY user_id
    """)


# =====================================================================
# PROPERTIES, DESTINATIONS & AMENITIES
# =====================================================================

# Comprehensive SELECT query joining properties, hosts, destinations, and amenities.
# Returns computed boolean columns `has_pool` and `has_wifi` for fast Explore filtering.
LISTING_SELECT = """
    SELECT p.property_id AS id, p.*,
           h.display_name  AS host_name,
           h.avatar_url    AS host_avatar_url,
           h.is_superhost  AS host_superhost,
           h.response_rate AS host_response_rate,
           h.response_time AS host_response_time,
           hu.phone        AS host_phone,
           d.name          AS destination,
           d.country       AS country,
           d.description   AS destination_description,
           d.nearest_airport,
           d.best_season,
           d.map_zoom      AS destination_zoom,
           EXISTS (SELECT 1 FROM property_amenities pa JOIN amenities a ON a.amenity_id = pa.amenity_id
                   WHERE pa.property_id = p.property_id AND a.category = 'Pool')     AS has_pool,
           EXISTS (SELECT 1 FROM property_amenities pa JOIN amenities a ON a.amenity_id = pa.amenity_id
                   WHERE pa.property_id = p.property_id AND a.category = 'Internet') AS has_wifi
    FROM properties p
    JOIN hosts h        ON h.host_id = p.host_id
    JOIN users hu       ON hu.user_id = h.user_id
    JOIN destinations d ON d.destination_id = p.destination_id
"""


def _attach_media(listings):
    # WHAT: Attaches photo gallery URLs and amenity strings to listing dictionaries.
    # WHY:  Properties have 1-to-many images and many-to-many amenities. Instead of running
    #       hundreds of individual queries in a loop, we batch-fetch them using `IN (...)`
    #       and attach them as pipe-separated strings ("url1|url2|url3").
    if not listings:
        return listings
    ids = [l["id"] for l in listings]
    placeholders = ",".join(["%s"] * len(ids))
    
    # Query all images belonging to the fetched properties, ordered by sort_order
    image_rows = fetch_all(f"""
        SELECT property_id, image_url FROM property_images
        WHERE property_id IN ({placeholders}) ORDER BY property_id, sort_order
    """, tuple(ids))
    
    # Query all amenities belonging to the fetched properties
    amenity_rows = fetch_all(f"""
        SELECT pa.property_id, COALESCE(pa.detail, a.name) AS label
        FROM property_amenities pa JOIN amenities a ON a.amenity_id = pa.amenity_id
        WHERE pa.property_id IN ({placeholders}) ORDER BY pa.property_id, pa.sort_order
    """, tuple(ids))
    
    # Group images and amenities by property_id
    images = {}
    for r in image_rows:
        images.setdefault(r["property_id"], []).append(r["image_url"])
    amenities = {}
    for r in amenity_rows:
        amenities.setdefault(r["property_id"], []).append(r["label"])
        
    for l in listings:
        l["image_urls"] = "|".join(images.get(l["id"], [])) or "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80"
        l["amenities"] = "|".join(amenities.get(l["id"], []))
    return listings


def get_all_listings():
    # Fetches all active luxury properties with attached images and amenities.
    return _attach_media(fetch_all(LISTING_SELECT + " WHERE p.is_active = 1 ORDER BY p.rating DESC"))


def get_listing_by_id(listing_id):
    # Fetches full details for a single property by its slug ID (e.g. 'villa-paradiso').
    rows = _attach_media(fetch_all(LISTING_SELECT + " WHERE p.property_id = %s", (listing_id,)))
    return rows[0] if rows else None


def get_distinct_categories():
    # Returns distinct category names (Amazing pools, Luxury Villas, Eco Cabins, etc.).
    rows = fetch_all("SELECT DISTINCT category FROM properties WHERE is_active = 1 ORDER BY category")
    return [r["category"] for r in rows]


def get_destinations():
    # Returns active destinations along with their live property counts.
    return fetch_all("""
        SELECT d.destination_id, d.name, d.country, d.continent, d.description, d.latitude, d.longitude,
               d.map_zoom, d.nearest_airport, d.best_season, COUNT(p.property_id) AS property_count
        FROM destinations d
        JOIN properties p ON p.destination_id = d.destination_id AND p.is_active = 1
        WHERE d.is_active = 1
        GROUP BY d.destination_id, d.name, d.country, d.continent, d.description, d.latitude, d.longitude,
                 d.map_zoom, d.nearest_airport, d.best_season
        ORDER BY d.name
    """)


def get_areas(destination_name):
    # Returns distinct towns/neighbourhoods inside a selected destination (e.g., Anjuna in Goa).
    rows = fetch_all("""
        SELECT DISTINCT p.area FROM properties p JOIN destinations d ON d.destination_id = p.destination_id
        WHERE d.name = %s AND p.is_active = 1 ORDER BY p.area
    """, (destination_name,))
    return [r["area"] for r in rows]


def get_price_bounds():
    # Queries the lowest and highest price per night across all active listings to calibrate the UI slider.
    row = fetch_one("SELECT MIN(price_per_night) AS lo, MAX(price_per_night) AS hi FROM properties WHERE is_active = 1")
    return int(row["lo"] or 50), int(row["hi"] or 400)


# =====================================================================
# AVAILABILITY & DOUBLE-BOOKING PREVENTION
# =====================================================================

def get_unavailable_listing_ids(check_in_str, check_out_str):
    # WHAT: Finds all property IDs that have an overlapping confirmed booking.
    # WHY:  Overlapping listings are filtered out immediately on the Explore search page.
    # OVERLAP FORMULA:
    #   existing.check_in < new_check_out AND existing.check_out > new_check_in
    rows = fetch_all("""
        SELECT DISTINCT property_id FROM bookings
        WHERE status = 'Confirmed' AND check_in < %s AND check_out > %s
    """, (check_out_str, check_in_str))
    return {r["property_id"] for r in rows}


def is_listing_available(listing_id, check_in_str, check_out_str):
    # Checks if a single property is free for a given date range.
    row = fetch_one("""
        SELECT COUNT(*) AS n FROM bookings
        WHERE property_id = %s AND status = 'Confirmed' AND check_in < %s AND check_out > %s
    """, (listing_id, check_out_str, check_in_str))
    return row["n"] == 0


# =====================================================================
# WISHLIST (SAVED LISTINGS)
# =====================================================================

def get_saved_listing_ids(user_id):
    # Returns property IDs bookmarked by the user.
    rows = fetch_all("SELECT property_id FROM saved_listings WHERE user_id = %s ORDER BY saved_at DESC", (user_id,))
    return [r["property_id"] for r in rows]


def toggle_saved_listing(user_id, listing_id):
    # WHAT: Toggles a property bookmark (inserts if absent, removes if present).
    # RETURNS: True if the stay is now saved, False if it was removed.
    exists = fetch_one("SELECT 1 AS x FROM saved_listings WHERE user_id = %s AND property_id = %s", (user_id, listing_id))
    if exists:
        execute("DELETE FROM saved_listings WHERE user_id = %s AND property_id = %s", (user_id, listing_id))
        return False
    execute("INSERT INTO saved_listings (user_id, property_id, saved_at) VALUES (%s, %s, %s)", (user_id, listing_id, _now()))
    return True


# =====================================================================
# REVIEWS & RUNNING AVERAGE RATING
# =====================================================================

def get_listing_reviews(listing_id):
    # Fetches reviews for a property, formatted with clean dates like 'August 2026'.
    rows = fetch_all("SELECT * FROM reviews WHERE property_id = %s ORDER BY review_date DESC, review_id DESC", (listing_id,))
    for r in rows:
        r["author"] = r["author_name"]
        r["location"] = r["author_location"]
        r["review_date"] = datetime.date.fromisoformat(r["review_date"]).strftime("%B %Y")
    return rows


def has_reviewed_booking(booking_id):
    # Checks if a review has already been written for this specific booking.
    return fetch_one("SELECT review_id FROM reviews WHERE booking_id = %s", (booking_id,)) is not None


def add_review(user_id, session_id, listing_id, booking_id, author, location, rating, comment):
    # WHAT: Saves a guest review and atomically updates the property's cached rating.
    # RUNNING AVERAGE FORMULA:
    #   new_rating = (old_rating * old_count + new_score) / (old_count + 1)
    # WHY:  Properties retain historic review counts (e.g. 142 reviews) instead of resetting.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            # Verify the booking belongs to this user and is Completed
            cursor.execute("SELECT user_id, status FROM bookings WHERE booking_id = %s", (booking_id,))
            booking = cursor.fetchone()
            if not booking or booking["user_id"] != user_id or booking["status"] != "Completed":
                return False, "You can only review your own completed stays."
                
            now = _now()
            cursor.execute("""
                INSERT INTO reviews (property_id, booking_id, user_id, author_name, author_location, rating, comment, review_date, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (listing_id, booking_id, user_id, author, location, rating, comment, now.date(), now))
            review_id = cursor.lastrowid
            
            # Lock the property row to safely compute the running average
            cursor.execute("SELECT rating, review_count FROM properties WHERE property_id = %s FOR UPDATE", (listing_id,))
            prop = cursor.fetchone()
            old_count = int(prop["review_count"])
            new_rating = round((float(prop["rating"]) * old_count + float(rating)) / (old_count + 1), 2)
            
            cursor.execute("UPDATE properties SET rating = %s, review_count = %s WHERE property_id = %s",
                           (new_rating, old_count + 1, listing_id))
                           
            log_activity(user_id, "REVIEW_SUBMITTED", f"Reviewed property {listing_id}", "review", review_id,
                         {"rating": rating, "booking_id": booking_id, "new_property_rating": new_rating},
                         session_id=session_id, cursor=cursor)
        conn.commit()
        return True, "Thank you! Your review has been published."
    except pymysql.err.IntegrityError:
        conn.rollback()
        return False, "A review for this booking already exists."
    finally:
        conn.close()


# =====================================================================
# ATOMIC BOOKING & PAYMENT TRANSACTIONS
# =====================================================================

def update_completed_bookings():
    # Automatically transitions Confirmed bookings to 'Completed' once checkout date has passed.
    execute("UPDATE bookings SET status = 'Completed' WHERE status = 'Confirmed' AND check_out < %s",
            (datetime.date.today(),))


def _unique_code(cursor, prefix, digits, table, column):
    # Generates a random unique alphanumeric code (e.g. #OFS-83599 or TXN494733481482).
    while True:
        code = prefix + str(random.randint(10 ** (digits - 1), 10 ** digits - 1))
        cursor.execute(f"SELECT 1 FROM {table} WHERE {column} = %s", (code,))
        if cursor.fetchone() is None:
            return code


def create_booking_transaction(user_id, session_id, booking, payment):
    # WHAT: Executes an atomic multi-table transaction to confirm a reservation.
    # STEPS IN TRANSACTION:
    #   1. Lock property row (`SELECT ... FOR UPDATE`) to prevent race condition double-bookings.
    #   2. Re-verify date availability within the lock.
    #   3. Insert booking record with unique #OFS-XXXXX ref code and 4-digit keyless PIN.
    #   4. Insert payment record (storing only last 4 digits of card or masked UPI).
    #   5. Insert system confirmation message + automated host welcome message into chat.
    #   6. Insert in-app booking and check-in notifications.
    #   7. Write PAYMENT_SUCCESS and BOOKING_CREATED to activity_logs.
    #   8. Commit everything together. If any step fails, roll back completely.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            # 1. Row-level lock to prevent concurrent double-booking
            cursor.execute("SELECT property_id FROM properties WHERE property_id = %s FOR UPDATE", (booking["listing_id"],))
            
            # 2. Re-check date collision
            cursor.execute("""
                SELECT COUNT(*) AS n FROM bookings
                WHERE property_id = %s AND status = 'Confirmed' AND check_in < %s AND check_out > %s
            """, (booking["listing_id"], booking["check_out"], booking["check_in"]))
            if cursor.fetchone()["n"] > 0:
                conn.rollback()
                log_activity(user_id, "BOOKING_FAILED", "Dates were taken by another guest", "property",
                             booking["listing_id"], {"check_in": booking["check_in"], "check_out": booking["check_out"]},
                             status="FAILED", session_id=session_id)
                return False, "This property was just booked for the selected dates. Please choose other dates.", None

            now = _now()
            ref_code = _unique_code(cursor, "#OFS-", 5, "bookings", "ref_code")
            pin = f"{random.randint(1000, 9999)}#"
            
            # 3. Insert confirmed booking
            cursor.execute("""
                INSERT INTO bookings (ref_code, user_id, property_id, check_in, check_out, nights, guests,
                                      stay_cost, cleaning_fee, service_fee, taxes, total_price,
                                      host_note, status, keyless_pin, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'Confirmed', %s, %s)
            """, (ref_code, user_id, booking["listing_id"], booking["check_in"], booking["check_out"],
                  booking["nights"], booking["guests"], booking["stay_cost"], booking["cleaning_fee"],
                  booking["service_fee"], booking["taxes"], booking["total_price"],
                  booking.get("host_note") or None, pin, now))
            booking_id = cursor.lastrowid

            # 4. Insert payment record
            txn = _unique_code(cursor, "TXN", 12, "payments", "transaction_ref")
            cursor.execute("""
                INSERT INTO payments (booking_id, user_id, method, amount, currency, payment_status,
                                      transaction_ref, card_last4, upi_masked, paid_at)
                VALUES (%s, %s, %s, %s, 'USD', 'Paid', %s, %s, %s, %s)
            """, (booking_id, user_id, payment["method"], booking["total_price"], txn,
                  payment.get("card_last4"), payment.get("upi_masked"), now))

            # 5. Insert system notification and host automated welcome message into chat thread
            cursor.execute("""
                INSERT INTO messages (user_id, property_id, sender, text, sent_at, is_read) VALUES
                (%s, %s, 'system', %s, %s, 1),
                (%s, %s, 'host',   %s, %s, 0)
            """, (user_id, booking["listing_id"],
                  f"Booking confirmed (Ref: {ref_code}). Payment of ${booking['total_price']:.2f} simulated via {payment['method']}.", now,
                  user_id, booking["listing_id"],
                  f"Hello! Thank you for reserving your stay. Your digital keyless entry PIN is {pin}. Let us know if you have any questions before arrival! (automated demo reply)", now))

            # 6. Insert in-app notifications
            cursor.execute("""
                INSERT INTO notifications (user_id, kind, title, description, created_at, is_read) VALUES
                (%s, 'booking', 'Booking Confirmed', %s, %s, 0),
                (%s, 'checkin', 'Check-In Instructions', %s, %s, 0)
            """, (user_id, f"Reservation {ref_code} at {booking['listing_title']} is confirmed.", now,
                  user_id, f"Your keyless entry code for {booking['listing_title']} is {pin}.", now))

            # 7. Write audit log entries
            log_activity(user_id, "PAYMENT_SUCCESS", f"Simulated payment of ${booking['total_price']:.2f} succeeded",
                         "payment", booking_id, {"method": payment["method"], "amount": booking["total_price"], "transaction_ref": txn},
                         session_id=session_id, cursor=cursor)
            log_activity(user_id, "BOOKING_CREATED", f"Booking {ref_code} confirmed for {booking['listing_title']}",
                         "booking", booking_id, {"ref_code": ref_code, "check_in": booking["check_in"],
                                                 "check_out": booking["check_out"], "guests": booking["guests"]},
                         session_id=session_id, cursor=cursor)
        conn.commit()
        return True, "Booking confirmed successfully!", ref_code
    except Exception as e:
        conn.rollback()
        try:
            log_activity(user_id, "BOOKING_FAILED", "Database error while booking", "property", booking["listing_id"],
                         {"error": str(e)[:200]}, status="FAILED", session_id=session_id)
        except Exception:
            pass
        return False, f"Database transaction failed: {e}", None
    finally:
        conn.close()


# Base SELECT query joining bookings with properties, destinations, hosts, and payments.
BOOKING_SELECT = """
    SELECT b.*, b.booking_id AS id, b.property_id AS listing_id,
           p.title AS listing_title, p.location AS listing_location, p.price_per_night,
           d.name AS destination,
           h.display_name AS host_name,
           (SELECT image_url FROM property_images i WHERE i.property_id = p.property_id ORDER BY i.sort_order LIMIT 1) AS listing_images,
           pay.method AS payment_method, pay.transaction_ref, pay.payment_status
    FROM bookings b
    JOIN properties p ON p.property_id = b.property_id
    JOIN destinations d ON d.destination_id = p.destination_id
    JOIN hosts h ON h.host_id = p.host_id
    LEFT JOIN payments pay ON pay.booking_id = b.booking_id
"""


def get_bookings_by_status(user_id, status_list):
    # Returns bookings belonging exclusively to user_id matching specific statuses (Confirmed, Completed, Cancelled).
    placeholders = ",".join(["%s"] * len(status_list))
    return fetch_all(BOOKING_SELECT + f" WHERE b.user_id = %s AND b.status IN ({placeholders}) ORDER BY b.check_in DESC",
                     tuple([user_id] + list(status_list)))


def get_latest_booking_for_listing(user_id, listing_id):
    # Fetches the latest booking for a user at a listing to determine if Wi-Fi and door PINs should be revealed.
    return fetch_one("""
        SELECT * FROM bookings WHERE user_id = %s AND property_id = %s ORDER BY booking_id DESC LIMIT 1
    """, (user_id, listing_id))


def cancel_booking(user_id, session_id, booking_id, refund_amount, note):
    # WHAT: Cancels a confirmed booking, updates payment status, provisions notification, and logs cancellation.
    # HOW:  Uses `FOR UPDATE` so the booking cannot be double-cancelled or altered concurrently.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT b.ref_code, b.status, b.total_price, b.property_id, p.title
                FROM bookings b JOIN properties p ON p.property_id = b.property_id
                WHERE b.booking_id = %s AND b.user_id = %s FOR UPDATE
            """, (booking_id, user_id))
            info = cursor.fetchone()
            if not info or info["status"] != "Confirmed":
                conn.rollback()
                return False
                
            now = _now()
            cursor.execute("""
                UPDATE bookings SET status = 'Cancelled', cancelled_at = %s, refund_amount = %s WHERE booking_id = %s
            """, (now, refund_amount, booking_id))
            
            pay_status = "Refunded" if float(refund_amount) >= float(info["total_price"]) else "Partially Refunded"
            cursor.execute("""
                UPDATE payments SET payment_status = %s, refunded_amount = %s, refunded_at = %s WHERE booking_id = %s
            """, (pay_status, refund_amount, now, booking_id))
            
            cursor.execute("""
                INSERT INTO notifications (user_id, kind, title, description, created_at, is_read)
                VALUES (%s, 'booking', 'Reservation Cancelled', %s, %s, 0)
            """, (user_id, f"Reservation {info['ref_code']} cancelled. {note} Simulated refund: ${refund_amount:.2f}.", now))
            
            cursor.execute("""
                INSERT INTO messages (user_id, property_id, sender, text, sent_at, is_read)
                VALUES (%s, %s, 'system', %s, %s, 1)
            """, (user_id, info["property_id"], f"Booking {info['ref_code']} was cancelled. Simulated refund: ${refund_amount:.2f}.", now))
            
            log_activity(user_id, "BOOKING_CANCELLED", f"Booking {info['ref_code']} cancelled", "booking", booking_id,
                         {"refund": refund_amount, "policy": note}, session_id=session_id, cursor=cursor)
        conn.commit()
        return True
    finally:
        conn.close()


# =====================================================================
# IN-APP MESSAGES & CHAT
# =====================================================================

def get_conversations_summary(user_id):
    # Returns conversation threads for the logged-in user, ordered by most recent message.
    return fetch_all("""
        SELECT p.property_id AS id, p.title, h.display_name AS host_name, h.avatar_url AS host_avatar_url,
               (SELECT MAX(m.message_id) FROM messages m WHERE m.user_id = %s AND m.property_id = p.property_id) AS last_message_id
        FROM properties p JOIN hosts h ON h.host_id = p.host_id
        WHERE p.property_id IN (SELECT property_id FROM messages WHERE user_id = %s)
           OR p.property_id IN (SELECT property_id FROM bookings WHERE user_id = %s)
        ORDER BY last_message_id DESC, p.title
    """, (user_id, user_id, user_id))


def get_messages_for_listing(user_id, listing_id):
    # Fetches all messages between the guest and host for a specific property.
    return fetch_all("""
        SELECT * FROM messages WHERE user_id = %s AND property_id = %s ORDER BY message_id
    """, (user_id, listing_id))


def send_message(user_id, listing_id, sender, text, is_read=1):
    # Saves a chat message from guest, host, or system.
    return execute("""
        INSERT INTO messages (user_id, property_id, sender, text, sent_at, is_read) VALUES (%s, %s, %s, %s, %s, %s)
    """, (user_id, listing_id, sender, text, _now(), is_read))


def mark_thread_read(user_id, listing_id):
    # WHAT: Marks unread host/system messages in a chat thread as read.
    # RETURNS: The count of messages updated.
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            changed = cursor.execute(
                "UPDATE messages SET is_read = 1 WHERE user_id = %s AND property_id = %s AND is_read = 0",
                (user_id, listing_id)
            )
        conn.commit()
        return changed
    finally:
        conn.close()


def get_unread_message_count(user_id):
    # Counts unread messages sent to the guest (used for the sidebar notification counter).
    row = fetch_one("SELECT COUNT(*) AS n FROM messages WHERE user_id = %s AND sender <> 'guest' AND is_read = 0", (user_id,))
    return row["n"]


# =====================================================================
# NOTIFICATIONS
# =====================================================================

def get_notifications(user_id, filter_kind=None):
    # Fetches notifications for a user, optionally filtered by Bookings or Account.
    if filter_kind == "Bookings":
        return fetch_all("SELECT * FROM notifications WHERE user_id = %s AND kind IN ('booking', 'checkin') ORDER BY notification_id DESC", (user_id,))
    if filter_kind == "Account":
        return fetch_all("SELECT * FROM notifications WHERE user_id = %s AND kind IN ('message', 'review', 'account', 'host') ORDER BY notification_id DESC", (user_id,))
    return fetch_all("SELECT * FROM notifications WHERE user_id = %s ORDER BY notification_id DESC", (user_id,))


def get_unread_notification_count(user_id):
    # Counts unread notifications for the sidebar indicator.
    return fetch_one("SELECT COUNT(*) AS n FROM notifications WHERE user_id = %s AND is_read = 0", (user_id,))["n"]


def mark_notification_as_read(user_id, notification_id):
    # Marks a single notification as read.
    execute("UPDATE notifications SET is_read = 1 WHERE notification_id = %s AND user_id = %s", (notification_id, user_id))


def mark_all_notifications_as_read(user_id):
    # Marks all notifications for a user as read.
    execute("UPDATE notifications SET is_read = 1 WHERE user_id = %s", (user_id,))


# =====================================================================
# HOST PARTNERSHIP APPLICATIONS
# =====================================================================

def submit_host_application(user_id, name, email, city, prop_type, message):
    # Inserts a new host application and creates a confirmation notification.
    new_id = execute("""
        INSERT INTO host_applications (user_id, full_name, email, city, property_type, message, status, submitted_at)
        VALUES (%s, %s, %s, %s, %s, %s, 'Submitted', %s)
    """, (user_id, name, email, city, prop_type, message, _now()))
    execute("""
        INSERT INTO notifications (user_id, kind, title, description, created_at, is_read)
        VALUES (%s, 'host', 'Host application received', %s, %s, 0)
    """, (user_id, f"Application #{new_id} for a {prop_type} in {city} is under review.", _now()))
    return new_id


def get_host_application_count():
    # Returns the total number of host applications submitted to date.
    return fetch_one("SELECT COUNT(*) AS n FROM host_applications")["n"]


def get_user_host_applications(user_id):
    # Returns applications submitted by the logged-in user.
    return fetch_all("SELECT * FROM host_applications WHERE user_id = %s ORDER BY application_id DESC", (user_id,))


# =====================================================================
# ADMIN PLATFORM METRICS
# =====================================================================

def get_platform_stats():
    # WHAT: Queries aggregate metrics for the Admin Dashboard (total users, new signups, active bookings,
    #       gross booking revenue, and today's successful vs failed logins).
    today = datetime.date.today()
    return fetch_one("""
        SELECT
          (SELECT COUNT(*) FROM users) AS users,
          (SELECT COUNT(*) FROM users WHERE DATE(created_at) = %s) AS new_users_today,
          (SELECT COUNT(*) FROM properties) AS properties,
          (SELECT COUNT(*) FROM bookings WHERE status <> 'Cancelled') AS active_bookings,
          (SELECT COALESCE(SUM(total_price), 0) FROM bookings WHERE status <> 'Cancelled') AS revenue,
          (SELECT COUNT(*) FROM activity_logs WHERE activity_type = 'LOGIN' AND DATE(created_at) = %s) AS logins_today,
          (SELECT COUNT(*) FROM activity_logs WHERE activity_type = 'LOGIN_FAILED' AND DATE(created_at) = %s) AS failed_today,
          (SELECT COUNT(*) FROM activity_logs) AS total_logs
    """, (today, today, today))