# page_host.py: Become a Host Partnership Application Screen.
#
# WHAT THIS FILE DOES:
#   Renders the host acquisition workflow for property owners and boutique hosts:
#     1. Displays marketing benefit cards (e.g., $1M damage protection, verified guests, direct payouts).
#     2. Displays an educational demo disclaimer explaining that listing onboarding is simulated.
#     3. Presents an application submission form capturing full name, email, destination city,
#        property category, and an architectural/amenity description.
#     4. Enforces validation rules (non-empty fields, email formatting with '@' and '.',
#        and a minimum 20-character description requirement).
#     5. Inserts submitted applications into the MySQL `host_applications` table.
#     6. Automatically creates an in-app confirmation notification for the user.
#     7. Displays live application metrics and lists the user's previously submitted applications
#        with their current review status (Submitted, Under Review, Approved, or Rejected).
#
# WHY THIS STEP IS NECESSARY:
#   Demonstrates end-to-end data intake, persistence, and status tracking for prospective
#   property partners, proving that user submissions survive across server reruns and database restarts.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - Pre-fills the user's name and email from `auth.current_user()`.
#   - Queries distinct categories via `database.get_distinct_categories()`.
#   - Persists data via `database.submit_host_application()`.
#   - Records `HOST_APPLICATION` events in `activity_logs`.
#   - Queries application counts and user history via `database.get_user_host_applications()`.

import streamlit as st  # Streamlit UI framework (forms, columns, text inputs, text areas).
import database  # Database queries for categories, applications count, and application persistence.
import activity  # Audit logging helper for HOST_APPLICATION events.
import auth  # Retrieves current authenticated user dictionary.


def render():
    user = auth.current_user()
    st.title("Partner with OFFSTAYS")
    st.caption("Open your luxury sanctuary or boutique villa to discerning global travelers.")

    # Educational notice clarifying marketing copy is simulated for coursework evaluation.
    st.info("ℹ️ **Demo Information:** This host application workflow demonstrates database insertions and input validation for academic review. No real contracts or listings are generated.")

    # Host Benefits Showcase (3-column layout)
    st.markdown("### Why Host on OFFSTAYS?")
    b_col1, b_col2, b_col3 = st.columns(3)
    with b_col1:
        with st.container(border=True):
            st.markdown("#### 🛡️ $1M Protection")
            st.write("Comprehensive property damage protection and automated guest verification included with every stay.")
    with b_col2:
        with st.container(border=True):
            st.markdown("#### 💎 Verified Guests")
            st.write("Our platform serves curated guests with verified community profiles and stellar conduct reviews.")
    with b_col3:
        with st.container(border=True):
            st.markdown("#### ⚡ Effortless Payouts")
            st.write("Guaranteed scheduled direct deposits within 24 hours of guest check-in with transparent low fees.")

    st.markdown("---")

    # Host Application Intake Form
    st.markdown("### Submit Your Property Details")

    # Wrapping inputs in st.form ensures typing does not cause premature script reruns.
    with st.form(key="host_application_form"):
        # Pre-fill applicant details with the logged-in user's profile information
        f_name = st.text_input("Full Name", value=user["full_name"])
        f_email = st.text_input("Email Address", value=user["email"])
        f_city = st.text_input("City / Destination", placeholder="e.g. Anjuna, Goa")
        
        # Property Category dropdown populated dynamically with existing categories from MySQL
        f_type = st.selectbox(
            "Property Category",
            database.get_distinct_categories() + ["Other"]
        )
        f_msg = st.text_area(
            "Tell us about your property",
            placeholder="Describe bedroom count, unique design highlights, and guest amenities..."
        )

        # Form submission button
        submit_app = st.form_submit_button("Submit Host Application")

        if submit_app:
            # 1. Name validation
            if not f_name.strip():
                st.error("Please enter your full name.")
                return
                
            # 2. Email format validation
            if "@" not in f_email or "." not in f_email:
                st.error("Please enter a valid email address containing '@' and a domain (e.g. .com).")
                return
                
            # 3. Destination city validation
            if not f_city.strip():
                st.error("Please enter the city or destination.")
                return

            # 4. Description length validation (minimum 20 characters to ensure meaningful submissions)
            if len(f_msg.strip()) < 20:
                st.error("Please describe your property in at least 20 characters.")
                return
                
            # Insert application into MySQL and receive the new AUTO_INCREMENT application_id
            app_id = database.submit_host_application(
                user["user_id"],
                f_name.strip(),
                f_email.strip(),
                f_city.strip(),
                f_type,
                f_msg.strip()
            )
            
            # Log the submission in the MySQL activity audit trail
            activity.log_event(
                "HOST_APPLICATION",
                f"Submitted host application #{app_id}",
                "host_application",
                app_id,
                {"property_type": f_type, "city": f_city.strip()}
            )
            
            st.success("🎉 Thank you! Your host application has been received. Our concierge team will review your property within 48 hours.")

    # Live platform metric: Show total host applications received across the system
    total_apps = database.get_host_application_count()
    st.caption(f"Total host applications received to date: **{total_apps}**")

    # User History: Display applications previously submitted by this specific logged-in user
    my_apps = database.get_user_host_applications(user["user_id"])
    if my_apps:
        st.markdown("### Your Applications")
        for a in my_apps:
            st.write(
                f"**#{a['application_id']}** · {a['property_type']} in {a['city']} · Status: **{a['status']}** · "
                f"submitted {a['submitted_at'][:10]}"
            )