# page_login.py: User Authentication & Account Registration Screen.
#
# WHAT THIS FILE DOES:
#   Renders the login and registration tabs presented to unauthenticated visitors.
#   It captures user credentials, validates required input fields, displays demo
#   credentials for coursework evaluation, and delegates authentication and account
#   creation to `auth.py`.
#
# WHY THIS STEP IS NECESSARY:
#   This file acts as our front-line security boundary. It ensures that visitors
#   cannot browse stays, message hosts, or create reservations until they have
#   either signed into an existing account or registered a new one.
#
# HOW IT CONNECTS TO THE REST OF THE APPLICATION:
#   - It is imported and rendered directly by `app.py` whenever `auth.is_logged_in()` is False.
#   - Upon successful login or registration, it stores a welcome toast in `st.session_state["flash_main"]`
#     and calls `st.rerun()`, allowing `app.py` to transition to the Explore marketplace.

import streamlit as st  # Streamlit UI framework (handles forms, input widgets, tabs, and layout).
import auth  # Contains our authentication routines, password validation, and PBKDF2 hashing.


def render():
    # Centered layout: We create 3 columns with a [1, 2, 1] width ratio so the login
    # box appears neatly centered in the middle of the browser screen.
    left, center, right = st.columns([1, 2, 1])
    with center:
        st.markdown("<h1 style='text-align:center;'>🏡 OFFSTAYS</h1>", unsafe_allow_html=True)
        st.markdown(
            "<p style='text-align:center;'>Hand-picked sanctuaries · Bali · Goa · Maldives · Santorini · Swiss Alps · Kyoto & more</p>",
            unsafe_allow_html=True
        )

        # Check for any flash message carried over after a logout rerun (e.g., "You have been logged out.").
        flash = st.session_state.pop("flash", None)
        if flash:
            st.success(flash)

        # Split screen into Login and Register tabs
        tab_login, tab_register = st.tabs(["🔐 Log in", "✨ Create account"])

        # ---------------------------------------------------------- LOGIN TAB
        with tab_login:
            # We wrap input fields in `st.form` so typing does not trigger immediate script reruns.
            # The script only processes input when the user explicitly clicks the submit button.
            with st.form("login_form", clear_on_submit=False):
                email = st.text_input("Email", placeholder="you@example.com")
                password = st.text_input("Password", type="password")
                submitted = st.form_submit_button("Log in", use_container_width=True)
                
            if submitted:
                # Delegate credential lookup, brute-force checks, and PBKDF2 verification to auth.py
                ok, message = auth.login_user(email, password)
                if ok:
                    # Stash welcome message in session state and reload the app
                    st.session_state["flash_main"] = message
                    st.rerun()  # Triggers app.py to notice the user is logged in and render Explore.
                else:
                    # Display clean error message (e.g., "Incorrect email or password." or Lockout notice)
                    st.error(message)

            # Coursework evaluation expander providing pre-seeded accounts from sql/02_seed_data.sql
            with st.expander("Demo accounts (from the sample data)"):
                st.markdown(
                    "- **Guest:** `sarah.vance@example.com` / `Password@123`\n"
                    "- **Admin:** `admin@offstays.com` / `Admin@123`\n"
                    "- Every other sample user also uses `Password@123`."
                )

        # ---------------------------------------------------------- REGISTRATION TAB
        with tab_register:
            with st.form("register_form", clear_on_submit=False):
                full_name = st.text_input("Full name *", placeholder="e.g. Ketan Trivedi")
                reg_email = st.text_input("Email *", placeholder="you@example.com")
                phone = st.text_input("Phone", placeholder="+91 98765 43210")
                
                # Split city and country into two side-by-side columns
                c1, c2 = st.columns(2)
                with c1:
                    city = st.text_input("City", placeholder="Ahmedabad")
                with c2:
                    country = st.text_input("Country", placeholder="India")
                    
                reg_password = st.text_input(
                    "Password *",
                    type="password",
                    help="At least 8 characters, with a letter, a number and a special character."
                )
                confirm = st.text_input("Confirm password *", type="password")
                agree = st.checkbox("I agree to the OFFSTAYS terms and privacy policy.")
                create = st.form_submit_button("Create account", use_container_width=True)
                
            if create:
                # Mandatory checkbox verification
                if not agree:
                    st.error("Please accept the terms to create an account.")
                else:
                    # Validate complexity, hash with a fresh salt, and insert into MySQL via auth.py
                    ok, message = auth.register_user(
                        full_name, reg_email, phone, reg_password, confirm, city, country
                    )
                    if ok:
                        # Stash welcome message and reload; user is now fully authenticated
                        st.session_state["flash_main"] = message
                        st.rerun()
                    else:
                        st.error(message)

        st.caption("Demo project · Passwords are stored as salted PBKDF2-SHA256 hashes · All activity is recorded in MySQL.")